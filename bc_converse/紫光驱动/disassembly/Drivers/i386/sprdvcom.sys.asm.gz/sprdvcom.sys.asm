; Static disassembly: Drivers/i386/sprdvcom.sys
; Addresses are as reported by objdump. No original symbols or C source are implied.

Drivers/i386/sprdvcom.sys:     file format pei-i386


Disassembly of section .text:

00011000 <.text>:
   11000:	add    BYTE PTR [eax],al
   11002:	add    BYTE PTR [eax],al
   11004:	add    BYTE PTR [eax],al
   11006:	mov    edi,edi
   11008:	push   ebp
   11009:	mov    ebp,esp
   1100b:	push   DWORD PTR [ebp+0x8]
   1100e:	push   DWORD PTR ds:0x1770c
   11014:	call   DWORD PTR ds:0x172a0
   1101a:	push   eax
   1101b:	call   0x145c4
   11020:	pop    ebp
   11021:	ret    0x4
   11024:	int3
   11025:	int3
   11026:	int3
   11027:	int3
   11028:	int3
   11029:	int3
   1102a:	mov    edi,edi
   1102c:	push   ebp
   1102d:	mov    ebp,esp
   1102f:	mov    edx,DWORD PTR [ebp+0x8]
   11032:	mov    ecx,DWORD PTR ds:0x1770c
   11038:	push   esi
   11039:	push   DWORD PTR ds:0x1700c
   1103f:	call   DWORD PTR ds:0x173f0
   11045:	push   DWORD PTR [ebp+0x8]
   11048:	mov    esi,eax
   1104a:	push   DWORD PTR ds:0x1770c
   11050:	call   DWORD PTR ds:0x174cc
   11056:	test   al,al
   11058:	je     0x11061
   1105a:	mov    eax,0xc0000001
   1105f:	jmp    0x1107d
   11061:	mov    eax,DWORD PTR [ebp+0xc]
   11064:	or     DWORD PTR [esi+0x8],0x1
   11068:	push   eax
   11069:	push   DWORD PTR [ebp+0x8]
   1106c:	mov    DWORD PTR [esi+0x4],eax
   1106f:	push   DWORD PTR ds:0x1770c
   11075:	call   DWORD PTR ds:0x174c4
   1107b:	xor    eax,eax
   1107d:	pop    esi
   1107e:	pop    ebp
   1107f:	ret    0x8
   11082:	int3
   11083:	int3
   11084:	int3
   11085:	int3
   11086:	int3
   11087:	int3
   11088:	mov    edi,edi
   1108a:	push   ebp
   1108b:	mov    ebp,esp
   1108d:	mov    edx,DWORD PTR [ebp+0x8]
   11090:	mov    ecx,DWORD PTR ds:0x1770c
   11096:	push   esi
   11097:	push   DWORD PTR ds:0x1700c
   1109d:	call   DWORD PTR ds:0x173f0
   110a3:	mov    esi,eax
   110a5:	test   BYTE PTR [esi+0x8],0x1
   110a9:	jne    0x110af
   110ab:	xor    eax,eax
   110ad:	jmp    0x110d4
   110af:	push   DWORD PTR [ebp+0x8]
   110b2:	push   DWORD PTR ds:0x1770c
   110b8:	call   DWORD PTR ds:0x174c8
   110be:	test   eax,eax
   110c0:	jl     0x110d4
   110c2:	mov    ecx,DWORD PTR [esi+0x8]
   110c5:	test   cl,0x1
   110c8:	je     0x110d4
   110ca:	and    ecx,0xfffffffe
   110cd:	and    DWORD PTR [esi+0x4],0x0
   110d1:	mov    DWORD PTR [esi+0x8],ecx
   110d4:	pop    esi
   110d5:	pop    ebp
   110d6:	ret    0x4
   110d9:	int3
   110da:	int3
   110db:	int3
   110dc:	int3
   110dd:	int3
   110de:	mov    edi,edi
   110e0:	push   ebp
   110e1:	mov    ebp,esp
   110e3:	sub    esp,0x14
   110e6:	push   esi
   110e7:	push   edi
   110e8:	push   DWORD PTR [ebp+0xc]
   110eb:	push   DWORD PTR [ebp+0x8]
   110ee:	call   0x145bc
   110f3:	xor    eax,eax
   110f5:	lea    edi,[ebp-0x14]
   110f8:	stos   DWORD PTR es:[edi],eax
   110f9:	stos   DWORD PTR es:[edi],eax
   110fa:	stos   DWORD PTR es:[edi],eax
   110fb:	stos   DWORD PTR es:[edi],eax
   110fc:	stos   DWORD PTR es:[edi],eax
   110fd:	push   0x0
   110ff:	lea    eax,[ebp-0x14]
   11102:	push   eax
   11103:	push   0x0
   11105:	push   DWORD PTR [ebp+0xc]
   11108:	mov    DWORD PTR [ebp-0x14],0x14
   1110f:	push   DWORD PTR [ebp+0x8]
   11112:	mov    DWORD PTR [ebp-0x10],0x12826
   11119:	push   DWORD PTR ds:0x1770c
   1111f:	mov    DWORD PTR [ebp-0xc],0x11006
   11126:	call   DWORD PTR ds:0x17298
   1112c:	mov    esi,eax
   1112e:	test   esi,esi
   11130:	jge    0x1113a
   11132:	push   DWORD PTR [ebp+0x8]
   11135:	call   0x145c4
   1113a:	pop    edi
   1113b:	mov    eax,esi
   1113d:	pop    esi
   1113e:	leave
   1113f:	ret    0x8
   11142:	int3
   11143:	int3
   11144:	int3
   11145:	int3
   11146:	int3
   11147:	int3
   11148:	mov    edi,edi
   1114a:	push   ebp
   1114b:	mov    ebp,esp
   1114d:	sub    esp,0xc
   11150:	push   esi
   11151:	mov    esi,DWORD PTR [ebp+0x8]
   11154:	push   0x0
   11156:	push   0x7fff
   1115b:	push   0x0
   1115d:	lea    eax,[ebp-0x8]
   11160:	push   eax
   11161:	lea    eax,[ebp-0xc]
   11164:	push   eax
   11165:	push   esi
   11166:	call   0x148b4
   1116b:	test   eax,eax
   1116d:	jl     0x11191
   1116f:	and    DWORD PTR [ebp-0x4],0x0
   11173:	lea    eax,[ebp+0x10]
   11176:	push   eax
   11177:	push   DWORD PTR [ebp+0xc]
   1117a:	lea    eax,[ebp-0x4]
   1117d:	push   eax
   1117e:	push   DWORD PTR [ebp-0x8]
   11181:	push   DWORD PTR [ebp-0xc]
   11184:	call   0x14910
   11189:	mov    ecx,DWORD PTR [ebp-0x4]
   1118c:	add    ecx,ecx
   1118e:	mov    WORD PTR [esi],cx
   11191:	pop    esi
   11192:	leave
   11193:	ret
   11194:	int3
   11195:	int3
   11196:	int3
   11197:	int3
   11198:	int3
   11199:	int3
   1119a:	mov    edi,edi
   1119c:	push   ebp
   1119d:	mov    ebp,esp
   1119f:	sub    esp,0x20
   111a2:	push   ebx
   111a3:	push   esi
   111a4:	mov    esi,DWORD PTR [ebp+0x8]
   111a7:	push   edi
   111a8:	push   0x8
   111aa:	pop    ecx
   111ab:	xor    eax,eax
   111ad:	lea    edi,[ebp-0x20]
   111b0:	rep stos DWORD PTR es:[edi],eax
   111b2:	mov    eax,ds:0x17020
   111b7:	mov    DWORD PTR [ebp-0x4],eax
   111ba:	mov    eax,DWORD PTR [esi]
   111bc:	lea    edi,[esi+0x5c]
   111bf:	push   edi
   111c0:	mov    DWORD PTR [ebp-0xc],eax
   111c3:	push   0x0
   111c5:	lea    eax,[ebp-0x20]
   111c8:	push   eax
   111c9:	push   DWORD PTR ds:0x1770c
   111cf:	xor    ebx,ebx
   111d1:	inc    ebx
   111d2:	mov    DWORD PTR [ebp-0x20],0x20
   111d9:	mov    DWORD PTR [ebp-0x14],ebx
   111dc:	mov    DWORD PTR [ebp-0x10],ebx
   111df:	call   DWORD PTR ds:0x174a4
   111e5:	test   eax,eax
   111e7:	jne    0x11244
   111e9:	push   DWORD PTR ds:0x17020
   111ef:	mov    edx,DWORD PTR [edi]
   111f1:	mov    ecx,DWORD PTR ds:0x1770c
   111f7:	call   DWORD PTR ds:0x173f0
   111fd:	mov    ecx,DWORD PTR [esi]
   111ff:	mov    DWORD PTR [eax],ecx
   11201:	push   0x8
   11203:	pop    ecx
   11204:	lea    edx,[eax+0x4]
   11207:	and    DWORD PTR [edx],0x0
   1120a:	push   0x0
   1120c:	xor    eax,eax
   1120e:	push   edx
   1120f:	lea    edi,[ebp-0x20]
   11212:	rep stos DWORD PTR es:[edi],eax
   11214:	mov    eax,DWORD PTR [esi]
   11216:	mov    esi,DWORD PTR [esi+0x144]
   1121c:	push   esi
   1121d:	push   0x6d6f6355
   11222:	mov    DWORD PTR [ebp-0xc],eax
   11225:	push   0x0
   11227:	lea    eax,[ebp-0x20]
   1122a:	push   eax
   1122b:	push   DWORD PTR ds:0x1770c
   11231:	mov    DWORD PTR [ebp-0x20],0x20
   11238:	mov    DWORD PTR [ebp-0x14],ebx
   1123b:	mov    DWORD PTR [ebp-0x10],ebx
   1123e:	call   DWORD PTR ds:0x173c8
   11244:	pop    edi
   11245:	pop    esi
   11246:	pop    ebx
   11247:	leave
   11248:	ret    0x4
   1124b:	int3
   1124c:	int3
   1124d:	int3
   1124e:	int3
   1124f:	int3
   11250:	mov    edi,edi
   11252:	push   ebp
   11253:	mov    ebp,esp
   11255:	sub    esp,0xc
   11258:	mov    eax,DWORD PTR [ebp+0x8]
   1125b:	mov    eax,DWORD PTR [eax]
   1125d:	and    DWORD PTR [ebp-0x4],0x0
   11261:	push   edi
   11262:	lea    ecx,[ebp-0x4]
   11265:	push   ecx
   11266:	push   0x0
   11268:	push   0x1f0000
   1126d:	push   0x1
   1126f:	push   eax
   11270:	push   DWORD PTR ds:0x1770c
   11276:	call   DWORD PTR ds:0x17188
   1127c:	mov    edi,eax
   1127e:	test   edi,edi
   11280:	jne    0x112aa
   11282:	push   0x1562a
   11287:	lea    eax,[ebp-0xc]
   1128a:	push   eax
   1128b:	call   DWORD PTR ds:0x16044
   11291:	push   DWORD PTR [ebp+0xc]
   11294:	lea    eax,[ebp-0xc]
   11297:	push   edi
   11298:	push   eax
   11299:	push   DWORD PTR [ebp-0x4]
   1129c:	push   DWORD PTR ds:0x1770c
   112a2:	call   DWORD PTR ds:0x17480
   112a8:	mov    edi,eax
   112aa:	cmp    DWORD PTR [ebp-0x4],0x0
   112ae:	je     0x112bf
   112b0:	push   DWORD PTR [ebp-0x4]
   112b3:	push   DWORD PTR ds:0x1770c
   112b9:	call   DWORD PTR ds:0x17464
   112bf:	mov    eax,edi
   112c1:	pop    edi
   112c2:	leave
   112c3:	ret    0x8
   112c6:	int3
   112c7:	int3
   112c8:	int3
   112c9:	int3
   112ca:	int3
   112cb:	int3
   112cc:	mov    edi,edi
   112ce:	push   ebp
   112cf:	mov    ebp,esp
   112d1:	sub    esp,0x238
   112d7:	mov    eax,ds:0x17044
   112dc:	xor    eax,ebp
   112de:	mov    DWORD PTR [ebp-0x4],eax
   112e1:	push   ebx
   112e2:	push   esi
   112e3:	mov    esi,DWORD PTR [ebp+0x8]
   112e6:	push   edi
   112e7:	xor    eax,eax
   112e9:	push   0xfe
   112ee:	push   eax
   112ef:	mov    WORD PTR [ebp-0x104],ax
   112f6:	lea    eax,[ebp-0x102]
   112fc:	push   eax
   112fd:	call   0x14618
   11302:	xor    eax,eax
   11304:	and    DWORD PTR [ebp-0x208],0x0
   1130b:	mov    WORD PTR [ebp-0x210],ax
   11312:	add    esp,0xc
   11315:	mov    ebx,0x100
   1131a:	mov    eax,ebx
   1131c:	mov    WORD PTR [ebp-0x20e],ax
   11323:	push   0x8
   11325:	pop    ecx
   11326:	lea    eax,[ebp-0x204]
   1132c:	mov    DWORD PTR [ebp-0x20c],eax
   11332:	xor    eax,eax
   11334:	lea    edi,[ebp-0x238]
   1133a:	rep stos DWORD PTR es:[edi],eax
   1133c:	mov    eax,DWORD PTR [esi]
   1133e:	mov    DWORD PTR [ebp-0x224],eax
   11344:	lea    eax,[ebp-0x208]
   1134a:	push   eax
   1134b:	lea    eax,[ebp-0x238]
   11351:	push   eax
   11352:	push   0x0
   11354:	push   DWORD PTR ds:0x1770c
   1135a:	xor    edi,edi
   1135c:	inc    edi
   1135d:	mov    DWORD PTR [ebp-0x238],0x20
   11367:	mov    DWORD PTR [ebp-0x22c],edi
   1136d:	mov    DWORD PTR [ebp-0x228],edi
   11373:	call   DWORD PTR ds:0x17598
   11379:	test   eax,eax
   1137b:	jne    0x1147d
   11381:	push   DWORD PTR [ebp-0x208]
   11387:	mov    eax,DWORD PTR [esi]
   11389:	push   eax
   1138a:	push   DWORD PTR ds:0x1770c
   11390:	call   DWORD PTR ds:0x17168
   11396:	test   eax,eax
   11398:	jne    0x1147d
   1139e:	lea    eax,[esi+0x24]
   113a1:	push   eax
   113a2:	push   DWORD PTR [ebp-0x208]
   113a8:	push   DWORD PTR ds:0x1770c
   113ae:	call   DWORD PTR ds:0x1759c
   113b4:	xor    eax,eax
   113b6:	mov    WORD PTR [ebp-0x218],ax
   113bd:	lea    eax,[ebp-0x104]
   113c3:	mov    DWORD PTR [ebp-0x214],eax
   113c9:	lea    eax,[ebp-0x218]
   113cf:	push   eax
   113d0:	push   esi
   113d1:	mov    WORD PTR [ebp-0x216],bx
   113d8:	call   0x11250
   113dd:	test   eax,eax
   113df:	jne    0x1147d
   113e5:	lea    eax,[ebp-0x104]
   113eb:	push   eax
   113ec:	push   0x15660
   113f1:	lea    eax,[ebp-0x210]
   113f7:	push   0x15652
   113fc:	push   eax
   113fd:	call   0x11148
   11402:	add    esp,0x10
   11405:	test   eax,eax
   11407:	jne    0x1147d
   11409:	mov    eax,DWORD PTR [esi]
   1140b:	lea    ecx,[ebp-0x210]
   11411:	push   ecx
   11412:	push   eax
   11413:	push   DWORD PTR ds:0x1770c
   11419:	call   DWORD PTR ds:0x17208
   1141f:	test   eax,eax
   11421:	jne    0x1147d
   11423:	lea    eax,[ebp-0x104]
   11429:	mov    BYTE PTR [esi+0x71],0x1
   1142d:	lea    ecx,[eax+0x2]
   11430:	mov    dx,WORD PTR [eax]
   11433:	inc    eax
   11434:	inc    eax
   11435:	test   dx,dx
   11438:	jne    0x11430
   1143a:	sub    eax,ecx
   1143c:	sar    eax,1
   1143e:	lea    eax,[eax+eax*1+0x2]
   11442:	push   eax
   11443:	lea    eax,[ebp-0x104]
   11449:	push   eax
   1144a:	push   edi
   1144b:	push   DWORD PTR [esi+0x28]
   1144e:	push   0x1563c
   11453:	push   0x4
   11455:	call   DWORD PTR ds:0x1602c
   1145b:	test   eax,eax
   1145d:	jne    0x1147d
   1145f:	mov    eax,DWORD PTR [esi]
   11461:	push   0x0
   11463:	push   0x160cc
   11468:	push   eax
   11469:	mov    BYTE PTR [esi+0x72],0x1
   1146d:	push   DWORD PTR ds:0x1770c
   11473:	call   DWORD PTR ds:0x171fc
   11479:	test   eax,eax
   1147b:	je     0x11481
   1147d:	and    DWORD PTR [esi+0x28],0x0
   11481:	mov    ecx,DWORD PTR [ebp-0x4]
   11484:	pop    edi
   11485:	pop    esi
   11486:	xor    ecx,ebp
   11488:	pop    ebx
   11489:	call   0x145cc
   1148e:	leave
   1148f:	ret    0x4
   11492:	int3
   11493:	int3
   11494:	int3
   11495:	int3
   11496:	int3
   11497:	int3
   11498:	mov    edi,edi
   1149a:	push   ebp
   1149b:	mov    ebp,esp
   1149d:	mov    ecx,DWORD PTR [ebp+0x8]
   114a0:	mov    eax,DWORD PTR [ecx+0x14c]
   114a6:	test   eax,eax
   114a8:	je     0x114ad
   114aa:	push   ecx
   114ab:	call   eax
   114ad:	pop    ebp
   114ae:	ret    0x4
   114b1:	int3
   114b2:	int3
   114b3:	int3
   114b4:	int3
   114b5:	int3
   114b6:	mov    edi,edi
   114b8:	push   ebp
   114b9:	mov    ebp,esp
   114bb:	mov    ecx,DWORD PTR [ebp+0x8]
   114be:	mov    eax,DWORD PTR [ecx+0x150]
   114c4:	test   eax,eax
   114c6:	je     0x114cb
   114c8:	push   ecx
   114c9:	call   eax
   114cb:	pop    ebp
   114cc:	ret    0x4
   114cf:	int3
   114d0:	int3
   114d1:	int3
   114d2:	int3
   114d3:	int3
   114d4:	mov    edi,edi
   114d6:	push   ebp
   114d7:	mov    ebp,esp
   114d9:	mov    ecx,DWORD PTR [ebp+0x8]
   114dc:	mov    eax,DWORD PTR [ecx+0x154]
   114e2:	test   eax,eax
   114e4:	je     0x114e9
   114e6:	push   ecx
   114e7:	call   eax
   114e9:	pop    ebp
   114ea:	ret    0x4
   114ed:	int3
   114ee:	int3
   114ef:	int3
   114f0:	int3
   114f1:	int3
   114f2:	xor    eax,eax
   114f4:	ret    0x4
   114f7:	int3
   114f8:	int3
   114f9:	int3
   114fa:	int3
   114fb:	int3
   114fc:	mov    edi,edi
   114fe:	push   ebp
   114ff:	mov    ebp,esp
   11501:	mov    edx,DWORD PTR [ebp+0x8]
   11504:	mov    ecx,DWORD PTR ds:0x1770c
   1150a:	push   esi
   1150b:	push   edi
   1150c:	push   DWORD PTR ds:0x17034
   11512:	xor    edi,edi
   11514:	call   DWORD PTR ds:0x173f0
   1151a:	mov    esi,eax
   1151c:	cmp    DWORD PTR [esi+0x7c],edi
   1151f:	je     0x11549
   11521:	push   esi
   11522:	call   0x114b6
   11527:	mov    edi,eax
   11529:	xor    eax,eax
   1152b:	inc    eax
   1152c:	lea    ecx,[esi+0x80]
   11532:	xchg   DWORD PTR [ecx],eax
   11534:	test   eax,eax
   11536:	jne    0x11549
   11538:	push   DWORD PTR [esi+0x44]
   1153b:	push   DWORD PTR ds:0x1770c
   11541:	call   DWORD PTR ds:0x17374
   11547:	mov    edi,eax
   11549:	mov    eax,edi
   1154b:	pop    edi
   1154c:	pop    esi
   1154d:	pop    ebp
   1154e:	ret    0x8
   11551:	int3
   11552:	int3
   11553:	int3
   11554:	int3
   11555:	int3
   11556:	mov    edi,edi
   11558:	push   ebp
   11559:	mov    ebp,esp
   1155b:	mov    edx,DWORD PTR [ebp+0x8]
   1155e:	mov    ecx,DWORD PTR ds:0x1770c
   11564:	push   esi
   11565:	push   edi
   11566:	push   DWORD PTR ds:0x17034
   1156c:	xor    edi,edi
   1156e:	call   DWORD PTR ds:0x173f0
   11574:	mov    esi,eax
   11576:	cmp    DWORD PTR [esi+0x7c],edi
   11579:	je     0x115a2
   1157b:	xor    eax,eax
   1157d:	lea    ecx,[esi+0x80]
   11583:	xchg   DWORD PTR [ecx],eax
   11585:	cmp    eax,0x1
   11588:	jne    0x1159a
   1158a:	push   eax
   1158b:	push   DWORD PTR [esi+0x44]
   1158e:	push   DWORD PTR ds:0x1770c
   11594:	call   DWORD PTR ds:0x17378
   1159a:	push   esi
   1159b:	call   0x114d4
   115a0:	mov    edi,eax
   115a2:	mov    eax,edi
   115a4:	pop    edi
   115a5:	pop    esi
   115a6:	pop    ebp
   115a7:	ret    0x8
   115aa:	int3
   115ab:	int3
   115ac:	int3
   115ad:	int3
   115ae:	int3
   115af:	int3
   115b0:	mov    edi,edi
   115b2:	push   ebp
   115b3:	mov    ebp,esp
   115b5:	push   DWORD PTR ds:0x17034
   115bb:	mov    edx,DWORD PTR [ebp+0x8]
   115be:	mov    ecx,DWORD PTR ds:0x1770c
   115c4:	call   DWORD PTR ds:0x173f0
   115ca:	pop    ebp
   115cb:	ret    0x4
   115ce:	int3
   115cf:	int3
   115d0:	int3
   115d1:	int3
   115d2:	int3
   115d3:	int3
   115d4:	mov    edi,edi
   115d6:	push   ebp
   115d7:	mov    ebp,esp
   115d9:	sub    esp,0x14
   115dc:	push   esi
   115dd:	mov    esi,DWORD PTR [ebp+0x8]
   115e0:	mov    eax,DWORD PTR [esi+0x2c]
   115e3:	lea    ecx,[ebp+0xc]
   115e6:	push   ecx
   115e7:	push   0x0
   115e9:	push   eax
   115ea:	push   DWORD PTR ds:0x1770c
   115f0:	call   DWORD PTR ds:0x175f0
   115f6:	test   eax,eax
   115f8:	jne    0x1167f
   115fe:	push   DWORD PTR [esi+0x2c]
   11601:	push   DWORD PTR ds:0x1770c
   11607:	call   DWORD PTR ds:0x175ec
   1160d:	test   al,al
   1160f:	jbe    0x1167d
   11611:	mov    eax,DWORD PTR [ebp+0x18]
   11614:	mov    DWORD PTR [esi+0x30],eax
   11617:	mov    al,BYTE PTR [ebp+0x14]
   1161a:	mov    BYTE PTR [esi+0x3c],al
   1161d:	cmp    al,0x2
   1161f:	jae    0x11628
   11621:	mov    eax,0xc0000001
   11626:	jmp    0x1167f
   11628:	mov    BYTE PTR [ebp+0x8],0x0
   1162c:	test   al,al
   1162e:	jbe    0x1167d
   11630:	push   edi
   11631:	xor    eax,eax
   11633:	lea    edi,[ebp-0x14]
   11636:	stos   DWORD PTR es:[edi],eax
   11637:	stos   DWORD PTR es:[edi],eax
   11638:	stos   DWORD PTR es:[edi],eax
   11639:	stos   DWORD PTR es:[edi],eax
   1163a:	lea    ecx,[ebp-0x14]
   1163d:	push   ecx
   1163e:	push   DWORD PTR [ebp+0x8]
   11641:	stos   DWORD PTR es:[edi],eax
   11642:	mov    eax,DWORD PTR [esi+0x30]
   11645:	push   eax
   11646:	push   DWORD PTR ds:0x1770c
   1164c:	mov    DWORD PTR [ebp-0x14],0x14
   11653:	call   DWORD PTR ds:0x1767c
   11659:	test   eax,eax
   1165b:	je     0x11671
   1165d:	cmp    DWORD PTR [ebp-0x8],0x3
   11661:	jne    0x11671
   11663:	test   BYTE PTR [ebp-0xc],0x80
   11667:	je     0x1166e
   11669:	mov    DWORD PTR [esi+0x44],eax
   1166c:	jmp    0x11671
   1166e:	mov    DWORD PTR [esi+0x40],eax
   11671:	inc    BYTE PTR [ebp+0x8]
   11674:	mov    al,BYTE PTR [ebp+0x8]
   11677:	cmp    al,BYTE PTR [esi+0x3c]
   1167a:	jb     0x11631
   1167c:	pop    edi
   1167d:	xor    eax,eax
   1167f:	pop    esi
   11680:	leave
   11681:	ret    0x18
   11684:	int3
   11685:	int3
   11686:	int3
   11687:	int3
   11688:	int3
   11689:	int3
   1168a:	mov    edi,edi
   1168c:	push   ebp
   1168d:	mov    ebp,esp
   1168f:	sub    esp,0x1c
   11692:	push   esi
   11693:	mov    esi,DWORD PTR [ebp+0x8]
   11696:	mov    eax,DWORD PTR [esi+0x2c]
   11699:	lea    ecx,[ebp+0xc]
   1169c:	push   ecx
   1169d:	push   0x0
   1169f:	push   eax
   116a0:	push   DWORD PTR ds:0x1770c
   116a6:	call   DWORD PTR ds:0x175f0
   116ac:	test   eax,eax
   116ae:	jne    0x11774
   116b4:	push   ebx
   116b5:	push   edi
   116b6:	push   DWORD PTR [esi+0x2c]
   116b9:	push   DWORD PTR ds:0x1770c
   116bf:	call   DWORD PTR ds:0x175ec
   116c5:	test   al,al
   116c7:	jbe    0x11770
   116cd:	mov    al,BYTE PTR [ebp+0x1c]
   116d0:	mov    BYTE PTR [esi+0x135],al
   116d6:	mov    BYTE PTR [ebp-0x8],0x0
   116da:	test   al,al
   116dc:	jbe    0x11770
   116e2:	push   DWORD PTR [ebp-0x8]
   116e5:	mov    eax,DWORD PTR [esi+0x2c]
   116e8:	push   eax
   116e9:	push   DWORD PTR ds:0x1770c
   116ef:	call   DWORD PTR ds:0x17670
   116f5:	mov    ebx,eax
   116f7:	test   ebx,ebx
   116f9:	je     0x11779
   116fb:	push   ebx
   116fc:	push   DWORD PTR ds:0x1770c
   11702:	call   DWORD PTR ds:0x17678
   11708:	mov    BYTE PTR [ebp+0xb],al
   1170b:	mov    BYTE PTR [ebp-0x4],0x0
   1170f:	test   al,al
   11711:	jbe    0x1175e
   11713:	xor    eax,eax
   11715:	lea    edi,[ebp-0x1c]
   11718:	stos   DWORD PTR es:[edi],eax
   11719:	stos   DWORD PTR es:[edi],eax
   1171a:	stos   DWORD PTR es:[edi],eax
   1171b:	stos   DWORD PTR es:[edi],eax
   1171c:	stos   DWORD PTR es:[edi],eax
   1171d:	lea    eax,[ebp-0x1c]
   11720:	push   eax
   11721:	push   DWORD PTR [ebp-0x4]
   11724:	mov    DWORD PTR [ebp-0x1c],0x14
   1172b:	push   ebx
   1172c:	push   DWORD PTR ds:0x1770c
   11732:	call   DWORD PTR ds:0x1767c
   11738:	test   eax,eax
   1173a:	je     0x11753
   1173c:	cmp    DWORD PTR [ebp-0x10],0x3
   11740:	jne    0x11753
   11742:	test   BYTE PTR [ebp-0x14],0x80
   11746:	je     0x1174d
   11748:	mov    DWORD PTR [esi+0x44],eax
   1174b:	jmp    0x11750
   1174d:	mov    DWORD PTR [esi+0x40],eax
   11750:	mov    DWORD PTR [esi+0x30],ebx
   11753:	inc    BYTE PTR [ebp-0x4]
   11756:	mov    al,BYTE PTR [ebp-0x4]
   11759:	cmp    al,BYTE PTR [ebp+0xb]
   1175c:	jb     0x11713
   1175e:	inc    BYTE PTR [ebp-0x8]
   11761:	mov    al,BYTE PTR [ebp-0x8]
   11764:	cmp    al,BYTE PTR [esi+0x135]
   1176a:	jb     0x116e2
   11770:	xor    eax,eax
   11772:	pop    edi
   11773:	pop    ebx
   11774:	pop    esi
   11775:	leave
   11776:	ret    0x18
   11779:	mov    eax,0xc0000001
   1177e:	jmp    0x11772
   11780:	int3
   11781:	int3
   11782:	int3
   11783:	int3
   11784:	int3
   11785:	int3
   11786:	mov    edi,edi
   11788:	push   ebp
   11789:	mov    ebp,esp
   1178b:	mov    edx,DWORD PTR [ebp+0x8]
   1178e:	mov    ecx,DWORD PTR ds:0x1770c
   11794:	push   esi
   11795:	push   DWORD PTR ds:0x17034
   1179b:	call   DWORD PTR ds:0x173f0
   117a1:	mov    esi,eax
   117a3:	push   0xf
   117a5:	push   esi
   117a6:	call   0x142f0
   117ab:	push   0x0
   117ad:	push   esi
   117ae:	call   0x14218
   117b3:	xor    eax,eax
   117b5:	pop    esi
   117b6:	pop    ebp
   117b7:	ret    0x8
   117ba:	int3
   117bb:	int3
   117bc:	int3
   117bd:	int3
   117be:	int3
   117bf:	int3
   117c0:	mov    edi,edi
   117c2:	push   ebp
   117c3:	mov    ebp,esp
   117c5:	sub    esp,0x10
   117c8:	push   esi
   117c9:	mov    esi,DWORD PTR [ebp+0x8]
   117cc:	cmp    BYTE PTR [esi+0x14a],0x0
   117d3:	je     0x117ec
   117d5:	push   DWORD PTR [esi+0x44]
   117d8:	push   DWORD PTR ds:0x1770c
   117de:	call   DWORD PTR ds:0x17374
   117e4:	mov    DWORD PTR [ebp+0x8],eax
   117e7:	jmp    0x118a2
   117ec:	mov    edx,DWORD PTR [esi+0x5c]
   117ef:	mov    ecx,DWORD PTR ds:0x1770c
   117f5:	push   ebx
   117f6:	push   edi
   117f7:	push   DWORD PTR ds:0x17020
   117fd:	call   DWORD PTR ds:0x173f0
   11803:	mov    ebx,eax
   11805:	xor    eax,eax
   11807:	lea    edi,[ebp-0x10]
   1180a:	stos   DWORD PTR es:[edi],eax
   1180b:	stos   DWORD PTR es:[edi],eax
   1180c:	stos   DWORD PTR es:[edi],eax
   1180d:	stos   DWORD PTR es:[edi],eax
   1180e:	mov    eax,DWORD PTR [esi+0x5c]
   11811:	lea    ecx,[ebp-0x10]
   11814:	push   ecx
   11815:	push   eax
   11816:	push   DWORD PTR ds:0x1770c
   1181c:	xor    edi,edi
   1181e:	mov    DWORD PTR [ebp-0x10],0x10
   11825:	mov    DWORD PTR [ebp-0xc],edi
   11828:	mov    DWORD PTR [ebp-0x8],edi
   1182b:	call   DWORD PTR ds:0x174ac
   11831:	mov    DWORD PTR [ebp+0x8],eax
   11834:	cmp    eax,edi
   11836:	jne    0x118a0
   11838:	mov    eax,DWORD PTR [ebx+0x4]
   1183b:	mov    ecx,DWORD PTR [esi+0x5c]
   1183e:	mov    edx,DWORD PTR [esi+0x44]
   11841:	push   edi
   11842:	push   eax
   11843:	push   ecx
   11844:	push   edx
   11845:	push   DWORD PTR ds:0x1770c
   1184b:	call   DWORD PTR ds:0x1763c
   11851:	mov    DWORD PTR [ebp+0x8],eax
   11854:	cmp    eax,edi
   11856:	jne    0x118a0
   11858:	push   ebx
   11859:	push   0x13a06
   1185e:	push   DWORD PTR [esi+0x5c]
   11861:	push   DWORD PTR ds:0x1770c
   11867:	call   DWORD PTR ds:0x174d8
   1186d:	lea    ebx,[esi+0x60]
   11870:	push   ebx
   11871:	call   DWORD PTR ds:0x16018
   11877:	mov    eax,DWORD PTR [esi+0x44]
   1187a:	mov    esi,DWORD PTR [esi+0x5c]
   1187d:	push   edi
   1187e:	push   eax
   1187f:	push   esi
   11880:	push   DWORD PTR ds:0x1770c
   11886:	call   DWORD PTR ds:0x174bc
   1188c:	test   al,al
   1188e:	jne    0x118a0
   11890:	push   edi
   11891:	push   edi
   11892:	push   ebx
   11893:	mov    DWORD PTR [ebp+0x8],0xc0000001
   1189a:	call   DWORD PTR ds:0x16014
   118a0:	pop    edi
   118a1:	pop    ebx
   118a2:	mov    eax,DWORD PTR [ebp+0x8]
   118a5:	pop    esi
   118a6:	leave
   118a7:	ret    0x4
   118aa:	int3
   118ab:	int3
   118ac:	int3
   118ad:	int3
   118ae:	int3
   118af:	int3
   118b0:	mov    edi,edi
   118b2:	push   ebp
   118b3:	mov    ebp,esp
   118b5:	push   ebx
   118b6:	push   esi
   118b7:	mov    esi,DWORD PTR [ebp+0x8]
   118ba:	xor    ebx,ebx
   118bc:	cmp    BYTE PTR [esi+0x14a],bl
   118c2:	je     0x118d7
   118c4:	push   0x1
   118c6:	push   DWORD PTR [esi+0x44]
   118c9:	push   DWORD PTR ds:0x1770c
   118cf:	call   DWORD PTR ds:0x17378
   118d5:	jmp    0x118f4
   118d7:	push   DWORD PTR [esi+0x5c]
   118da:	push   DWORD PTR ds:0x1770c
   118e0:	call   DWORD PTR ds:0x174d0
   118e6:	push   ebx
   118e7:	push   ebx
   118e8:	push   ebx
   118e9:	push   ebx
   118ea:	add    esi,0x60
   118ed:	push   esi
   118ee:	call   DWORD PTR ds:0x16048
   118f4:	pop    esi
   118f5:	pop    ebx
   118f6:	pop    ebp
   118f7:	ret    0x4
   118fa:	int3
   118fb:	int3
   118fc:	int3
   118fd:	int3
   118fe:	int3
   118ff:	int3
   11900:	mov    edi,edi
   11902:	push   ebp
   11903:	mov    ebp,esp
   11905:	push   ecx
   11906:	and    DWORD PTR [ebp-0x4],0x0
   1190a:	push   esi
   1190b:	push   edi
   1190c:	push   DWORD PTR [ebp+0x8]
   1190f:	push   DWORD PTR ds:0x1770c
   11915:	call   DWORD PTR ds:0x172f4
   1191b:	push   DWORD PTR ds:0x17034
   11921:	mov    ecx,DWORD PTR ds:0x1770c
   11927:	mov    edx,eax
   11929:	call   DWORD PTR ds:0x173f0
   1192f:	mov    esi,eax
   11931:	lea    eax,[ebp-0x4]
   11934:	push   eax
   11935:	push   esi
   11936:	call   0x1446a
   1193b:	xor    eax,eax
   1193d:	lea    ecx,[esi+0x80]
   11943:	xchg   DWORD PTR [ecx],eax
   11945:	xor    edi,edi
   11947:	inc    edi
   11948:	cmp    eax,edi
   1194a:	jne    0x11952
   1194c:	push   esi
   1194d:	call   0x118b0
   11952:	push   edi
   11953:	push   DWORD PTR [esi+0x4]
   11956:	push   DWORD PTR ds:0x1770c
   1195c:	call   DWORD PTR ds:0x175c8
   11962:	push   edi
   11963:	push   DWORD PTR [esi+0x20]
   11966:	push   DWORD PTR ds:0x1770c
   1196c:	call   DWORD PTR ds:0x1728c
   11972:	push   edi
   11973:	push   DWORD PTR [esi+0x18]
   11976:	push   DWORD PTR ds:0x1770c
   1197c:	call   DWORD PTR ds:0x1728c
   11982:	push   edi
   11983:	push   DWORD PTR [esi+0x1c]
   11986:	push   DWORD PTR ds:0x1770c
   1198c:	call   DWORD PTR ds:0x1728c
   11992:	push   esi
   11993:	call   0x114d4
   11998:	xor    eax,eax
   1199a:	lea    ecx,[esi+0x7c]
   1199d:	xchg   DWORD PTR [ecx],eax
   1199f:	push   edi
   119a0:	push   DWORD PTR [esi]
   119a2:	push   DWORD PTR ds:0x1770c
   119a8:	call   DWORD PTR ds:0x171f8
   119ae:	pop    edi
   119af:	pop    esi
   119b0:	leave
   119b1:	ret    0x4
   119b4:	int3
   119b5:	int3
   119b6:	int3
   119b7:	int3
   119b8:	int3
   119b9:	int3
   119ba:	mov    edi,edi
   119bc:	push   ebp
   119bd:	mov    ebp,esp
   119bf:	push   ecx
   119c0:	push   DWORD PTR [ebp+0x8]
   119c3:	and    DWORD PTR [ebp-0x4],0x0
   119c7:	push   DWORD PTR ds:0x1770c
   119cd:	call   DWORD PTR ds:0x172f4
   119d3:	push   DWORD PTR ds:0x17034
   119d9:	mov    ecx,DWORD PTR ds:0x1770c
   119df:	mov    edx,eax
   119e1:	call   DWORD PTR ds:0x173f0
   119e7:	lea    ecx,[ebp-0x4]
   119ea:	push   ecx
   119eb:	push   eax
   119ec:	call   0x1446a
   119f1:	leave
   119f2:	ret    0x4
   119f5:	int3
   119f6:	int3
   119f7:	int3
   119f8:	int3
   119f9:	int3
   119fa:	mov    edi,edi
   119fc:	push   ebp
   119fd:	mov    ebp,esp
   119ff:	push   esi
   11a00:	push   DWORD PTR [ebp+0x8]
   11a03:	push   DWORD PTR ds:0x1770c
   11a09:	call   DWORD PTR ds:0x175cc
   11a0f:	push   DWORD PTR ds:0x17034
   11a15:	mov    ecx,DWORD PTR ds:0x1770c
   11a1b:	mov    edx,eax
   11a1d:	call   DWORD PTR ds:0x173f0
   11a23:	mov    esi,eax
   11a25:	push   esi
   11a26:	call   0x143e8
   11a2b:	push   esi
   11a2c:	call   0x145c4
   11a31:	push   esi
   11a32:	call   0x1393e
   11a37:	pop    esi
   11a38:	pop    ebp
   11a39:	ret    0x4
   11a3c:	int3
   11a3d:	int3
   11a3e:	int3
   11a3f:	int3
   11a40:	int3
   11a41:	int3
   11a42:	mov    edi,edi
   11a44:	push   ebp
   11a45:	mov    ebp,esp
   11a47:	mov    edx,DWORD PTR [ebp+0x8]
   11a4a:	mov    ecx,DWORD PTR ds:0x1770c
   11a50:	push   esi
   11a51:	push   edi
   11a52:	push   DWORD PTR ds:0x17034
   11a58:	call   DWORD PTR ds:0x173f0
   11a5e:	mov    esi,eax
   11a60:	cmp    BYTE PTR [esi+0x73],0x0
   11a64:	mov    edi,DWORD PTR [esi+0x28]
   11a67:	je     0x11a74
   11a69:	call   DWORD PTR ds:0x16020
   11a6f:	add    eax,0x14
   11a72:	dec    DWORD PTR [eax]
   11a74:	test   edi,edi
   11a76:	je     0x11a8c
   11a78:	cmp    BYTE PTR [esi+0x72],0x0
   11a7c:	je     0x11a8c
   11a7e:	push   edi
   11a7f:	push   0x1563c
   11a84:	push   0x4
   11a86:	call   DWORD PTR ds:0x1601c
   11a8c:	pop    edi
   11a8d:	pop    esi
   11a8e:	pop    ebp
   11a8f:	ret    0x4
   11a92:	int3
   11a93:	int3
   11a94:	int3
   11a95:	int3
   11a96:	int3
   11a97:	int3
   11a98:	mov    edi,edi
   11a9a:	push   ebp
   11a9b:	mov    ebp,esp
   11a9d:	sub    esp,0x1c
   11aa0:	mov    eax,ds:0x17044
   11aa5:	xor    eax,ebp
   11aa7:	mov    DWORD PTR [ebp-0x4],eax
   11aaa:	xor    eax,eax
   11aac:	push   esi
   11aad:	mov    esi,DWORD PTR [ebp+0x8]
   11ab0:	mov    ecx,DWORD PTR [esi+0x13c]
   11ab6:	push   edi
   11ab7:	lea    edi,[ebp-0xc]
   11aba:	stos   DWORD PTR es:[edi],eax
   11abb:	stos   DWORD PTR es:[edi],eax
   11abc:	mov    al,BYTE PTR [ebp-0xc]
   11abf:	and    al,0x1c
   11ac1:	or     al,0x21
   11ac3:	mov    BYTE PTR [ebp-0xc],al
   11ac6:	mov    al,BYTE PTR [ebp+0xc]
   11ac9:	mov    BYTE PTR [ebp-0xb],al
   11acc:	mov    ax,WORD PTR [ebp+0x10]
   11ad0:	mov    WORD PTR [ebp-0xa],ax
   11ad4:	mov    ax,WORD PTR [ebp+0x14]
   11ad8:	mov    WORD PTR [ebp-0x8],ax
   11adc:	xor    eax,eax
   11ade:	test   ecx,ecx
   11ae0:	je     0x11b0f
   11ae2:	lea    edi,[ebp-0x1c]
   11ae5:	stos   DWORD PTR es:[edi],eax
   11ae6:	stos   DWORD PTR es:[edi],eax
   11ae7:	push   0xffffffff
   11ae9:	stos   DWORD PTR es:[edi],eax
   11aea:	push   0xff676980
   11aef:	push   0x0
   11af1:	stos   DWORD PTR es:[edi],eax
   11af2:	push   ecx
   11af3:	mov    DWORD PTR [ebp-0x1c],0x10
   11afa:	mov    DWORD PTR [ebp-0x18],0x1
   11b01:	call   0x1460c
   11b06:	mov    DWORD PTR [ebp-0x14],eax
   11b09:	mov    DWORD PTR [ebp-0x10],edx
   11b0c:	lea    eax,[ebp-0x1c]
   11b0f:	mov    esi,DWORD PTR [esi+0x2c]
   11b12:	push   0x0
   11b14:	push   0x0
   11b16:	lea    ecx,[ebp-0xc]
   11b19:	push   ecx
   11b1a:	push   eax
   11b1b:	push   0x0
   11b1d:	push   esi
   11b1e:	push   DWORD PTR ds:0x1770c
   11b24:	call   DWORD PTR ds:0x175fc
   11b2a:	mov    ecx,DWORD PTR [ebp-0x4]
   11b2d:	pop    edi
   11b2e:	xor    ecx,ebp
   11b30:	pop    esi
   11b31:	call   0x145cc
   11b36:	leave
   11b37:	ret    0x10
   11b3a:	int3
   11b3b:	int3
   11b3c:	int3
   11b3d:	int3
   11b3e:	int3
   11b3f:	int3
   11b40:	mov    edi,edi
   11b42:	push   ebp
   11b43:	mov    ebp,esp
   11b45:	mov    eax,DWORD PTR [ebp+0xc]
   11b48:	mov    ecx,DWORD PTR [ebp+0x8]
   11b4b:	mov    edx,DWORD PTR [ebp+0x10]
   11b4e:	mov    DWORD PTR [ecx],eax
   11b50:	mov    DWORD PTR [ecx+0x4],eax
   11b53:	mov    DWORD PTR [ecx+0x8],eax
   11b56:	add    eax,edx
   11b58:	mov    DWORD PTR [ecx+0xc],eax
   11b5b:	pop    ebp
   11b5c:	ret    0xc
   11b5f:	int3
   11b60:	int3
   11b61:	int3
   11b62:	int3
   11b63:	int3
   11b64:	mov    edi,edi
   11b66:	push   ebp
   11b67:	mov    ebp,esp
   11b69:	mov    eax,DWORD PTR [ebp+0xc]
   11b6c:	mov    ecx,DWORD PTR [ebp+0x8]
   11b6f:	inc    eax
   11b70:	cmp    eax,DWORD PTR [ecx+0xc]
   11b73:	jb     0x11b77
   11b75:	mov    eax,DWORD PTR [ecx]
   11b77:	pop    ebp
   11b78:	ret    0x8
   11b7b:	int3
   11b7c:	int3
   11b7d:	int3
   11b7e:	int3
   11b7f:	int3
   11b80:	mov    edi,edi
   11b82:	push   ebp
   11b83:	mov    ebp,esp
   11b85:	mov    eax,DWORD PTR [ebp+0x8]
   11b88:	mov    eax,DWORD PTR [eax+0x8]
   11b8b:	pop    ebp
   11b8c:	ret    0x4
   11b8f:	int3
   11b90:	int3
   11b91:	int3
   11b92:	int3
   11b93:	int3
   11b94:	mov    edi,edi
   11b96:	push   ebp
   11b97:	mov    ebp,esp
   11b99:	mov    eax,DWORD PTR [ebp+0x8]
   11b9c:	mov    eax,DWORD PTR [eax+0x4]
   11b9f:	pop    ebp
   11ba0:	ret    0x4
   11ba3:	int3
   11ba4:	int3
   11ba5:	int3
   11ba6:	int3
   11ba7:	int3
   11ba8:	mov    edi,edi
   11baa:	push   ebp
   11bab:	mov    ebp,esp
   11bad:	mov    ecx,DWORD PTR [ebp+0x8]
   11bb0:	mov    eax,DWORD PTR [ecx+0x4]
   11bb3:	sub    eax,DWORD PTR [ecx+0x8]
   11bb6:	neg    eax
   11bb8:	sbb    eax,eax
   11bba:	inc    eax
   11bbb:	pop    ebp
   11bbc:	ret    0x4
   11bbf:	int3
   11bc0:	int3
   11bc1:	int3
   11bc2:	int3
   11bc3:	int3
   11bc4:	mov    edi,edi
   11bc6:	push   ebp
   11bc7:	mov    ebp,esp
   11bc9:	mov    edx,DWORD PTR [ebp+0x8]
   11bcc:	push   DWORD PTR [edx+0x4]
   11bcf:	push   edx
   11bd0:	call   0x11b64
   11bd5:	sub    eax,DWORD PTR [edx+0x8]
   11bd8:	neg    eax
   11bda:	sbb    eax,eax
   11bdc:	inc    eax
   11bdd:	pop    ebp
   11bde:	ret    0x4
   11be1:	int3
   11be2:	int3
   11be3:	int3
   11be4:	int3
   11be5:	int3
   11be6:	mov    edi,edi
   11be8:	push   ebp
   11be9:	mov    ebp,esp
   11beb:	mov    ecx,DWORD PTR [ebp+0x8]
   11bee:	mov    eax,DWORD PTR [ecx+0xc]
   11bf1:	sub    eax,DWORD PTR [ecx]
   11bf3:	pop    ebp
   11bf4:	ret    0x4
   11bf7:	int3
   11bf8:	int3
   11bf9:	int3
   11bfa:	int3
   11bfb:	int3
   11bfc:	mov    edi,edi
   11bfe:	push   ebp
   11bff:	mov    ebp,esp
   11c01:	mov    ecx,DWORD PTR [ebp+0x8]
   11c04:	mov    edx,DWORD PTR [ecx+0x8]
   11c07:	push   esi
   11c08:	mov    esi,DWORD PTR [ecx+0x4]
   11c0b:	cmp    edx,esi
   11c0d:	ja     0x11c15
   11c0f:	mov    eax,esi
   11c11:	sub    eax,edx
   11c13:	jmp    0x11c1e
   11c15:	mov    eax,DWORD PTR [ecx+0xc]
   11c18:	sub    eax,edx
   11c1a:	sub    eax,DWORD PTR [ecx]
   11c1c:	add    eax,esi
   11c1e:	pop    esi
   11c1f:	pop    ebp
   11c20:	ret    0x4
   11c23:	int3
   11c24:	int3
   11c25:	int3
   11c26:	int3
   11c27:	int3
   11c28:	mov    edi,edi
   11c2a:	push   ebp
   11c2b:	mov    ebp,esp
   11c2d:	mov    eax,DWORD PTR [ebp+0x8]
   11c30:	mov    ecx,DWORD PTR [eax]
   11c32:	mov    DWORD PTR [eax+0x8],ecx
   11c35:	mov    DWORD PTR [eax+0x4],ecx
   11c38:	pop    ebp
   11c39:	ret    0x4
   11c3c:	int3
   11c3d:	int3
   11c3e:	int3
   11c3f:	int3
   11c40:	int3
   11c41:	int3
   11c42:	mov    edi,edi
   11c44:	push   ebp
   11c45:	mov    ebp,esp
   11c47:	push   esi
   11c48:	push   DWORD PTR [ebp+0x8]
   11c4b:	push   DWORD PTR ds:0x1770c
   11c51:	call   DWORD PTR ds:0x17290
   11c57:	push   DWORD PTR ds:0x17034
   11c5d:	mov    ecx,DWORD PTR ds:0x1770c
   11c63:	mov    edx,eax
   11c65:	call   DWORD PTR ds:0x173f0
   11c6b:	mov    esi,DWORD PTR [eax+0x10]
   11c6e:	mov    edx,DWORD PTR [eax+0x130]
   11c74:	mov    ecx,esi
   11c76:	and    ecx,edx
   11c78:	test   cl,0x10
   11c7b:	je     0x11c82
   11c7d:	or     ecx,0x8
   11c80:	jmp    0x11c85
   11c82:	and    ecx,0xfffffff7
   11c85:	test   ecx,ecx
   11c87:	je     0x11c8c
   11c89:	push   ecx
   11c8a:	jmp    0x11c95
   11c8c:	test   edx,edx
   11c8e:	jne    0x11c9b
   11c90:	test   esi,esi
   11c92:	je     0x11c9b
   11c94:	push   edx
   11c95:	push   eax
   11c96:	call   0x14218
   11c9b:	pop    esi
   11c9c:	pop    ebp
   11c9d:	ret    0x4
   11ca0:	int3
   11ca1:	int3
   11ca2:	int3
   11ca3:	int3
   11ca4:	int3
   11ca5:	int3
   11ca6:	mov    edi,edi
   11ca8:	push   ebp
   11ca9:	mov    ebp,esp
   11cab:	sub    esp,0x2c
   11cae:	push   ebx
   11caf:	push   esi
   11cb0:	mov    esi,DWORD PTR [ebp+0x8]
   11cb3:	push   edi
   11cb4:	xor    eax,eax
   11cb6:	lea    edi,[ebp-0xc]
   11cb9:	stos   DWORD PTR es:[edi],eax
   11cba:	stos   DWORD PTR es:[edi],eax
   11cbb:	stos   DWORD PTR es:[edi],eax
   11cbc:	push   0x8
   11cbe:	pop    ecx
   11cbf:	xor    eax,eax
   11cc1:	lea    edi,[ebp-0x2c]
   11cc4:	rep stos DWORD PTR es:[edi],eax
   11cc6:	mov    eax,DWORD PTR [esi]
   11cc8:	mov    DWORD PTR [ebp-0x18],eax
   11ccb:	lea    eax,[esi+0x1c]
   11cce:	push   eax
   11ccf:	lea    eax,[ebp-0x2c]
   11cd2:	push   eax
   11cd3:	lea    eax,[ebp-0xc]
   11cd6:	push   eax
   11cd7:	push   DWORD PTR ds:0x1770c
   11cdd:	xor    ebx,ebx
   11cdf:	inc    ebx
   11ce0:	mov    DWORD PTR [ebp-0xc],0xc
   11ce7:	mov    DWORD PTR [ebp-0x8],0x13d72
   11cee:	mov    BYTE PTR [ebp-0x4],bl
   11cf1:	mov    DWORD PTR [ebp-0x2c],0x20
   11cf8:	mov    DWORD PTR [ebp-0x20],ebx
   11cfb:	mov    DWORD PTR [ebp-0x1c],ebx
   11cfe:	call   DWORD PTR ds:0x17284
   11d04:	test   eax,eax
   11d06:	jne    0x11da6
   11d0c:	lea    edi,[ebp-0xc]
   11d0f:	stos   DWORD PTR es:[edi],eax
   11d10:	stos   DWORD PTR es:[edi],eax
   11d11:	stos   DWORD PTR es:[edi],eax
   11d12:	push   0x8
   11d14:	pop    ecx
   11d15:	xor    eax,eax
   11d17:	lea    edi,[ebp-0x2c]
   11d1a:	rep stos DWORD PTR es:[edi],eax
   11d1c:	mov    eax,DWORD PTR [esi]
   11d1e:	mov    DWORD PTR [ebp-0x18],eax
   11d21:	lea    eax,[esi+0x18]
   11d24:	push   eax
   11d25:	lea    eax,[ebp-0x2c]
   11d28:	push   eax
   11d29:	lea    eax,[ebp-0xc]
   11d2c:	push   eax
   11d2d:	push   DWORD PTR ds:0x1770c
   11d33:	mov    DWORD PTR [ebp-0xc],0xc
   11d3a:	mov    DWORD PTR [ebp-0x8],0x135aa
   11d41:	mov    BYTE PTR [ebp-0x4],bl
   11d44:	mov    DWORD PTR [ebp-0x2c],0x20
   11d4b:	mov    DWORD PTR [ebp-0x20],ebx
   11d4e:	mov    DWORD PTR [ebp-0x1c],ebx
   11d51:	call   DWORD PTR ds:0x17284
   11d57:	test   eax,eax
   11d59:	jne    0x11da6
   11d5b:	lea    edi,[ebp-0xc]
   11d5e:	stos   DWORD PTR es:[edi],eax
   11d5f:	stos   DWORD PTR es:[edi],eax
   11d60:	stos   DWORD PTR es:[edi],eax
   11d61:	push   0x8
   11d63:	pop    ecx
   11d64:	xor    eax,eax
   11d66:	lea    edi,[ebp-0x2c]
   11d69:	rep stos DWORD PTR es:[edi],eax
   11d6b:	mov    eax,DWORD PTR [esi]
   11d6d:	mov    DWORD PTR [ebp-0x18],eax
   11d70:	add    esi,0x20
   11d73:	push   esi
   11d74:	lea    eax,[ebp-0x2c]
   11d77:	push   eax
   11d78:	lea    eax,[ebp-0xc]
   11d7b:	push   eax
   11d7c:	push   DWORD PTR ds:0x1770c
   11d82:	mov    DWORD PTR [ebp-0xc],0xc
   11d89:	mov    DWORD PTR [ebp-0x8],0x11c42
   11d90:	mov    BYTE PTR [ebp-0x4],bl
   11d93:	mov    DWORD PTR [ebp-0x2c],0x20
   11d9a:	mov    DWORD PTR [ebp-0x20],ebx
   11d9d:	mov    DWORD PTR [ebp-0x1c],ebx
   11da0:	call   DWORD PTR ds:0x17284
   11da6:	pop    edi
   11da7:	pop    esi
   11da8:	pop    ebx
   11da9:	leave
   11daa:	ret    0x4
   11dad:	int3
   11dae:	int3
   11daf:	int3
   11db0:	int3
   11db1:	int3
   11db2:	mov    edi,edi
   11db4:	push   ebp
   11db5:	mov    ebp,esp
   11db7:	sub    esp,0x34
   11dba:	push   edi
   11dbb:	xor    eax,eax
   11dbd:	lea    edi,[ebp-0x14]
   11dc0:	stos   DWORD PTR es:[edi],eax
   11dc1:	stos   DWORD PTR es:[edi],eax
   11dc2:	stos   DWORD PTR es:[edi],eax
   11dc3:	stos   DWORD PTR es:[edi],eax
   11dc4:	stos   DWORD PTR es:[edi],eax
   11dc5:	and    DWORD PTR [ebp-0x4],0x0
   11dc9:	push   0x8
   11dcb:	pop    ecx
   11dcc:	xor    eax,eax
   11dce:	lea    edi,[ebp-0x34]
   11dd1:	rep stos DWORD PTR es:[edi],eax
   11dd3:	mov    eax,DWORD PTR [ebp+0x8]
   11dd6:	mov    ecx,DWORD PTR [eax]
   11dd8:	add    eax,0x4
   11ddb:	push   eax
   11ddc:	lea    eax,[ebp-0x34]
   11ddf:	push   eax
   11de0:	lea    eax,[ebp-0x14]
   11de3:	xor    edx,edx
   11de5:	inc    edx
   11de6:	push   eax
   11de7:	push   DWORD PTR ds:0x1770c
   11ded:	mov    DWORD PTR [ebp-0x14],0x14
   11df4:	mov    DWORD PTR [ebp-0x10],0x119fa
   11dfb:	mov    BYTE PTR [ebp-0x8],dl
   11dfe:	mov    DWORD PTR [ebp-0xc],0x64
   11e05:	mov    DWORD PTR [ebp-0x34],0x20
   11e0c:	mov    DWORD PTR [ebp-0x28],edx
   11e0f:	mov    DWORD PTR [ebp-0x24],edx
   11e12:	mov    DWORD PTR [ebp-0x20],ecx
   11e15:	call   DWORD PTR ds:0x175c0
   11e1b:	pop    edi
   11e1c:	leave
   11e1d:	ret    0x4
   11e20:	int3
   11e21:	int3
   11e22:	int3
   11e23:	int3
   11e24:	int3
   11e25:	int3
   11e26:	mov    edi,edi
   11e28:	push   ebp
   11e29:	mov    ebp,esp
   11e2b:	sub    esp,0x14
   11e2e:	push   esi
   11e2f:	mov    esi,DWORD PTR [ebp+0x8]
   11e32:	xor    eax,eax
   11e34:	cmp    BYTE PTR [esi+0x34],0xff
   11e38:	je     0x11e80
   11e3a:	push   edi
   11e3b:	lea    edi,[ebp-0x14]
   11e3e:	stos   DWORD PTR es:[edi],eax
   11e3f:	stos   DWORD PTR es:[edi],eax
   11e40:	stos   DWORD PTR es:[edi],eax
   11e41:	stos   DWORD PTR es:[edi],eax
   11e42:	stos   DWORD PTR es:[edi],eax
   11e43:	lea    eax,[ebp-0x14]
   11e46:	push   eax
   11e47:	push   DWORD PTR [esi+0x40]
   11e4a:	mov    DWORD PTR [ebp-0x14],0x14
   11e51:	push   DWORD PTR ds:0x1770c
   11e57:	call   DWORD PTR ds:0x1761c
   11e5d:	movzx  ax,BYTE PTR [ebp-0xc]
   11e62:	movzx  cx,BYTE PTR [esi+0x34]
   11e67:	shl    ax,0x8
   11e6b:	or     ax,0x1
   11e6f:	movzx  ecx,cx
   11e72:	movzx  eax,ax
   11e75:	push   ecx
   11e76:	push   eax
   11e77:	push   0x22
   11e79:	push   esi
   11e7a:	call   0x11a98
   11e7f:	pop    edi
   11e80:	pop    esi
   11e81:	leave
   11e82:	ret    0x4
   11e85:	int3
   11e86:	int3
   11e87:	int3
   11e88:	int3
   11e89:	int3
   11e8a:	mov    edi,edi
   11e8c:	push   ebp
   11e8d:	mov    ebp,esp
   11e8f:	mov    ecx,DWORD PTR [ebp+0x8]
   11e92:	mov    al,BYTE PTR [ecx+0x34]
   11e95:	cmp    al,0xff
   11e97:	jne    0x11e9d
   11e99:	xor    eax,eax
   11e9b:	jmp    0x11eaf
   11e9d:	movzx  ax,al
   11ea1:	movzx  eax,ax
   11ea4:	push   eax
   11ea5:	push   0x1
   11ea7:	push   0x22
   11ea9:	push   ecx
   11eaa:	call   0x11a98
   11eaf:	pop    ebp
   11eb0:	ret    0x4
   11eb3:	int3
   11eb4:	int3
   11eb5:	int3
   11eb6:	int3
   11eb7:	int3
   11eb8:	mov    edi,edi
   11eba:	push   ebp
   11ebb:	mov    ebp,esp
   11ebd:	mov    ecx,DWORD PTR [ebp+0x8]
   11ec0:	mov    al,BYTE PTR [ecx+0x34]
   11ec3:	cmp    al,0xff
   11ec5:	jne    0x11ecb
   11ec7:	xor    eax,eax
   11ec9:	jmp    0x11edd
   11ecb:	movzx  ax,al
   11ecf:	movzx  eax,ax
   11ed2:	push   eax
   11ed3:	push   0x0
   11ed5:	push   0x22
   11ed7:	push   ecx
   11ed8:	call   0x11a98
   11edd:	pop    ebp
   11ede:	ret    0x4
   11ee1:	int3
   11ee2:	int3
   11ee3:	int3
   11ee4:	int3
   11ee5:	int3
   11ee6:	mov    edi,edi
   11ee8:	push   ebp
   11ee9:	mov    ebp,esp
   11eeb:	sub    esp,0x138
   11ef1:	mov    eax,ds:0x17044
   11ef6:	xor    eax,ebp
   11ef8:	mov    DWORD PTR [ebp-0x4],eax
   11efb:	push   ebx
   11efc:	mov    ebx,DWORD PTR [ebp+0x8]
   11eff:	mov    eax,DWORD PTR [ebx]
   11f01:	push   esi
   11f02:	lea    ecx,[ebp-0x100]
   11f08:	push   ecx
   11f09:	xor    esi,esi
   11f0b:	push   esi
   11f0c:	push   0x1f0000
   11f11:	push   0x1
   11f13:	push   eax
   11f14:	mov    DWORD PTR [ebx+0x13c],0x5
   11f1e:	mov    DWORD PTR [ebx+0x140],0x20000
   11f28:	mov    BYTE PTR [ebx+0x14b],0x1
   11f2f:	mov    DWORD PTR [ebx+0x144],0x1000
   11f39:	mov    BYTE PTR [ebx+0x148],0x1
   11f40:	mov    BYTE PTR [ebx+0x14a],0x0
   11f47:	mov    BYTE PTR [ebx+0x149],0x0
   11f4e:	push   DWORD PTR ds:0x1770c
   11f54:	mov    DWORD PTR [ebp-0x100],esi
   11f5a:	call   DWORD PTR ds:0x17188
   11f60:	test   eax,eax
   11f62:	jne    0x1221c
   11f68:	push   edi
   11f69:	push   0xd
   11f6b:	pop    ecx
   11f6c:	push   0x32
   11f6e:	pop    eax
   11f6f:	push   0x34
   11f71:	mov    WORD PTR [ebp-0x118],ax
   11f78:	pop    eax
   11f79:	push   0x9
   11f7b:	mov    WORD PTR [ebp-0x116],ax
   11f82:	mov    esi,0x15736
   11f87:	lea    edi,[ebp-0xf8]
   11f8d:	rep movs DWORD PTR es:[edi],DWORD PTR ds:[esi]
   11f8f:	pop    ecx
   11f90:	push   0x22
   11f92:	lea    eax,[ebp-0xf8]
   11f98:	mov    DWORD PTR [ebp-0x114],eax
   11f9e:	pop    eax
   11f9f:	push   0x24
   11fa1:	mov    WORD PTR [ebp-0x138],ax
   11fa8:	pop    eax
   11fa9:	push   0xa
   11fab:	mov    WORD PTR [ebp-0x136],ax
   11fb2:	mov    esi,0x15712
   11fb7:	lea    edi,[ebp-0x78]
   11fba:	rep movs DWORD PTR es:[edi],DWORD PTR ds:[esi]
   11fbc:	pop    ecx
   11fbd:	push   0x26
   11fbf:	lea    eax,[ebp-0x78]
   11fc2:	mov    DWORD PTR [ebp-0x134],eax
   11fc8:	pop    eax
   11fc9:	push   0x28
   11fcb:	mov    WORD PTR [ebp-0x130],ax
   11fd2:	pop    eax
   11fd3:	push   0x9
   11fd5:	mov    WORD PTR [ebp-0x12e],ax
   11fdc:	mov    esi,0x156ea
   11fe1:	lea    edi,[ebp-0xc4]
   11fe7:	rep movs DWORD PTR es:[edi],DWORD PTR ds:[esi]
   11fe9:	pop    ecx
   11fea:	push   0x22
   11fec:	lea    eax,[ebp-0xc4]
   11ff2:	mov    DWORD PTR [ebp-0x12c],eax
   11ff8:	pop    eax
   11ff9:	push   0x24
   11ffb:	mov    WORD PTR [ebp-0x120],ax
   12002:	pop    eax
   12003:	push   0x5
   12005:	mov    WORD PTR [ebp-0x11e],ax
   1200c:	mov    esi,0x156c6
   12011:	lea    edi,[ebp-0x9c]
   12017:	rep movs DWORD PTR es:[edi],DWORD PTR ds:[esi]
   12019:	pop    ecx
   1201a:	push   0x14
   1201c:	lea    eax,[ebp-0x9c]
   12022:	mov    DWORD PTR [ebp-0x11c],eax
   12028:	pop    eax
   12029:	push   0x16
   1202b:	mov    WORD PTR [ebp-0x110],ax
   12032:	pop    eax
   12033:	push   0x7
   12035:	mov    esi,0x156b0
   1203a:	lea    edi,[ebp-0x1c]
   1203d:	rep movs DWORD PTR es:[edi],DWORD PTR ds:[esi]
   1203f:	pop    ecx
   12040:	mov    WORD PTR [ebp-0x10e],ax
   12047:	push   0x1a
   12049:	lea    eax,[ebp-0x1c]
   1204c:	mov    DWORD PTR [ebp-0x10c],eax
   12052:	pop    eax
   12053:	push   0x1c
   12055:	mov    WORD PTR [ebp-0x128],ax
   1205c:	pop    eax
   1205d:	movs   WORD PTR es:[edi],WORD PTR ds:[esi]
   1205f:	mov    WORD PTR [ebp-0x126],ax
   12066:	mov    esi,0x15694
   1206b:	lea    edi,[ebp-0x54]
   1206e:	lea    eax,[ebp-0x54]
   12071:	rep movs DWORD PTR es:[edi],DWORD PTR ds:[esi]
   12073:	mov    DWORD PTR [ebp-0x124],eax
   12079:	push   0x6
   1207b:	pop    ecx
   1207c:	push   0x18
   1207e:	pop    eax
   1207f:	push   0x1a
   12081:	mov    WORD PTR [ebp-0x108],ax
   12088:	pop    eax
   12089:	mov    WORD PTR [ebp-0x106],ax
   12090:	mov    esi,0x1567a
   12095:	lea    edi,[ebp-0x38]
   12098:	lea    eax,[ebp-0x38]
   1209b:	rep movs DWORD PTR es:[edi],DWORD PTR ds:[esi]
   1209d:	mov    DWORD PTR [ebp-0x104],eax
   120a3:	lea    eax,[ebp-0xfc]
   120a9:	push   eax
   120aa:	lea    eax,[ebp-0x118]
   120b0:	push   eax
   120b1:	push   DWORD PTR [ebp-0x100]
   120b7:	movs   WORD PTR es:[edi],WORD PTR ds:[esi]
   120b9:	push   DWORD PTR ds:0x1770c
   120bf:	call   DWORD PTR ds:0x17488
   120c5:	pop    edi
   120c6:	test   eax,eax
   120c8:	jne    0x120d6
   120ca:	mov    eax,DWORD PTR [ebp-0xfc]
   120d0:	mov    DWORD PTR [ebx+0x13c],eax
   120d6:	lea    eax,[ebp-0xfc]
   120dc:	push   eax
   120dd:	lea    eax,[ebp-0x138]
   120e3:	push   eax
   120e4:	push   DWORD PTR [ebp-0x100]
   120ea:	push   DWORD PTR ds:0x1770c
   120f0:	call   DWORD PTR ds:0x17488
   120f6:	test   eax,eax
   120f8:	jne    0x12109
   120fa:	cmp    DWORD PTR [ebp-0xfc],eax
   12100:	setne  al
   12103:	mov    BYTE PTR [ebx+0x148],al
   12109:	lea    eax,[ebp-0xfc]
   1210f:	push   eax
   12110:	lea    eax,[ebp-0x130]
   12116:	push   eax
   12117:	push   DWORD PTR [ebp-0x100]
   1211d:	push   DWORD PTR ds:0x1770c
   12123:	call   DWORD PTR ds:0x17488
   12129:	test   eax,eax
   1212b:	jne    0x1213c
   1212d:	cmp    DWORD PTR [ebp-0xfc],eax
   12133:	setne  al
   12136:	mov    BYTE PTR [ebx+0x149],al
   1213c:	lea    eax,[ebp-0xfc]
   12142:	push   eax
   12143:	lea    eax,[ebp-0x120]
   12149:	push   eax
   1214a:	push   DWORD PTR [ebp-0x100]
   12150:	push   DWORD PTR ds:0x1770c
   12156:	call   DWORD PTR ds:0x17488
   1215c:	test   eax,eax
   1215e:	jne    0x1216f
   12160:	cmp    DWORD PTR [ebp-0xfc],eax
   12166:	setne  al
   12169:	mov    BYTE PTR [ebx+0x14a],al
   1216f:	lea    eax,[ebp-0xfc]
   12175:	push   eax
   12176:	lea    eax,[ebp-0x110]
   1217c:	push   eax
   1217d:	push   DWORD PTR [ebp-0x100]
   12183:	push   DWORD PTR ds:0x1770c
   12189:	call   DWORD PTR ds:0x17488
   1218f:	test   eax,eax
   12191:	jne    0x121a2
   12193:	mov    eax,DWORD PTR [ebp-0xfc]
   12199:	shl    eax,0xa
   1219c:	mov    DWORD PTR [ebx+0x140],eax
   121a2:	lea    eax,[ebp-0xfc]
   121a8:	push   eax
   121a9:	lea    eax,[ebp-0x108]
   121af:	push   eax
   121b0:	push   DWORD PTR [ebp-0x100]
   121b6:	push   DWORD PTR ds:0x1770c
   121bc:	call   DWORD PTR ds:0x17488
   121c2:	test   eax,eax
   121c4:	jne    0x121d5
   121c6:	cmp    DWORD PTR [ebp-0xfc],eax
   121cc:	setne  al
   121cf:	mov    BYTE PTR [ebx+0x14b],al
   121d5:	lea    eax,[ebp-0xfc]
   121db:	push   eax
   121dc:	lea    eax,[ebp-0x128]
   121e2:	push   eax
   121e3:	push   DWORD PTR [ebp-0x100]
   121e9:	push   DWORD PTR ds:0x1770c
   121ef:	call   DWORD PTR ds:0x17488
   121f5:	test   eax,eax
   121f7:	jne    0x12208
   121f9:	mov    eax,DWORD PTR [ebp-0xfc]
   121ff:	shl    eax,0xa
   12202:	mov    DWORD PTR [ebx+0x144],eax
   12208:	push   DWORD PTR [ebp-0x100]
   1220e:	push   DWORD PTR ds:0x1770c
   12214:	call   DWORD PTR ds:0x17464
   1221a:	xor    esi,esi
   1221c:	cmp    BYTE PTR [ebx+0x148],0x0
   12223:	je     0x12245
   12225:	mov    DWORD PTR [ebx+0x14c],0x11eb8
   1222f:	mov    DWORD PTR [ebx+0x150],0x11e26
   12239:	mov    DWORD PTR [ebx+0x154],0x114f2
   12243:	jmp    0x12280
   12245:	cmp    BYTE PTR [ebx+0x149],0x0
   1224c:	je     0x1226e
   1224e:	mov    DWORD PTR [ebx+0x14c],0x114f2
   12258:	mov    DWORD PTR [ebx+0x150],0x11e8a
   12262:	mov    DWORD PTR [ebx+0x154],0x11eb8
   1226c:	jmp    0x12280
   1226e:	mov    DWORD PTR [ebx+0x14c],esi
   12274:	mov    DWORD PTR [ebx+0x150],esi
   1227a:	mov    DWORD PTR [ebx+0x154],esi
   12280:	mov    ecx,DWORD PTR [ebp-0x4]
   12283:	pop    esi
   12284:	xor    ecx,ebp
   12286:	pop    ebx
   12287:	call   0x145cc
   1228c:	leave
   1228d:	ret    0x4
   12290:	int3
   12291:	int3
   12292:	int3
   12293:	int3
   12294:	int3
   12295:	int3
   12296:	mov    edi,edi
   12298:	push   ebp
   12299:	mov    ebp,esp
   1229b:	sub    esp,0x5c
   1229e:	mov    edx,DWORD PTR [ebp+0x8]
   122a1:	mov    ecx,DWORD PTR ds:0x1770c
   122a7:	push   ebx
   122a8:	push   esi
   122a9:	push   edi
   122aa:	push   DWORD PTR ds:0x17034
   122b0:	call   DWORD PTR ds:0x173f0
   122b6:	mov    ebx,eax
   122b8:	xor    edi,edi
   122ba:	lea    esi,[ebx+0x2c]
   122bd:	mov    DWORD PTR [ebp+0x8],edi
   122c0:	cmp    DWORD PTR [esi],edi
   122c2:	jne    0x122dd
   122c4:	mov    eax,DWORD PTR [ebx]
   122c6:	push   esi
   122c7:	push   edi
   122c8:	push   eax
   122c9:	push   DWORD PTR ds:0x1770c
   122cf:	call   DWORD PTR ds:0x175d0
   122d5:	cmp    eax,edi
   122d7:	jne    0x1245d
   122dd:	lea    eax,[ebx+0x48]
   122e0:	push   eax
   122e1:	push   DWORD PTR [esi]
   122e3:	push   DWORD PTR ds:0x1770c
   122e9:	call   DWORD PTR ds:0x175d8
   122ef:	mov    eax,DWORD PTR [esi]
   122f1:	lea    ecx,[ebp+0x8]
   122f4:	push   ecx
   122f5:	push   edi
   122f6:	push   eax
   122f7:	push   DWORD PTR ds:0x1770c
   122fd:	call   DWORD PTR ds:0x175dc
   12303:	cmp    eax,0xc0000023
   12308:	jne    0x1245d
   1230e:	cmp    WORD PTR [ebp+0x8],di
   12312:	je     0x1245d
   12318:	push   0x8
   1231a:	pop    ecx
   1231b:	xor    eax,eax
   1231d:	lea    edi,[ebp-0x38]
   12320:	rep stos DWORD PTR es:[edi],eax
   12322:	inc    eax
   12323:	mov    DWORD PTR [ebp-0x2c],eax
   12326:	mov    DWORD PTR [ebp-0x28],eax
   12329:	mov    DWORD PTR [ebp-0x38],0x20
   12330:	mov    eax,DWORD PTR [ebx]
   12332:	mov    DWORD PTR [ebp-0x24],eax
   12335:	movzx  eax,WORD PTR [ebp+0x8]
   12339:	lea    edi,[ebx+0x38]
   1233c:	push   edi
   1233d:	lea    ecx,[ebp-0x4]
   12340:	push   ecx
   12341:	push   eax
   12342:	push   0x6d6f6355
   12347:	push   0x0
   12349:	lea    eax,[ebp-0x38]
   1234c:	push   eax
   1234d:	push   DWORD PTR ds:0x1770c
   12353:	call   DWORD PTR ds:0x173c8
   12359:	test   eax,eax
   1235b:	jne    0x1245d
   12361:	mov    edi,DWORD PTR [edi]
   12363:	mov    eax,DWORD PTR [esi]
   12365:	lea    ecx,[ebp+0x8]
   12368:	push   ecx
   12369:	push   edi
   1236a:	push   eax
   1236b:	push   DWORD PTR ds:0x1770c
   12371:	call   DWORD PTR ds:0x175dc
   12377:	test   eax,eax
   12379:	jne    0x1245d
   1237f:	push   DWORD PTR [esi]
   12381:	push   DWORD PTR ds:0x1770c
   12387:	call   DWORD PTR ds:0x175ec
   1238d:	sub    esp,0x14
   12390:	lea    edi,[ebp-0x18]
   12393:	push   0x5
   12395:	mov    BYTE PTR [ebx+0x136],al
   1239b:	mov    esi,edi
   1239d:	pop    ecx
   1239e:	cmp    al,0x1
   123a0:	jne    0x123c3
   123a2:	xor    eax,eax
   123a4:	stos   DWORD PTR es:[edi],eax
   123a5:	stos   DWORD PTR es:[edi],eax
   123a6:	stos   DWORD PTR es:[edi],eax
   123a7:	stos   DWORD PTR es:[edi],eax
   123a8:	stos   DWORD PTR es:[edi],eax
   123a9:	mov    edi,esp
   123ab:	mov    DWORD PTR [ebp-0x18],0x14
   123b2:	mov    DWORD PTR [ebp-0x14],0x2
   123b9:	push   ebx
   123ba:	rep movs DWORD PTR es:[edi],DWORD PTR ds:[esi]
   123bc:	call   0x115d4
   123c1:	jmp    0x123e2
   123c3:	xor    eax,eax
   123c5:	stos   DWORD PTR es:[edi],eax
   123c6:	stos   DWORD PTR es:[edi],eax
   123c7:	stos   DWORD PTR es:[edi],eax
   123c8:	stos   DWORD PTR es:[edi],eax
   123c9:	stos   DWORD PTR es:[edi],eax
   123ca:	mov    edi,esp
   123cc:	mov    DWORD PTR [ebp-0x18],0x14
   123d3:	mov    DWORD PTR [ebp-0x14],0x3
   123da:	push   ebx
   123db:	rep movs DWORD PTR es:[edi],DWORD PTR ds:[esi]
   123dd:	call   0x1168a
   123e2:	test   eax,eax
   123e4:	jne    0x1245d
   123e6:	cmp    DWORD PTR [ebx+0x40],eax
   123e9:	je     0x12458
   123eb:	cmp    DWORD PTR [ebx+0x44],eax
   123ee:	je     0x12458
   123f0:	mov    eax,DWORD PTR [ebx+0x30]
   123f3:	test   eax,eax
   123f5:	je     0x12407
   123f7:	push   eax
   123f8:	push   DWORD PTR ds:0x1770c
   123fe:	call   DWORD PTR ds:0x1765c
   12404:	mov    BYTE PTR [ebx+0x34],al
   12407:	push   ebx
   12408:	call   0x11498
   1240d:	test   eax,eax
   1240f:	jne    0x1245d
   12411:	cmp    BYTE PTR [ebx+0x14a],al
   12417:	je     0x1245d
   12419:	mov    edx,DWORD PTR [ebx+0x144]
   1241f:	push   0x9
   12421:	pop    ecx
   12422:	lea    edi,[ebp-0x5c]
   12425:	rep stos DWORD PTR es:[edi],eax
   12427:	lea    eax,[ebp-0x5c]
   1242a:	mov    DWORD PTR [ebp-0x5c],0x24
   12431:	mov    DWORD PTR [ebp-0x44],0x13710
   12438:	mov    DWORD PTR [ebp-0x40],ebx
   1243b:	mov    DWORD PTR [ebp-0x58],edx
   1243e:	mov    DWORD PTR [ebp-0x3c],0x13706
   12445:	mov    ebx,DWORD PTR [ebx+0x44]
   12448:	push   eax
   12449:	push   ebx
   1244a:	push   DWORD PTR ds:0x1770c
   12450:	call   DWORD PTR ds:0x17640
   12456:	jmp    0x1245d
   12458:	mov    eax,0xc0000001
   1245d:	pop    edi
   1245e:	pop    esi
   1245f:	pop    ebx
   12460:	leave
   12461:	ret    0xc
   12464:	int3
   12465:	int3
   12466:	int3
   12467:	int3
   12468:	int3
   12469:	int3
   1246a:	mov    edi,edi
   1246c:	push   ebp
   1246d:	mov    ebp,esp
   1246f:	mov    edx,DWORD PTR [ebp+0x8]
   12472:	mov    ecx,DWORD PTR ds:0x1770c
   12478:	push   esi
   12479:	push   DWORD PTR ds:0x17034
   1247f:	call   DWORD PTR ds:0x173f0
   12485:	mov    esi,eax
   12487:	lea    eax,[esi+0x7c]
   1248a:	xor    ecx,ecx
   1248c:	mov    DWORD PTR [ebp+0x8],eax
   1248f:	inc    ecx
   12490:	xchg   DWORD PTR [eax],ecx
   12492:	test   ecx,ecx
   12494:	je     0x124af
   12496:	push   0x80000011
   1249b:	push   DWORD PTR [ebp+0xc]
   1249e:	push   DWORD PTR ds:0x1770c
   124a4:	call   DWORD PTR ds:0x174e4
   124aa:	jmp    0x12597
   124af:	mov    DWORD PTR [esi+0x100],0x30
   124b9:	xor    eax,eax
   124bb:	push   ebx
   124bc:	push   edi
   124bd:	xor    ebx,ebx
   124bf:	mov    DWORD PTR [esi+0xc8],ebx
   124c5:	mov    DWORD PTR [esi+0x130],ebx
   124cb:	mov    DWORD PTR [esi+0x10],ebx
   124ce:	lea    edi,[esi+0xd8]
   124d4:	stos   DWORD PTR es:[edi],eax
   124d5:	stos   DWORD PTR es:[edi],eax
   124d6:	stos   DWORD PTR es:[edi],eax
   124d7:	stos   DWORD PTR es:[edi],eax
   124d8:	stos   DWORD PTR es:[edi],eax
   124d9:	xor    eax,eax
   124db:	lea    edi,[esi+0xd0]
   124e1:	stos   DWORD PTR es:[edi],eax
   124e2:	stos   WORD PTR es:[edi],ax
   124e4:	mov    DWORD PTR [esi+0xcc],0x800
   124ee:	xor    eax,eax
   124f0:	lea    edi,[esi+0xec]
   124f6:	stos   DWORD PTR es:[edi],eax
   124f7:	stos   DWORD PTR es:[edi],eax
   124f8:	stos   DWORD PTR es:[edi],eax
   124f9:	stos   DWORD PTR es:[edi],eax
   124fa:	xor    eax,eax
   124fc:	lea    edi,[esi+0xfc]
   12502:	stos   WORD PTR es:[edi],ax
   12504:	stos   BYTE PTR es:[edi],al
   12505:	xor    eax,eax
   12507:	lea    edi,[esi+0x11c]
   1250d:	stos   DWORD PTR es:[edi],eax
   1250e:	stos   DWORD PTR es:[edi],eax
   1250f:	stos   DWORD PTR es:[edi],eax
   12510:	stos   DWORD PTR es:[edi],eax
   12511:	stos   DWORD PTR es:[edi],eax
   12512:	lea    eax,[esi+0xb0]
   12518:	mov    BYTE PTR [esi+0x137],bl
   1251e:	mov    BYTE PTR [esi+0x138],bl
   12524:	mov    ecx,DWORD PTR [eax]
   12526:	push   esi
   12527:	mov    DWORD PTR [eax+0x8],ecx
   1252a:	mov    DWORD PTR [eax+0x4],ecx
   1252d:	call   0x114b6
   12532:	mov    edi,eax
   12534:	cmp    edi,ebx
   12536:	jne    0x1256d
   12538:	xor    eax,eax
   1253a:	inc    eax
   1253b:	lea    ecx,[esi+0x80]
   12541:	xchg   DWORD PTR [ecx],eax
   12543:	test   eax,eax
   12545:	jne    0x12553
   12547:	push   esi
   12548:	call   0x117c0
   1254d:	mov    edi,eax
   1254f:	cmp    edi,ebx
   12551:	jne    0x1256d
   12553:	push   0xffffffff
   12555:	push   0xfff0bdc0
   1255a:	push   DWORD PTR [esi+0x4]
   1255d:	push   DWORD PTR ds:0x1770c
   12563:	call   DWORD PTR ds:0x175c4
   12569:	cmp    edi,ebx
   1256b:	je     0x12576
   1256d:	mov    ecx,DWORD PTR [ebp+0x8]
   12570:	xor    eax,eax
   12572:	xchg   DWORD PTR [ecx],eax
   12574:	jmp    0x12585
   12576:	push   ebx
   12577:	push   DWORD PTR [esi]
   12579:	push   DWORD PTR ds:0x1770c
   1257f:	call   DWORD PTR ds:0x171f8
   12585:	push   edi
   12586:	push   DWORD PTR [ebp+0xc]
   12589:	push   DWORD PTR ds:0x1770c
   1258f:	call   DWORD PTR ds:0x174e4
   12595:	pop    edi
   12596:	pop    ebx
   12597:	pop    esi
   12598:	pop    ebp
   12599:	ret    0xc
   1259c:	int3
   1259d:	int3
   1259e:	int3
   1259f:	int3
   125a0:	int3
   125a1:	int3
   125a2:	mov    edi,edi
   125a4:	push   ebp
   125a5:	mov    ebp,esp
   125a7:	push   esi
   125a8:	mov    esi,DWORD PTR [ebp+0x8]
   125ab:	push   esi
   125ac:	call   0x11bc4
   125b1:	test   al,al
   125b3:	je     0x125b9
   125b5:	xor    eax,eax
   125b7:	jmp    0x125d0
   125b9:	mov    eax,DWORD PTR [esi+0x4]
   125bc:	mov    cl,BYTE PTR [ebp+0xc]
   125bf:	mov    BYTE PTR [eax],cl
   125c1:	push   DWORD PTR [esi+0x4]
   125c4:	push   esi
   125c5:	call   0x11b64
   125ca:	mov    DWORD PTR [esi+0x4],eax
   125cd:	xor    eax,eax
   125cf:	inc    eax
   125d0:	pop    esi
   125d1:	pop    ebp
   125d2:	ret    0x8
   125d5:	int3
   125d6:	int3
   125d7:	int3
   125d8:	int3
   125d9:	int3
   125da:	mov    edi,edi
   125dc:	push   ebp
   125dd:	mov    ebp,esp
   125df:	mov    edx,DWORD PTR [ebp+0x8]
   125e2:	push   edx
   125e3:	call   0x11ba8
   125e8:	test   al,al
   125ea:	je     0x125f0
   125ec:	xor    eax,eax
   125ee:	jmp    0x12609
   125f0:	mov    eax,DWORD PTR [edx+0x8]
   125f3:	mov    al,BYTE PTR [eax]
   125f5:	mov    ecx,DWORD PTR [ebp+0xc]
   125f8:	mov    BYTE PTR [ecx],al
   125fa:	push   DWORD PTR [edx+0x8]
   125fd:	push   edx
   125fe:	call   0x11b64
   12603:	mov    DWORD PTR [edx+0x8],eax
   12606:	xor    eax,eax
   12608:	inc    eax
   12609:	pop    ebp
   1260a:	ret    0x8
   1260d:	int3
   1260e:	int3
   1260f:	int3
   12610:	int3
   12611:	int3
   12612:	mov    edi,edi
   12614:	push   ebp
   12615:	mov    ebp,esp
   12617:	sub    esp,0x60
   1261a:	mov    ecx,DWORD PTR ds:0x1770c
   12620:	push   ebx
   12621:	push   esi
   12622:	mov    esi,DWORD PTR [ebp+0x8]
   12625:	push   edi
   12626:	mov    edx,esi
   12628:	call   DWORD PTR ds:0x173f8
   1262e:	push   0x158
   12633:	xor    ebx,ebx
   12635:	mov    edi,eax
   12637:	push   ebx
   12638:	push   esi
   12639:	mov    DWORD PTR [ebp-0x4],edi
   1263c:	call   0x14618
   12641:	add    esp,0xc
   12644:	push   esi
   12645:	mov    DWORD PTR [esi],edi
   12647:	mov    BYTE PTR [esi+0x34],0xff
   1264b:	call   0x11ee6
   12650:	mov    eax,DWORD PTR [esi+0x140]
   12656:	push   0x1
   12658:	mov    DWORD PTR [esi+0xc0],eax
   1265e:	push   ebx
   1265f:	lea    eax,[esi+0x60]
   12662:	push   eax
   12663:	call   DWORD PTR ds:0x16024
   12669:	push   esi
   1266a:	call   0x11ca6
   1266f:	mov    DWORD PTR [ebp+0x8],eax
   12672:	cmp    eax,ebx
   12674:	jne    0x12817
   1267a:	push   esi
   1267b:	call   0x11db2
   12680:	mov    DWORD PTR [ebp+0x8],eax
   12683:	cmp    eax,ebx
   12685:	jne    0x12817
   1268b:	push   esi
   1268c:	call   0x1119a
   12691:	mov    DWORD PTR [ebp+0x8],eax
   12694:	cmp    eax,ebx
   12696:	jne    0x12817
   1269c:	push   0x34
   1269e:	pop    edi
   1269f:	push   edi
   126a0:	lea    eax,[ebp-0x60]
   126a3:	push   ebx
   126a4:	push   eax
   126a5:	call   0x14618
   126aa:	add    esp,0xc
   126ad:	lea    eax,[esi+0x8]
   126b0:	push   eax
   126b1:	push   0x0
   126b3:	lea    eax,[ebp-0x60]
   126b6:	push   eax
   126b7:	push   DWORD PTR [ebp-0x4]
   126ba:	mov    DWORD PTR [ebp-0x60],edi
   126bd:	push   DWORD PTR ds:0x1770c
   126c3:	mov    ebx,0x132ee
   126c8:	mov    edi,0x13234
   126cd:	mov    DWORD PTR [ebp-0x58],0x2
   126d4:	mov    DWORD PTR [ebp-0x5c],0x3
   126db:	mov    DWORD PTR [ebp-0x3c],0x13258
   126e2:	mov    DWORD PTR [ebp-0x38],ebx
   126e5:	mov    DWORD PTR [ebp-0x34],edi
   126e8:	call   DWORD PTR ds:0x17328
   126ee:	mov    DWORD PTR [ebp+0x8],eax
   126f1:	test   eax,eax
   126f3:	jne    0x12817
   126f9:	push   0x34
   126fb:	push   eax
   126fc:	lea    eax,[ebp-0x60]
   126ff:	push   eax
   12700:	call   0x14618
   12705:	add    esp,0xc
   12708:	lea    eax,[esi+0xc]
   1270b:	push   eax
   1270c:	push   0x0
   1270e:	lea    eax,[ebp-0x60]
   12711:	push   eax
   12712:	push   DWORD PTR [ebp-0x4]
   12715:	mov    DWORD PTR [ebp-0x60],0x34
   1271c:	push   DWORD PTR ds:0x1770c
   12722:	mov    DWORD PTR [ebp-0x58],0x2
   12729:	mov    DWORD PTR [ebp-0x5c],0x3
   12730:	mov    DWORD PTR [ebp-0x3c],0x13258
   12737:	mov    DWORD PTR [ebp-0x38],ebx
   1273a:	mov    DWORD PTR [ebp-0x34],edi
   1273d:	call   DWORD PTR ds:0x17328
   12743:	mov    DWORD PTR [ebp+0x8],eax
   12746:	test   eax,eax
   12748:	jne    0x12817
   1274e:	push   0x34
   12750:	push   eax
   12751:	lea    eax,[ebp-0x60]
   12754:	push   eax
   12755:	call   0x14618
   1275a:	or     DWORD PTR [ebp-0x30],0xffffffff
   1275e:	add    esp,0xc
   12761:	push   0x2
   12763:	pop    eax
   12764:	mov    DWORD PTR [ebp-0x58],eax
   12767:	mov    DWORD PTR [ebp-0x5c],eax
   1276a:	lea    eax,[ebp-0xc]
   1276d:	push   eax
   1276e:	push   0x0
   12770:	lea    eax,[ebp-0x60]
   12773:	push   eax
   12774:	push   DWORD PTR [ebp-0x4]
   12777:	mov    DWORD PTR [ebp-0x60],0x34
   1277e:	push   DWORD PTR ds:0x1770c
   12784:	mov    BYTE PTR [ebp-0x53],0x1
   12788:	mov    DWORD PTR [ebp-0x4c],0x1314a
   1278f:	mov    DWORD PTR [ebp-0x48],0x131b6
   12796:	mov    DWORD PTR [ebp-0x3c],0x13258
   1279d:	mov    DWORD PTR [ebp-0x38],ebx
   127a0:	mov    DWORD PTR [ebp-0x44],0x12bc2
   127a7:	mov    DWORD PTR [ebp-0x34],edi
   127aa:	call   DWORD PTR ds:0x17328
   127b0:	mov    DWORD PTR [ebp+0x8],eax
   127b3:	test   eax,eax
   127b5:	jne    0x12817
   127b7:	push   0x8
   127b9:	pop    ecx
   127ba:	lea    edi,[ebp-0x2c]
   127bd:	rep stos DWORD PTR es:[edi],eax
   127bf:	inc    eax
   127c0:	mov    DWORD PTR [ebp-0x20],eax
   127c3:	mov    DWORD PTR [ebp-0x1c],eax
   127c6:	mov    eax,DWORD PTR [esi]
   127c8:	lea    ecx,[ebp-0x8]
   127cb:	push   ecx
   127cc:	mov    DWORD PTR [ebp-0x18],eax
   127cf:	mov    eax,DWORD PTR [esi+0xc0]
   127d5:	lea    ecx,[esi+0xc4]
   127db:	push   ecx
   127dc:	push   eax
   127dd:	push   0x6d6f6355
   127e2:	push   0x0
   127e4:	lea    eax,[ebp-0x2c]
   127e7:	push   eax
   127e8:	push   DWORD PTR ds:0x1770c
   127ee:	mov    DWORD PTR [ebp-0x2c],0x20
   127f5:	call   DWORD PTR ds:0x173c8
   127fb:	mov    DWORD PTR [ebp+0x8],eax
   127fe:	test   eax,eax
   12800:	jne    0x12817
   12802:	push   DWORD PTR [esi+0xc0]
   12808:	add    esi,0xb0
   1280e:	push   DWORD PTR [ebp-0x8]
   12811:	push   esi
   12812:	call   0x11b40
   12817:	mov    eax,DWORD PTR [ebp+0x8]
   1281a:	pop    edi
   1281b:	pop    esi
   1281c:	pop    ebx
   1281d:	leave
   1281e:	ret    0x4
   12821:	int3
   12822:	int3
   12823:	int3
   12824:	int3
   12825:	int3
   12826:	mov    edi,edi
   12828:	push   ebp
   12829:	mov    ebp,esp
   1282b:	sub    esp,0x1e0
   12831:	mov    eax,ds:0x17044
   12836:	xor    eax,ebp
   12838:	mov    DWORD PTR [ebp-0x4],eax
   1283b:	mov    eax,DWORD PTR [ebp+0xc]
   1283e:	and    DWORD PTR [ebp-0x10c],0x0
   12845:	mov    DWORD PTR [ebp-0x108],eax
   1284b:	xor    eax,eax
   1284d:	mov    WORD PTR [ebp-0x114],ax
   12854:	mov    eax,0x100
   12859:	push   ebx
   1285a:	mov    WORD PTR [ebp-0x112],ax
   12861:	lea    eax,[ebp-0x104]
   12867:	xor    ebx,ebx
   12869:	inc    ebx
   1286a:	mov    DWORD PTR [ebp-0x110],eax
   12870:	mov    eax,0x170c0
   12875:	mov    ecx,ebx
   12877:	lock xadd DWORD PTR [eax],ecx
   1287b:	inc    ecx
   1287c:	push   ecx
   1287d:	push   0x15776
   12882:	lea    eax,[ebp-0x114]
   12888:	push   0x1576a
   1288d:	push   eax
   1288e:	call   0x11148
   12893:	add    esp,0x10
   12896:	test   eax,eax
   12898:	jne    0x12bae
   1289e:	lea    eax,[ebp-0x114]
   128a4:	push   eax
   128a5:	push   DWORD PTR [ebp-0x108]
   128ab:	push   DWORD PTR ds:0x1770c
   128b1:	call   DWORD PTR ds:0x171d4
   128b7:	test   eax,eax
   128b9:	jne    0x12bae
   128bf:	push   esi
   128c0:	push   edi
   128c1:	push   0x1b
   128c3:	push   DWORD PTR [ebp-0x108]
   128c9:	push   DWORD PTR ds:0x1770c
   128cf:	call   DWORD PTR ds:0x171d0
   128d5:	push   0x44
   128d7:	pop    esi
   128d8:	push   esi
   128d9:	lea    eax,[ebp-0x1e0]
   128df:	push   0x0
   128e1:	push   eax
   128e2:	call   0x14618
   128e7:	add    esp,0xc
   128ea:	lea    eax,[ebp-0x1e0]
   128f0:	push   eax
   128f1:	push   DWORD PTR [ebp-0x108]
   128f7:	mov    DWORD PTR [ebp-0x1e0],esi
   128fd:	push   DWORD PTR ds:0x1770c
   12903:	mov    DWORD PTR [ebp-0x1dc],0x114fc
   1290d:	mov    DWORD PTR [ebp-0x1d4],0x11556
   12917:	mov    DWORD PTR [ebp-0x1cc],0x12296
   12921:	mov    DWORD PTR [ebp-0x1c8],0x11786
   1292b:	mov    DWORD PTR [ebp-0x1c0],0x115b0
   12935:	mov    DWORD PTR [ebp-0x1b0],0x115b0
   1293f:	call   DWORD PTR ds:0x171a4
   12945:	push   0x8
   12947:	pop    ecx
   12948:	xor    eax,eax
   1294a:	lea    edi,[ebp-0x134]
   12950:	rep stos DWORD PTR es:[edi],eax
   12952:	mov    eax,ds:0x1700c
   12957:	mov    DWORD PTR [ebp-0x118],eax
   1295d:	lea    eax,[ebp-0x134]
   12963:	push   eax
   12964:	push   DWORD PTR [ebp-0x108]
   1296a:	mov    DWORD PTR [ebp-0x134],0x20
   12974:	push   DWORD PTR ds:0x1770c
   1297a:	mov    DWORD PTR [ebp-0x128],ebx
   12980:	mov    DWORD PTR [ebp-0x124],ebx
   12986:	call   DWORD PTR ds:0x171e8
   1298c:	push   0x4
   1298e:	pop    edx
   1298f:	push   0x2
   12991:	pop    esi
   12992:	push   0x8
   12994:	pop    ecx
   12995:	xor    eax,eax
   12997:	lea    edi,[ebp-0x134]
   1299d:	rep stos DWORD PTR es:[edi],eax
   1299f:	lea    eax,[ebp-0x134]
   129a5:	push   eax
   129a6:	lea    eax,[ebp-0x17c]
   129ac:	push   eax
   129ad:	push   DWORD PTR [ebp-0x108]
   129b3:	mov    DWORD PTR [ebp-0x17c],0x18
   129bd:	push   DWORD PTR ds:0x1770c
   129c3:	mov    DWORD PTR [ebp-0x178],0x1246a
   129cd:	mov    DWORD PTR [ebp-0x174],0x11900
   129d7:	mov    DWORD PTR [ebp-0x170],0x119ba
   129e1:	mov    DWORD PTR [ebp-0x168],edx
   129e7:	mov    DWORD PTR [ebp-0x16c],esi
   129ed:	mov    DWORD PTR [ebp-0x134],0x20
   129f7:	mov    DWORD PTR [ebp-0x128],ebx
   129fd:	mov    DWORD PTR [ebp-0x124],edx
   12a03:	call   DWORD PTR ds:0x171e4
   12a09:	push   0x0
   12a0b:	push   0x0
   12a0d:	push   0x3
   12a0f:	push   0x13b5c
   12a14:	push   DWORD PTR [ebp-0x108]
   12a1a:	push   DWORD PTR ds:0x1770c
   12a20:	call   DWORD PTR ds:0x171ec
   12a26:	push   ebx
   12a27:	push   DWORD PTR [ebp-0x108]
   12a2d:	push   DWORD PTR ds:0x1770c
   12a33:	call   DWORD PTR ds:0x171c0
   12a39:	push   esi
   12a3a:	push   DWORD PTR [ebp-0x108]
   12a40:	push   DWORD PTR ds:0x1770c
   12a46:	call   DWORD PTR ds:0x171bc
   12a4c:	push   0x8
   12a4e:	pop    ecx
   12a4f:	xor    eax,eax
   12a51:	lea    edi,[ebp-0x19c]
   12a57:	rep stos DWORD PTR es:[edi],eax
   12a59:	mov    eax,ds:0x17034
   12a5e:	mov    DWORD PTR [ebp-0x180],eax
   12a64:	lea    eax,[ebp-0x10c]
   12a6a:	push   eax
   12a6b:	lea    eax,[ebp-0x19c]
   12a71:	push   eax
   12a72:	lea    eax,[ebp-0x108]
   12a78:	push   eax
   12a79:	push   DWORD PTR ds:0x1770c
   12a7f:	mov    DWORD PTR [ebp-0x19c],0x20
   12a89:	mov    DWORD PTR [ebp-0x190],ebx
   12a8f:	mov    DWORD PTR [ebp-0x198],0x11a42
   12a99:	mov    DWORD PTR [ebp-0x18c],esi
   12a9f:	call   DWORD PTR ds:0x171f4
   12aa5:	test   eax,eax
   12aa7:	jl     0x12bac
   12aad:	push   0x30
   12aaf:	pop    edi
   12ab0:	push   edi
   12ab1:	lea    eax,[ebp-0x164]
   12ab7:	push   0x0
   12ab9:	push   eax
   12aba:	call   0x14618
   12abf:	or     DWORD PTR [ebp-0x13c],0xffffffff
   12ac6:	or     DWORD PTR [ebp-0x138],0xffffffff
   12acd:	add    esp,0xc
   12ad0:	lea    eax,[ebp-0x164]
   12ad6:	push   eax
   12ad7:	push   DWORD PTR [ebp-0x10c]
   12add:	mov    DWORD PTR [ebp-0x164],edi
   12ae3:	push   DWORD PTR ds:0x1770c
   12ae9:	mov    DWORD PTR [ebp-0x160],esi
   12aef:	mov    DWORD PTR [ebp-0x15c],esi
   12af5:	mov    DWORD PTR [ebp-0x154],esi
   12afb:	mov    DWORD PTR [ebp-0x150],esi
   12b01:	mov    DWORD PTR [ebp-0x14c],esi
   12b07:	mov    DWORD PTR [ebp-0x144],esi
   12b0d:	mov    DWORD PTR [ebp-0x140],esi
   12b13:	mov    DWORD PTR [ebp-0x158],ebx
   12b19:	mov    DWORD PTR [ebp-0x148],ebx
   12b1f:	call   DWORD PTR ds:0x17214
   12b25:	push   DWORD PTR ds:0x17034
   12b2b:	mov    edx,DWORD PTR [ebp-0x10c]
   12b31:	mov    ecx,DWORD PTR ds:0x1770c
   12b37:	call   DWORD PTR ds:0x173f0
   12b3d:	mov    esi,eax
   12b3f:	push   esi
   12b40:	call   0x12612
   12b45:	test   eax,eax
   12b47:	jl     0x12bac
   12b49:	push   esi
   12b4a:	call   0x112cc
   12b4f:	test   eax,eax
   12b51:	jne    0x12bac
   12b53:	push   0x8
   12b55:	pop    ecx
   12b56:	lea    edi,[ebp-0x134]
   12b5c:	rep stos DWORD PTR es:[edi],eax
   12b5e:	mov    DWORD PTR [ebp-0x134],0x20
   12b68:	mov    DWORD PTR [ebp-0x128],ebx
   12b6e:	mov    DWORD PTR [ebp-0x124],ebx
   12b74:	mov    eax,DWORD PTR [esi]
   12b76:	mov    DWORD PTR [ebp-0x120],eax
   12b7c:	lea    eax,[esi+0xa8]
   12b82:	push   eax
   12b83:	lea    eax,[ebp-0x134]
   12b89:	push   eax
   12b8a:	push   DWORD PTR ds:0x1770c
   12b90:	call   DWORD PTR ds:0x175b4
   12b96:	mov    edi,eax
   12b98:	test   edi,edi
   12b9a:	jl     0x12bac
   12b9c:	call   DWORD PTR ds:0x16020
   12ba2:	add    eax,0x14
   12ba5:	inc    DWORD PTR [eax]
   12ba7:	mov    BYTE PTR [esi+0x73],bl
   12baa:	mov    eax,edi
   12bac:	pop    edi
   12bad:	pop    esi
   12bae:	mov    ecx,DWORD PTR [ebp-0x4]
   12bb1:	xor    ecx,ebp
   12bb3:	pop    ebx
   12bb4:	call   0x145cc
   12bb9:	leave
   12bba:	ret    0x8
   12bbd:	int3
   12bbe:	int3
   12bbf:	int3
   12bc0:	int3
   12bc1:	int3
   12bc2:	mov    edi,edi
   12bc4:	push   ebp
   12bc5:	mov    ebp,esp
   12bc7:	push   ecx
   12bc8:	push   ecx
   12bc9:	push   ebx
   12bca:	push   esi
   12bcb:	push   edi
   12bcc:	push   DWORD PTR [ebp+0x8]
   12bcf:	push   DWORD PTR ds:0x1770c
   12bd5:	call   DWORD PTR ds:0x1733c
   12bdb:	push   DWORD PTR ds:0x17034
   12be1:	mov    ecx,DWORD PTR ds:0x1770c
   12be7:	mov    edx,eax
   12be9:	call   DWORD PTR ds:0x173f0
   12bef:	mov    ecx,DWORD PTR [ebp+0x18]
   12bf2:	xor    edi,edi
   12bf4:	mov    ebx,eax
   12bf6:	mov    eax,0x1b004c
   12bfb:	mov    DWORD PTR [ebp-0x8],edi
   12bfe:	mov    DWORD PTR [ebp+0x8],edi
   12c01:	mov    DWORD PTR [ebp-0x4],edi
   12c04:	cmp    ecx,eax
   12c06:	ja     0x12e76
   12c0c:	je     0x12e45
   12c12:	add    eax,0xffffffdc
   12c15:	cmp    ecx,eax
   12c17:	ja     0x12d7d
   12c1d:	je     0x12d72
   12c23:	sub    ecx,0x1b0004
   12c29:	je     0x12d43
   12c2f:	push   0x4
   12c31:	pop    esi
   12c32:	sub    ecx,esi
   12c34:	je     0x12d14
   12c3a:	sub    ecx,esi
   12c3c:	je     0x12ce5
   12c42:	sub    ecx,0x10
   12c45:	je     0x12c8f
   12c47:	sub    ecx,esi
   12c49:	je     0x12c5e
   12c4b:	sub    ecx,esi
   12c4d:	jne    0x12ff7
   12c53:	push   ebx
   12c54:	call   0x14164
   12c59:	jmp    0x130cd
   12c5e:	lea    eax,[ebp-0x4]
   12c61:	push   eax
   12c62:	lea    eax,[ebp+0x8]
   12c65:	push   eax
   12c66:	push   0x14
   12c68:	pop    esi
   12c69:	push   esi
   12c6a:	push   DWORD PTR [ebp+0xc]
   12c6d:	push   DWORD PTR ds:0x1770c
   12c73:	call   DWORD PTR ds:0x17500
   12c79:	cmp    eax,edi
   12c7b:	jne    0x130cd
   12c81:	push   DWORD PTR [ebp+0x8]
   12c84:	push   ebx
   12c85:	call   0x140de
   12c8a:	jmp    0x130c6
   12c8f:	lea    eax,[ebp-0x4]
   12c92:	push   eax
   12c93:	lea    eax,[ebp+0x8]
   12c96:	push   eax
   12c97:	push   0x14
   12c99:	push   DWORD PTR [ebp+0xc]
   12c9c:	push   DWORD PTR ds:0x1770c
   12ca2:	call   DWORD PTR ds:0x174fc
   12ca8:	cmp    eax,edi
   12caa:	jne    0x130cd
   12cb0:	push   DWORD PTR [ebp+0x8]
   12cb3:	push   ebx
   12cb4:	call   0x141d0
   12cb9:	cmp    eax,edi
   12cbb:	jne    0x130cd
   12cc1:	mov    ecx,DWORD PTR [ebp+0x8]
   12cc4:	cmp    DWORD PTR [ecx],0xffffffff
   12cc7:	jne    0x12cd8
   12cc9:	cmp    DWORD PTR [ecx+0x4],edi
   12ccc:	jne    0x12cd8
   12cce:	cmp    DWORD PTR [ecx+0x8],edi
   12cd1:	jne    0x12cd8
   12cd3:	xor    ecx,ecx
   12cd5:	inc    ecx
   12cd6:	jmp    0x12cda
   12cd8:	xor    ecx,ecx
   12cda:	mov    BYTE PTR [ebx+0x134],cl
   12ce0:	jmp    0x130cd
   12ce5:	lea    eax,[ebp-0x4]
   12ce8:	push   eax
   12ce9:	lea    eax,[ebp+0x8]
   12cec:	push   eax
   12ced:	push   0x3
   12cef:	push   DWORD PTR [ebp+0xc]
   12cf2:	push   DWORD PTR ds:0x1770c
   12cf8:	call   DWORD PTR ds:0x174fc
   12cfe:	cmp    eax,edi
   12d00:	jne    0x130cd
   12d06:	push   DWORD PTR [ebp+0x8]
   12d09:	push   ebx
   12d0a:	call   0x141ac
   12d0f:	jmp    0x130cd
   12d14:	lea    eax,[ebp-0x4]
   12d17:	push   eax
   12d18:	lea    eax,[ebp+0x8]
   12d1b:	push   eax
   12d1c:	push   0x8
   12d1e:	push   DWORD PTR [ebp+0xc]
   12d21:	push   DWORD PTR ds:0x1770c
   12d27:	call   DWORD PTR ds:0x174fc
   12d2d:	cmp    eax,edi
   12d2f:	jne    0x130cd
   12d35:	push   DWORD PTR [ebp+0x8]
   12d38:	push   ebx
   12d39:	call   0x1420e
   12d3e:	jmp    0x130cd
   12d43:	lea    eax,[ebp-0x4]
   12d46:	push   eax
   12d47:	lea    eax,[ebp+0x8]
   12d4a:	push   eax
   12d4b:	push   0x4
   12d4d:	push   DWORD PTR [ebp+0xc]
   12d50:	push   DWORD PTR ds:0x1770c
   12d56:	call   DWORD PTR ds:0x174fc
   12d5c:	cmp    eax,edi
   12d5e:	jne    0x130cd
   12d64:	push   DWORD PTR [ebp+0x8]
   12d67:	push   ebx
   12d68:	call   0x14122
   12d6d:	jmp    0x130cd
   12d72:	push   ebx
   12d73:	call   0x14426
   12d78:	jmp    0x130cd
   12d7d:	sub    ecx,0x1b0030
   12d83:	je     0x12e3a
   12d89:	push   0x4
   12d8b:	pop    esi
   12d8c:	sub    ecx,esi
   12d8e:	je     0x12e2f
   12d94:	sub    ecx,0xc
   12d97:	je     0x12e01
   12d99:	sub    ecx,esi
   12d9b:	je     0x12dd3
   12d9d:	sub    ecx,esi
   12d9f:	jne    0x12ff7
   12da5:	lea    eax,[ebp-0x4]
   12da8:	push   eax
   12da9:	lea    eax,[ebp+0x8]
   12dac:	push   eax
   12dad:	push   esi
   12dae:	push   DWORD PTR [ebp+0xc]
   12db1:	push   DWORD PTR ds:0x1770c
   12db7:	call   DWORD PTR ds:0x17500
   12dbd:	cmp    eax,edi
   12dbf:	jne    0x130cd
   12dc5:	push   DWORD PTR [ebp+0xc]
   12dc8:	push   ebx
   12dc9:	call   0x144c8
   12dce:	jmp    0x130e7
   12dd3:	lea    eax,[ebp-0x4]
   12dd6:	push   eax
   12dd7:	lea    eax,[ebp+0x8]
   12dda:	push   eax
   12ddb:	push   esi
   12ddc:	push   DWORD PTR [ebp+0xc]
   12ddf:	push   DWORD PTR ds:0x1770c
   12de5:	call   DWORD PTR ds:0x174fc
   12deb:	cmp    eax,edi
   12ded:	jne    0x130cd
   12df3:	push   DWORD PTR [ebp+0x8]
   12df6:	push   ebx
   12df7:	call   0x1446a
   12dfc:	jmp    0x130cd
   12e01:	lea    eax,[ebp-0x4]
   12e04:	push   eax
   12e05:	lea    eax,[ebp+0x8]
   12e08:	push   eax
   12e09:	push   esi
   12e0a:	push   DWORD PTR [ebp+0xc]
   12e0d:	push   DWORD PTR ds:0x1770c
   12e13:	call   DWORD PTR ds:0x17500
   12e19:	cmp    eax,edi
   12e1b:	jne    0x130cd
   12e21:	push   DWORD PTR [ebp+0x8]
   12e24:	push   ebx
   12e25:	call   0x14104
   12e2a:	jmp    0x130c6
   12e2f:	push   ebx
   12e30:	call   0x114f2
   12e35:	jmp    0x130cd
   12e3a:	push   ebx
   12e3b:	call   0x114f2
   12e40:	jmp    0x130cd
   12e45:	lea    eax,[ebp-0x4]
   12e48:	push   eax
   12e49:	lea    eax,[ebp+0x8]
   12e4c:	push   eax
   12e4d:	push   0x4
   12e4f:	push   DWORD PTR [ebp+0xc]
   12e52:	push   DWORD PTR ds:0x1770c
   12e58:	call   DWORD PTR ds:0x174fc
   12e5e:	cmp    eax,edi
   12e60:	jne    0x130cd
   12e66:	mov    eax,DWORD PTR [ebp+0x8]
   12e69:	push   DWORD PTR [eax]
   12e6b:	push   ebx
   12e6c:	call   0x142f0
   12e71:	jmp    0x130cd
   12e76:	mov    eax,0x1b0064
   12e7b:	cmp    ecx,eax
   12e7d:	ja     0x12fd2
   12e83:	je     0x12fa3
   12e89:	sub    ecx,0x1b0050
   12e8f:	je     0x12f72
   12e95:	push   0x4
   12e97:	pop    esi
   12e98:	sub    ecx,esi
   12e9a:	je     0x12f41
   12ea0:	sub    ecx,esi
   12ea2:	je     0x12f10
   12ea4:	sub    ecx,esi
   12ea6:	je     0x12ee1
   12ea8:	sub    ecx,esi
   12eaa:	jne    0x12ff7
   12eb0:	lea    eax,[ebp-0x4]
   12eb3:	push   eax
   12eb4:	lea    eax,[ebp+0x8]
   12eb7:	push   eax
   12eb8:	push   0x10
   12eba:	pop    esi
   12ebb:	push   esi
   12ebc:	push   DWORD PTR [ebp+0xc]
   12ebf:	push   DWORD PTR ds:0x1770c
   12ec5:	call   DWORD PTR ds:0x17500
   12ecb:	cmp    eax,edi
   12ecd:	jne    0x130cd
   12ed3:	push   DWORD PTR [ebp+0x8]
   12ed6:	push   ebx
   12ed7:	call   0x13fe8
   12edc:	jmp    0x130c6
   12ee1:	lea    eax,[ebp-0x4]
   12ee4:	push   eax
   12ee5:	lea    eax,[ebp+0x8]
   12ee8:	push   eax
   12ee9:	push   0x6
   12eeb:	push   DWORD PTR [ebp+0xc]
   12eee:	push   DWORD PTR ds:0x1770c
   12ef4:	call   DWORD PTR ds:0x174fc
   12efa:	cmp    eax,edi
   12efc:	jne    0x130cd
   12f02:	push   DWORD PTR [ebp+0x8]
   12f05:	push   ebx
   12f06:	call   0x14140
   12f0b:	jmp    0x130cd
   12f10:	lea    eax,[ebp-0x4]
   12f13:	push   eax
   12f14:	lea    eax,[ebp+0x8]
   12f17:	push   eax
   12f18:	push   0x6
   12f1a:	pop    esi
   12f1b:	push   esi
   12f1c:	push   DWORD PTR [ebp+0xc]
   12f1f:	push   DWORD PTR ds:0x1770c
   12f25:	call   DWORD PTR ds:0x17500
   12f2b:	cmp    eax,edi
   12f2d:	jne    0x130cd
   12f33:	push   DWORD PTR [ebp+0x8]
   12f36:	push   ebx
   12f37:	call   0x13f9e
   12f3c:	jmp    0x130c6
   12f41:	lea    eax,[ebp-0x4]
   12f44:	push   eax
   12f45:	lea    eax,[ebp+0x8]
   12f48:	push   eax
   12f49:	push   0x3
   12f4b:	pop    esi
   12f4c:	push   esi
   12f4d:	push   DWORD PTR [ebp+0xc]
   12f50:	push   DWORD PTR ds:0x1770c
   12f56:	call   DWORD PTR ds:0x17500
   12f5c:	cmp    eax,edi
   12f5e:	jne    0x130cd
   12f64:	push   DWORD PTR [ebp+0x8]
   12f67:	push   ebx
   12f68:	call   0x1400c
   12f6d:	jmp    0x130c6
   12f72:	lea    eax,[ebp-0x4]
   12f75:	push   eax
   12f76:	lea    eax,[ebp+0x8]
   12f79:	push   eax
   12f7a:	push   0x4
   12f7c:	pop    esi
   12f7d:	push   esi
   12f7e:	push   DWORD PTR [ebp+0xc]
   12f81:	push   DWORD PTR ds:0x1770c
   12f87:	call   DWORD PTR ds:0x17500
   12f8d:	cmp    eax,edi
   12f8f:	jne    0x130cd
   12f95:	push   DWORD PTR [ebp+0x8]
   12f98:	push   ebx
   12f99:	call   0x13f80
   12f9e:	jmp    0x130c6
   12fa3:	lea    eax,[ebp-0x4]
   12fa6:	push   eax
   12fa7:	lea    eax,[ebp+0x8]
   12faa:	push   eax
   12fab:	push   0x10
   12fad:	push   DWORD PTR [ebp+0xc]
   12fb0:	push   DWORD PTR ds:0x1770c
   12fb6:	call   DWORD PTR ds:0x174fc
   12fbc:	cmp    eax,edi
   12fbe:	jne    0x130cd
   12fc4:	push   DWORD PTR [ebp+0x8]
   12fc7:	push   ebx
   12fc8:	call   0x14188
   12fcd:	jmp    0x130cd
   12fd2:	sub    ecx,0x1b0068
   12fd8:	je     0x1309e
   12fde:	push   0x4
   12fe0:	pop    esi
   12fe1:	sub    ecx,esi
   12fe3:	je     0x13074
   12fe9:	sub    ecx,0x8
   12fec:	je     0x1304a
   12fee:	sub    ecx,0x18
   12ff1:	je     0x1300c
   12ff3:	sub    ecx,esi
   12ff5:	je     0x13001
   12ff7:	mov    eax,0xc00000bb
   12ffc:	jmp    0x130d4
   13001:	push   ebx
   13002:	call   0x13f60
   13007:	jmp    0x130cd
   1300c:	lea    eax,[ebp-0x4]
   1300f:	push   eax
   13010:	lea    eax,[ebp+0x8]
   13013:	push   eax
   13014:	push   0x18
   13016:	push   DWORD PTR [ebp+0xc]
   13019:	push   DWORD PTR ds:0x1770c
   1301f:	call   DWORD PTR ds:0x17500
   13025:	cmp    eax,edi
   13027:	jne    0x130cd
   1302d:	push   DWORD PTR [ebp+0x8]
   13030:	push   ebx
   13031:	call   0x140b8
   13036:	cmp    eax,edi
   13038:	jne    0x130cd
   1303e:	mov    DWORD PTR [ebp-0x8],0x18
   13045:	jmp    0x130cd
   1304a:	lea    eax,[ebp-0x4]
   1304d:	push   eax
   1304e:	lea    eax,[ebp+0x8]
   13051:	push   eax
   13052:	push   0x40
   13054:	pop    esi
   13055:	push   esi
   13056:	push   DWORD PTR [ebp+0xc]
   13059:	push   DWORD PTR ds:0x1770c
   1305f:	call   DWORD PTR ds:0x17500
   13065:	cmp    eax,edi
   13067:	jne    0x130cd
   13069:	push   DWORD PTR [ebp+0x8]
   1306c:	push   ebx
   1306d:	call   0x1404e
   13072:	jmp    0x130c6
   13074:	lea    eax,[ebp-0x4]
   13077:	push   eax
   13078:	lea    eax,[ebp+0x8]
   1307b:	push   eax
   1307c:	push   0x14
   1307e:	pop    esi
   1307f:	push   esi
   13080:	push   DWORD PTR [ebp+0xc]
   13083:	push   DWORD PTR ds:0x1770c
   13089:	call   DWORD PTR ds:0x17500
   1308f:	cmp    eax,edi
   13091:	jne    0x130cd
   13093:	push   DWORD PTR [ebp+0x8]
   13096:	push   ebx
   13097:	call   0x13fc2
   1309c:	jmp    0x130c6
   1309e:	lea    eax,[ebp-0x4]
   130a1:	push   eax
   130a2:	lea    eax,[ebp+0x8]
   130a5:	push   eax
   130a6:	push   0x4
   130a8:	pop    esi
   130a9:	push   esi
   130aa:	push   DWORD PTR [ebp+0xc]
   130ad:	push   DWORD PTR ds:0x1770c
   130b3:	call   DWORD PTR ds:0x17500
   130b9:	cmp    eax,edi
   130bb:	jne    0x130cd
   130bd:	push   DWORD PTR [ebp+0x8]
   130c0:	push   ebx
   130c1:	call   0x14030
   130c6:	cmp    eax,edi
   130c8:	jne    0x130cd
   130ca:	mov    DWORD PTR [ebp-0x8],esi
   130cd:	cmp    eax,0x103
   130d2:	je     0x130e7
   130d4:	push   DWORD PTR [ebp-0x8]
   130d7:	push   eax
   130d8:	push   DWORD PTR [ebp+0xc]
   130db:	push   DWORD PTR ds:0x1770c
   130e1:	call   DWORD PTR ds:0x174ec
   130e7:	pop    edi
   130e8:	pop    esi
   130e9:	pop    ebx
   130ea:	leave
   130eb:	ret    0x14
   130ee:	int3
   130ef:	int3
   130f0:	int3
   130f1:	int3
   130f2:	int3
   130f3:	int3
   130f4:	mov    edi,edi
   130f6:	push   ebp
   130f7:	mov    ebp,esp
   130f9:	push   DWORD PTR ds:0x1700c
   130ff:	mov    edx,DWORD PTR [ebp+0x8]
   13102:	mov    ecx,DWORD PTR ds:0x1770c
   13108:	call   DWORD PTR ds:0x173f0
   1310e:	mov    eax,DWORD PTR [eax]
   13110:	push   DWORD PTR ds:0x17034
   13116:	mov    ecx,DWORD PTR ds:0x1770c
   1311c:	mov    edx,eax
   1311e:	call   DWORD PTR ds:0x173f0
   13124:	mov    ecx,DWORD PTR [eax+0x14]
   13127:	test   ecx,ecx
   13129:	je     0x13141
   1312b:	and    DWORD PTR [eax+0x14],0x0
   1312f:	push   0xc0000120
   13134:	push   ecx
   13135:	push   DWORD PTR ds:0x1770c
   1313b:	call   DWORD PTR ds:0x174e4
   13141:	pop    ebp
   13142:	ret    0x4
   13145:	int3
   13146:	int3
   13147:	int3
   13148:	int3
   13149:	int3
   1314a:	mov    edi,edi
   1314c:	push   ebp
   1314d:	mov    ebp,esp
   1314f:	push   esi
   13150:	push   DWORD PTR [ebp+0x8]
   13153:	push   DWORD PTR ds:0x1770c
   13159:	call   DWORD PTR ds:0x1733c
   1315f:	push   DWORD PTR ds:0x17034
   13165:	mov    ecx,DWORD PTR ds:0x1770c
   1316b:	mov    edx,eax
   1316d:	call   DWORD PTR ds:0x173f0
   13173:	mov    esi,eax
   13175:	push   DWORD PTR [esi+0x8]
   13178:	push   DWORD PTR [ebp+0xc]
   1317b:	push   DWORD PTR ds:0x1770c
   13181:	call   DWORD PTR ds:0x1752c
   13187:	test   eax,eax
   13189:	je     0x1319d
   1318b:	push   eax
   1318c:	push   DWORD PTR [ebp+0xc]
   1318f:	push   DWORD PTR ds:0x1770c
   13195:	call   DWORD PTR ds:0x174e4
   1319b:	jmp    0x131ac
   1319d:	push   DWORD PTR [esi+0x18]
   131a0:	push   DWORD PTR ds:0x1770c
   131a6:	call   DWORD PTR ds:0x17288
   131ac:	pop    esi
   131ad:	pop    ebp
   131ae:	ret    0xc
   131b1:	int3
   131b2:	int3
   131b3:	int3
   131b4:	int3
   131b5:	int3
   131b6:	mov    edi,edi
   131b8:	push   ebp
   131b9:	mov    ebp,esp
   131bb:	push   esi
   131bc:	push   edi
   131bd:	push   DWORD PTR [ebp+0x8]
   131c0:	push   DWORD PTR ds:0x1770c
   131c6:	call   DWORD PTR ds:0x1733c
   131cc:	push   DWORD PTR ds:0x17034
   131d2:	mov    ecx,DWORD PTR ds:0x1770c
   131d8:	mov    edx,eax
   131da:	call   DWORD PTR ds:0x173f0
   131e0:	mov    edi,DWORD PTR [ebp+0x10]
   131e3:	mov    esi,eax
   131e5:	push   DWORD PTR [esi+0xc]
   131e8:	add    DWORD PTR [esi+0xe4],edi
   131ee:	push   DWORD PTR [ebp+0xc]
   131f1:	push   DWORD PTR ds:0x1770c
   131f7:	call   DWORD PTR ds:0x1752c
   131fd:	test   eax,eax
   131ff:	je     0x13219
   13201:	push   eax
   13202:	push   DWORD PTR [ebp+0xc]
   13205:	push   DWORD PTR ds:0x1770c
   1320b:	call   DWORD PTR ds:0x174e4
   13211:	sub    DWORD PTR [esi+0xe4],edi
   13217:	jmp    0x13228
   13219:	push   DWORD PTR [esi+0x1c]
   1321c:	push   DWORD PTR ds:0x1770c
   13222:	call   DWORD PTR ds:0x17288
   13228:	pop    edi
   13229:	pop    esi
   1322a:	pop    ebp
   1322b:	ret    0xc
   1322e:	int3
   1322f:	int3
   13230:	int3
   13231:	int3
   13232:	int3
   13233:	int3
   13234:	mov    edi,edi
   13236:	push   ebp
   13237:	mov    ebp,esp
   13239:	push   0x0
   1323b:	push   0xc0000120
   13240:	push   DWORD PTR [ebp+0xc]
   13243:	push   DWORD PTR ds:0x1770c
   13249:	call   DWORD PTR ds:0x174ec
   1324f:	pop    ebp
   13250:	ret    0x8
   13253:	int3
   13254:	int3
   13255:	int3
   13256:	int3
   13257:	int3
   13258:	mov    edi,edi
   1325a:	push   ebp
   1325b:	mov    ebp,esp
   1325d:	mov    ecx,DWORD PTR ds:0x1770c
   13263:	push   ebx
   13264:	push   esi
   13265:	push   edi
   13266:	mov    edi,DWORD PTR [ebp+0xc]
   13269:	push   DWORD PTR ds:0x1700c
   1326f:	mov    edx,edi
   13271:	call   DWORD PTR ds:0x173f0
   13277:	push   DWORD PTR [ebp+0x8]
   1327a:	mov    esi,eax
   1327c:	push   DWORD PTR ds:0x1770c
   13282:	call   DWORD PTR ds:0x1733c
   13288:	push   DWORD PTR ds:0x17034
   1328e:	mov    ecx,DWORD PTR ds:0x1770c
   13294:	mov    edx,eax
   13296:	call   DWORD PTR ds:0x173f0
   1329c:	mov    ebx,DWORD PTR [ebp+0x10]
   1329f:	test   ebx,0x10000000
   132a5:	je     0x132b9
   132a7:	cmp    DWORD PTR [esi+0x4],0x0
   132ab:	je     0x132b3
   132ad:	push   edi
   132ae:	call   0x11088
   132b3:	and    ebx,0xefffffff
   132b9:	test   bl,0x2
   132bc:	je     0x132cd
   132be:	push   edi
   132bf:	push   DWORD PTR ds:0x1770c
   132c5:	call   DWORD PTR ds:0x174d0
   132cb:	jmp    0x132e1
   132cd:	test   bl,0x1
   132d0:	je     0x132e1
   132d2:	push   0x0
   132d4:	push   edi
   132d5:	push   DWORD PTR ds:0x1770c
   132db:	call   DWORD PTR ds:0x17538
   132e1:	pop    edi
   132e2:	pop    esi
   132e3:	pop    ebx
   132e4:	pop    ebp
   132e5:	ret    0xc
   132e8:	int3
   132e9:	int3
   132ea:	int3
   132eb:	int3
   132ec:	int3
   132ed:	int3
   132ee:	mov    edi,edi
   132f0:	push   ebp
   132f1:	mov    ebp,esp
   132f3:	push   DWORD PTR ds:0x1700c
   132f9:	mov    edx,DWORD PTR [ebp+0xc]
   132fc:	mov    ecx,DWORD PTR ds:0x1770c
   13302:	call   DWORD PTR ds:0x173f0
   13308:	mov    eax,DWORD PTR [eax+0x4]
   1330b:	test   eax,eax
   1330d:	je     0x13318
   1330f:	push   eax
   13310:	push   DWORD PTR [ebp+0xc]
   13313:	call   0x1102a
   13318:	pop    ebp
   13319:	ret    0x8
   1331c:	int3
   1331d:	int3
   1331e:	int3
   1331f:	int3
   13320:	int3
   13321:	int3
   13322:	mov    edi,edi
   13324:	push   ebp
   13325:	mov    ebp,esp
   13327:	mov    ecx,DWORD PTR [ebp+0x8]
   1332a:	mov    eax,DWORD PTR [ecx+0x128]
   13330:	imul   eax,DWORD PTR [ebp+0xc]
   13334:	add    eax,DWORD PTR [ecx+0x12c]
   1333a:	xor    edx,edx
   1333c:	pop    ebp
   1333d:	ret    0x8
   13340:	int3
   13341:	int3
   13342:	int3
   13343:	int3
   13344:	int3
   13345:	int3
   13346:	mov    edi,edi
   13348:	push   ebp
   13349:	mov    ebp,esp
   1334b:	push   ebx
   1334c:	push   esi
   1334d:	mov    esi,DWORD PTR [ebp+0x8]
   13350:	push   edi
   13351:	mov    edi,DWORD PTR [esi+0x90]
   13357:	sub    edi,DWORD PTR [esi+0x94]
   1335d:	je     0x13399
   1335f:	lea    ebx,[esi+0xb0]
   13365:	push   ebx
   13366:	call   0x11ba8
   1336b:	test   al,al
   1336d:	jne    0x13399
   1336f:	lea    eax,[ebp+0xb]
   13372:	push   eax
   13373:	push   ebx
   13374:	call   0x125da
   13379:	mov    dl,BYTE PTR [ebp+0xb]
   1337c:	lea    eax,[esi+0x8c]
   13382:	mov    ecx,DWORD PTR [eax]
   13384:	mov    BYTE PTR [ecx],dl
   13386:	inc    DWORD PTR [eax]
   13388:	inc    DWORD PTR [esi+0x94]
   1338e:	dec    edi
   1338f:	dec    DWORD PTR [esi+0xe0]
   13395:	test   edi,edi
   13397:	ja     0x13365
   13399:	lea    edi,[esi+0xb0]
   1339f:	push   edi
   133a0:	call   0x11bfc
   133a5:	push   edi
   133a6:	mov    ebx,eax
   133a8:	call   0x11be6
   133ad:	mov    ecx,eax
   133af:	mov    eax,ebx
   133b1:	imul   eax,eax,0x64
   133b4:	xor    edx,edx
   133b6:	div    ecx
   133b8:	cmp    eax,0x32
   133bb:	jae    0x133d2
   133bd:	xor    eax,eax
   133bf:	lea    ecx,[esi+0xc8]
   133c5:	xchg   DWORD PTR [ecx],eax
   133c7:	cmp    eax,0x1
   133ca:	jne    0x133d2
   133cc:	push   esi
   133cd:	call   0x117c0
   133d2:	mov    eax,DWORD PTR [esi+0x94]
   133d8:	cmp    eax,DWORD PTR [esi+0x90]
   133de:	pop    edi
   133df:	sbb    al,al
   133e1:	pop    esi
   133e2:	inc    al
   133e4:	pop    ebx
   133e5:	pop    ebp
   133e6:	ret    0x4
   133e9:	int3
   133ea:	int3
   133eb:	int3
   133ec:	int3
   133ed:	int3
   133ee:	mov    edi,edi
   133f0:	push   ebp
   133f1:	mov    ebp,esp
   133f3:	mov    eax,DWORD PTR [ebp+0x8]
   133f6:	sub    esp,0x14
   133f9:	push   esi
   133fa:	push   edi
   133fb:	push   0x5
   133fd:	pop    ecx
   133fe:	lea    esi,[eax+0x11c]
   13404:	lea    edi,[ebp-0x14]
   13407:	rep movs DWORD PTR es:[edi],DWORD PTR ds:[esi]
   13409:	cmp    DWORD PTR [ebp-0x14],0xffffffff
   1340d:	pop    edi
   1340e:	pop    esi
   1340f:	jne    0x13437
   13411:	cmp    DWORD PTR [ebp-0x10],0x0
   13415:	mov    ecx,DWORD PTR [ebp-0xc]
   13418:	jne    0x13422
   1341a:	test   ecx,ecx
   1341c:	jne    0x13422
   1341e:	mov    al,0x1
   13420:	jmp    0x13439
   13422:	cmp    DWORD PTR [ebp-0x10],0xffffffff
   13426:	jne    0x13437
   13428:	dec    ecx
   13429:	cmp    ecx,0xfffffffd
   1342c:	ja     0x13437
   1342e:	cmp    DWORD PTR [eax+0x94],0x0
   13435:	ja     0x1341e
   13437:	xor    al,al
   13439:	leave
   1343a:	ret    0x4
   1343d:	int3
   1343e:	int3
   1343f:	int3
   13440:	int3
   13441:	int3
   13442:	mov    edi,edi
   13444:	push   ebp
   13445:	mov    ebp,esp
   13447:	sub    esp,0x14
   1344a:	push   ebx
   1344b:	mov    ebx,DWORD PTR [ebp+0x8]
   1344e:	mov    eax,DWORD PTR [ebx+0x94]
   13454:	push   esi
   13455:	push   edi
   13456:	push   0x5
   13458:	lea    esi,[ebx+0x11c]
   1345e:	pop    ecx
   1345f:	lea    edi,[ebp-0x14]
   13462:	rep movs DWORD PTR es:[edi],DWORD PTR ds:[esi]
   13464:	cmp    DWORD PTR [ebp-0x10],0xffffffff
   13468:	mov    ecx,DWORD PTR [ebp-0x14]
   1346b:	mov    edi,DWORD PTR [ebp-0xc]
   1346e:	mov    DWORD PTR [ebp+0x8],ecx
   13471:	je     0x13480
   13473:	mov    edi,DWORD PTR [ebx+0x90]
   13479:	imul   edi,DWORD PTR [ebp-0x10]
   1347d:	add    edi,DWORD PTR [ebp-0xc]
   13480:	cmp    ecx,0xffffffff
   13483:	jne    0x13496
   13485:	xor    ecx,ecx
   13487:	cmp    DWORD PTR [ebp-0xc],ecx
   1348a:	jne    0x13496
   1348c:	cmp    DWORD PTR [ebp-0x10],ecx
   1348f:	jne    0x13496
   13491:	mov    DWORD PTR [ebp+0x8],ecx
   13494:	xor    edi,edi
   13496:	test   eax,eax
   13498:	jne    0x1349d
   1349a:	and    DWORD PTR [ebp+0x8],eax
   1349d:	cmp    DWORD PTR [ebp+0x8],0x0
   134a1:	jne    0x134b6
   134a3:	or     DWORD PTR [ebx+0x98],0xffffffff
   134aa:	mov    DWORD PTR [ebx+0x9c],0x7fffffff
   134b4:	jmp    0x134d2
   134b6:	lea    esi,[ebx+0x98]
   134bc:	push   esi
   134bd:	call   DWORD PTR ds:0x16028
   134c3:	mov    eax,DWORD PTR [ebp+0x8]
   134c6:	mov    ecx,0x2710
   134cb:	mul    ecx
   134cd:	add    DWORD PTR [esi],eax
   134cf:	adc    DWORD PTR [esi+0x4],edx
   134d2:	test   edi,edi
   134d4:	jne    0x134e9
   134d6:	or     DWORD PTR [ebx+0xa0],0xffffffff
   134dd:	mov    DWORD PTR [ebx+0xa4],0x7fffffff
   134e7:	jmp    0x13504
   134e9:	lea    esi,[ebx+0xa0]
   134ef:	push   esi
   134f0:	call   DWORD PTR ds:0x16028
   134f6:	mov    eax,edi
   134f8:	mov    ecx,0x2710
   134fd:	mul    ecx
   134ff:	add    DWORD PTR [esi],eax
   13501:	adc    DWORD PTR [esi+0x4],edx
   13504:	pop    edi
   13505:	pop    esi
   13506:	pop    ebx
   13507:	leave
   13508:	ret    0x4
   1350b:	int3
   1350c:	int3
   1350d:	int3
   1350e:	int3
   1350f:	int3
   13510:	mov    edi,edi
   13512:	push   ebp
   13513:	mov    ebp,esp
   13515:	mov    edx,DWORD PTR [ebp+0x8]
   13518:	mov    ecx,DWORD PTR ds:0x1770c
   1351e:	push   esi
   1351f:	push   DWORD PTR ds:0x1700c
   13525:	call   DWORD PTR ds:0x173f0
   1352b:	mov    eax,DWORD PTR [eax]
   1352d:	push   DWORD PTR ds:0x17034
   13533:	mov    ecx,DWORD PTR ds:0x1770c
   13539:	mov    edx,eax
   1353b:	call   DWORD PTR ds:0x173f0
   13541:	mov    esi,eax
   13543:	or     DWORD PTR [esi+0x98],0xffffffff
   1354a:	or     DWORD PTR [esi+0xa0],0xffffffff
   13551:	xor    eax,eax
   13553:	push   0xc0000120
   13558:	push   DWORD PTR [ebp+0x8]
   1355b:	mov    DWORD PTR [esi+0x88],eax
   13561:	mov    DWORD PTR [esi+0x8c],eax
   13567:	mov    DWORD PTR [esi+0x94],eax
   1356d:	mov    DWORD PTR [esi+0x90],eax
   13573:	mov    eax,0x7fffffff
   13578:	mov    DWORD PTR [esi+0x9c],eax
   1357e:	mov    DWORD PTR [esi+0xa4],eax
   13584:	push   DWORD PTR ds:0x1770c
   1358a:	call   DWORD PTR ds:0x174e4
   13590:	push   DWORD PTR [esi+0x18]
   13593:	push   DWORD PTR ds:0x1770c
   13599:	call   DWORD PTR ds:0x17288
   1359f:	pop    esi
   135a0:	pop    ebp
   135a1:	ret    0x4
   135a4:	int3
   135a5:	int3
   135a6:	int3
   135a7:	int3
   135a8:	int3
   135a9:	int3
   135aa:	mov    edi,edi
   135ac:	push   ebp
   135ad:	mov    ebp,esp
   135af:	push   esi
   135b0:	push   edi
   135b1:	push   DWORD PTR [ebp+0x8]
   135b4:	push   DWORD PTR ds:0x1770c
   135ba:	call   DWORD PTR ds:0x17290
   135c0:	push   DWORD PTR ds:0x17034
   135c6:	mov    ecx,DWORD PTR ds:0x1770c
   135cc:	mov    edx,eax
   135ce:	call   DWORD PTR ds:0x173f0
   135d4:	mov    esi,eax
   135d6:	xor    edi,edi
   135d8:	cmp    DWORD PTR [esi+0x88],edi
   135de:	je     0x13664
   135e4:	push   esi
   135e5:	call   0x13346
   135ea:	test   al,al
   135ec:	jne    0x135fc
   135ee:	push   esi
   135ef:	call   0x133ee
   135f4:	test   al,al
   135f6:	je     0x136f4
   135fc:	mov    eax,DWORD PTR [esi+0x88]
   13602:	mov    DWORD PTR [ebp+0x8],eax
   13605:	mov    DWORD PTR [esi+0x88],edi
   1360b:	push   DWORD PTR [ebp+0x8]
   1360e:	push   DWORD PTR ds:0x1770c
   13614:	call   DWORD PTR ds:0x174c8
   1361a:	cmp    eax,edi
   1361c:	jl     0x13636
   1361e:	push   DWORD PTR [esi+0x94]
   13624:	push   edi
   13625:	push   DWORD PTR [ebp+0x8]
   13628:	push   DWORD PTR ds:0x1770c
   1362e:	call   DWORD PTR ds:0x174ec
   13634:	jmp    0x1364d
   13636:	cmp    eax,0xc0000120
   1363b:	je     0x1364d
   1363d:	push   eax
   1363e:	push   DWORD PTR [ebp+0x8]
   13641:	push   DWORD PTR ds:0x1770c
   13647:	call   DWORD PTR ds:0x174e4
   1364d:	mov    DWORD PTR [esi+0x90],edi
   13653:	mov    DWORD PTR [esi+0x94],edi
   13659:	mov    DWORD PTR [esi+0x8c],edi
   1365f:	jmp    0x135d8
   13664:	mov    eax,DWORD PTR [esi+0x8]
   13667:	lea    ecx,[ebp+0x8]
   1366a:	push   ecx
   1366b:	push   eax
   1366c:	push   DWORD PTR ds:0x1770c
   13672:	call   DWORD PTR ds:0x17340
   13678:	test   eax,eax
   1367a:	jne    0x136fa
   1367c:	lea    eax,[esi+0x90]
   13682:	push   eax
   13683:	lea    eax,[esi+0x8c]
   13689:	push   eax
   1368a:	push   0x1
   1368c:	push   DWORD PTR [ebp+0x8]
   1368f:	push   DWORD PTR ds:0x1770c
   13695:	call   DWORD PTR ds:0x17500
   1369b:	cmp    eax,edi
   1369d:	je     0x136b4
   1369f:	push   eax
   136a0:	push   DWORD PTR [ebp+0x8]
   136a3:	push   DWORD PTR ds:0x1770c
   136a9:	call   DWORD PTR ds:0x174e4
   136af:	jmp    0x135d8
   136b4:	push   DWORD PTR ds:0x1700c
   136ba:	mov    edx,DWORD PTR [ebp+0x8]
   136bd:	mov    ecx,DWORD PTR ds:0x1770c
   136c3:	call   DWORD PTR ds:0x173f0
   136c9:	mov    DWORD PTR [eax],edi
   136cb:	mov    DWORD PTR [eax+0x4],edi
   136ce:	mov    DWORD PTR [eax+0x8],edi
   136d1:	mov    ecx,DWORD PTR [esi]
   136d3:	push   0x13510
   136d8:	mov    DWORD PTR [eax],ecx
   136da:	push   DWORD PTR [ebp+0x8]
   136dd:	call   0x1102a
   136e2:	cmp    eax,edi
   136e4:	jne    0x1369f
   136e6:	mov    eax,DWORD PTR [ebp+0x8]
   136e9:	mov    DWORD PTR [esi+0x88],eax
   136ef:	jmp    0x135d8
   136f4:	push   esi
   136f5:	call   0x13442
   136fa:	pop    edi
   136fb:	pop    esi
   136fc:	pop    ebp
   136fd:	ret    0x4
   13700:	int3
   13701:	int3
   13702:	int3
   13703:	int3
   13704:	int3
   13705:	int3
   13706:	mov    al,0x1
   13708:	ret    0xc
   1370b:	int3
   1370c:	int3
   1370d:	int3
   1370e:	int3
   1370f:	int3
   13710:	mov    edi,edi
   13712:	push   ebp
   13713:	mov    ebp,esp
   13715:	push   ecx
   13716:	push   ebx
   13717:	push   esi
   13718:	mov    esi,DWORD PTR [ebp+0x14]
   1371b:	push   edi
   1371c:	push   DWORD PTR [esi]
   1371e:	xor    ebx,ebx
   13720:	push   DWORD PTR ds:0x1770c
   13726:	mov    DWORD PTR [ebp-0x4],ebx
   13729:	call   DWORD PTR ds:0x175a0
   1372f:	push   ebx
   13730:	push   DWORD PTR [ebp+0xc]
   13733:	push   DWORD PTR ds:0x1770c
   13739:	call   DWORD PTR ds:0x173d0
   1373f:	mov    edi,eax
   13741:	mov    DWORD PTR [ebp+0x14],ebx
   13744:	cmp    DWORD PTR [ebp+0x10],ebx
   13747:	jbe    0x137da
   1374d:	mov    bl,BYTE PTR [edi]
   1374f:	mov    BYTE PTR [ebp+0xc],bl
   13752:	push   DWORD PTR [ebp+0xc]
   13755:	lea    eax,[esi+0xb0]
   1375b:	push   eax
   1375c:	call   0x125a2
   13761:	test   eax,eax
   13763:	je     0x137ce
   13765:	inc    DWORD PTR [esi+0x104]
   1376b:	mov    al,BYTE PTR [esi+0xd3]
   13771:	inc    DWORD PTR [esi+0xe0]
   13777:	cmp    bl,al
   13779:	jne    0x13783
   1377b:	test   al,al
   1377d:	je     0x13783
   1377f:	or     DWORD PTR [ebp-0x4],0x2
   13783:	mov    ecx,DWORD PTR ds:0x17040
   13789:	movsx  eax,BYTE PTR [ecx]
   1378c:	movzx  edx,bl
   1378f:	cmp    edx,eax
   13791:	jne    0x137c0
   13793:	mov    edx,DWORD PTR [ebp+0x10]
   13796:	sub    edx,DWORD PTR [ebp+0x14]
   13799:	mov    eax,ds:0x1703c
   1379e:	cmp    edx,eax
   137a0:	jb     0x137c0
   137a2:	push   eax
   137a3:	push   ecx
   137a4:	push   edi
   137a5:	call   DWORD PTR ds:0x16050
   137ab:	add    esp,0xc
   137ae:	test   eax,eax
   137b0:	jne    0x137c0
   137b2:	mov    BYTE PTR [esi+0x137],0x1
   137b9:	mov    BYTE PTR [esi+0x138],0x1
   137c0:	inc    DWORD PTR [ebp+0x14]
   137c3:	mov    eax,DWORD PTR [ebp+0x14]
   137c6:	inc    edi
   137c7:	cmp    eax,DWORD PTR [ebp+0x10]
   137ca:	jb     0x1374d
   137cc:	jmp    0x137da
   137ce:	mov    eax,DWORD PTR [ebp+0x10]
   137d1:	sub    eax,DWORD PTR [ebp+0x14]
   137d4:	add    DWORD PTR [esi+0x114],eax
   137da:	lea    edi,[esi+0xb0]
   137e0:	push   edi
   137e1:	call   0x11bfc
   137e6:	push   edi
   137e7:	mov    ebx,eax
   137e9:	call   0x11be6
   137ee:	mov    ecx,eax
   137f0:	mov    eax,ebx
   137f2:	imul   eax,eax,0x64
   137f5:	xor    edx,edx
   137f7:	div    ecx
   137f9:	cmp    eax,0x50
   137fc:	jb     0x13805
   137fe:	or     DWORD PTR [ebp-0x4],0x400
   13805:	cmp    DWORD PTR [ebp+0x10],0x0
   13809:	jbe    0x1380f
   1380b:	or     DWORD PTR [ebp-0x4],0x1
   1380f:	push   DWORD PTR [ebp-0x4]
   13812:	push   esi
   13813:	call   0x142a2
   13818:	push   DWORD PTR [esi]
   1381a:	push   DWORD PTR ds:0x1770c
   13820:	call   DWORD PTR ds:0x175a4
   13826:	push   DWORD PTR [esi+0x18]
   13829:	push   DWORD PTR ds:0x1770c
   1382f:	call   DWORD PTR ds:0x17288
   13835:	pop    edi
   13836:	pop    esi
   13837:	pop    ebx
   13838:	leave
   13839:	ret    0x10
   1383c:	int3
   1383d:	int3
   1383e:	int3
   1383f:	int3
   13840:	int3
   13841:	int3
   13842:	mov    edi,edi
   13844:	push   ebp
   13845:	mov    ebp,esp
   13847:	push   ebx
   13848:	push   esi
   13849:	mov    esi,DWORD PTR [ebp+0x14]
   1384c:	mov    ebx,DWORD PTR [esi+0xac]
   13852:	push   edi
   13853:	mov    edi,DWORD PTR [ebp+0x10]
   13856:	cmp    DWORD PTR [edi+0x8],0x0
   1385a:	mov    eax,DWORD PTR [edi+0xc]
   1385d:	jne    0x13867
   1385f:	add    DWORD PTR [esi+0x108],eax
   13865:	jmp    0x1386d
   13867:	add    DWORD PTR [esi+0x110],eax
   1386d:	mov    eax,DWORD PTR [esi+0x78]
   13870:	cmp    DWORD PTR [ebp+0x8],eax
   13873:	jne    0x138c6
   13875:	push   eax
   13876:	push   DWORD PTR ds:0x1770c
   1387c:	call   DWORD PTR ds:0x17408
   13882:	and    DWORD PTR [esi+0x78],0x0
   13886:	test   ebx,ebx
   13888:	je     0x138bd
   1388a:	push   DWORD PTR ds:0x1700c
   13890:	mov    ecx,DWORD PTR ds:0x1770c
   13896:	mov    edx,ebx
   13898:	call   DWORD PTR ds:0x173f0
   1389e:	test   eax,eax
   138a0:	je     0x138aa
   138a2:	push   DWORD PTR [eax+0xc]
   138a5:	push   DWORD PTR [eax+0x10]
   138a8:	jmp    0x138b0
   138aa:	push   DWORD PTR [edi+0xc]
   138ad:	push   DWORD PTR [edi+0x8]
   138b0:	push   ebx
   138b1:	push   DWORD PTR ds:0x1770c
   138b7:	call   DWORD PTR ds:0x174ec
   138bd:	and    DWORD PTR [esi+0xac],0x0
   138c4:	jmp    0x13918
   138c6:	cmp    BYTE PTR [esi+0x74],0x0
   138ca:	je     0x138fc
   138cc:	test   ebx,ebx
   138ce:	je     0x138f4
   138d0:	push   DWORD PTR ds:0x1700c
   138d6:	mov    ecx,DWORD PTR ds:0x1770c
   138dc:	mov    edx,ebx
   138de:	call   DWORD PTR ds:0x173f0
   138e4:	test   eax,eax
   138e6:	je     0x138f4
   138e8:	mov    ecx,DWORD PTR [edi+0x8]
   138eb:	mov    DWORD PTR [eax+0x10],ecx
   138ee:	mov    ecx,DWORD PTR [edi+0xc]
   138f1:	mov    DWORD PTR [eax+0xc],ecx
   138f4:	push   esi
   138f5:	call   0x13c1c
   138fa:	jmp    0x13931
   138fc:	and    DWORD PTR [esi+0xac],0x0
   13903:	push   DWORD PTR [edi+0xc]
   13906:	push   DWORD PTR [edi+0x8]
   13909:	push   DWORD PTR [ebp+0x8]
   1390c:	push   DWORD PTR ds:0x1770c
   13912:	call   DWORD PTR ds:0x174ec
   13918:	lea    ecx,[esi+0x84]
   1391e:	xor    eax,eax
   13920:	xchg   DWORD PTR [ecx],eax
   13922:	push   DWORD PTR [esi+0x1c]
   13925:	push   DWORD PTR ds:0x1770c
   1392b:	call   DWORD PTR ds:0x17288
   13931:	pop    edi
   13932:	pop    esi
   13933:	pop    ebx
   13934:	pop    ebp
   13935:	ret    0x10
   13938:	int3
   13939:	int3
   1393a:	int3
   1393b:	int3
   1393c:	int3
   1393d:	int3
   1393e:	mov    edi,edi
   13940:	push   ebp
   13941:	mov    ebp,esp
   13943:	push   ecx
   13944:	push   ecx
   13945:	push   esi
   13946:	mov    esi,DWORD PTR [ebp+0x8]
   13949:	cmp    DWORD PTR [esi+0x88],0x0
   13950:	je     0x139fb
   13956:	lea    eax,[ebp-0x8]
   13959:	push   eax
   1395a:	call   DWORD PTR ds:0x16028
   13960:	mov    eax,DWORD PTR [esi+0x9c]
   13966:	cmp    eax,DWORD PTR [ebp-0x4]
   13969:	jl     0x13990
   1396b:	jg     0x13978
   1396d:	mov    eax,DWORD PTR [esi+0x98]
   13973:	cmp    eax,DWORD PTR [ebp-0x8]
   13976:	jb     0x13990
   13978:	mov    eax,DWORD PTR [esi+0xa4]
   1397e:	cmp    eax,DWORD PTR [ebp-0x4]
   13981:	jg     0x139fb
   13983:	jl     0x13990
   13985:	mov    eax,DWORD PTR [esi+0xa0]
   1398b:	cmp    eax,DWORD PTR [ebp-0x8]
   1398e:	jae    0x139fb
   13990:	push   ebx
   13991:	push   edi
   13992:	mov    edi,DWORD PTR [esi+0x88]
   13998:	xor    ecx,ecx
   1399a:	lea    eax,[esi+0x94]
   139a0:	mov    ebx,DWORD PTR [eax]
   139a2:	push   edi
   139a3:	mov    DWORD PTR [esi+0x88],ecx
   139a9:	mov    DWORD PTR [esi+0x8c],ecx
   139af:	mov    DWORD PTR [esi+0x90],ecx
   139b5:	mov    DWORD PTR [eax],ecx
   139b7:	push   DWORD PTR ds:0x1770c
   139bd:	call   DWORD PTR ds:0x174c8
   139c3:	test   eax,eax
   139c5:	je     0x139d7
   139c7:	push   eax
   139c8:	push   edi
   139c9:	push   DWORD PTR ds:0x1770c
   139cf:	call   DWORD PTR ds:0x174e4
   139d5:	jmp    0x139ea
   139d7:	push   ebx
   139d8:	push   0x102
   139dd:	push   edi
   139de:	push   DWORD PTR ds:0x1770c
   139e4:	call   DWORD PTR ds:0x174ec
   139ea:	push   DWORD PTR [esi+0x18]
   139ed:	push   DWORD PTR ds:0x1770c
   139f3:	call   DWORD PTR ds:0x17288
   139f9:	pop    edi
   139fa:	pop    ebx
   139fb:	pop    esi
   139fc:	leave
   139fd:	ret    0x4
   13a00:	int3
   13a01:	int3
   13a02:	int3
   13a03:	int3
   13a04:	int3
   13a05:	int3
   13a06:	mov    edi,edi
   13a08:	push   ebp
   13a09:	mov    ebp,esp
   13a0b:	mov    edx,DWORD PTR [ebp+0x8]
   13a0e:	mov    ecx,DWORD PTR ds:0x1770c
   13a14:	sub    esp,0x10
   13a17:	push   ebx
   13a18:	push   esi
   13a19:	push   edi
   13a1a:	push   DWORD PTR ds:0x17020
   13a20:	call   DWORD PTR ds:0x173f0
   13a26:	push   DWORD PTR ds:0x17034
   13a2c:	mov    ecx,DWORD PTR ds:0x1770c
   13a32:	mov    ebx,eax
   13a34:	mov    edx,DWORD PTR [ebx]
   13a36:	call   DWORD PTR ds:0x173f0
   13a3c:	mov    esi,eax
   13a3e:	mov    eax,DWORD PTR [ebp+0x10]
   13a41:	cmp    DWORD PTR [eax+0x8],0x0
   13a45:	jne    0x13b09
   13a4b:	push   esi
   13a4c:	push   DWORD PTR [eax+0xc]
   13a4f:	push   DWORD PTR [ebx+0x4]
   13a52:	push   DWORD PTR [esi+0x44]
   13a55:	call   0x13710
   13a5a:	lea    edi,[esi+0xb0]
   13a60:	push   edi
   13a61:	call   0x11bfc
   13a66:	push   edi
   13a67:	mov    DWORD PTR [ebp+0x10],eax
   13a6a:	call   0x11be6
   13a6f:	mov    ecx,eax
   13a71:	mov    eax,DWORD PTR [ebp+0x10]
   13a74:	imul   eax,eax,0x64
   13a77:	xor    edx,edx
   13a79:	div    ecx
   13a7b:	cmp    eax,0x32
   13a7e:	jae    0x13b09
   13a84:	xor    eax,eax
   13a86:	lea    edi,[ebp-0x10]
   13a89:	stos   DWORD PTR es:[edi],eax
   13a8a:	stos   DWORD PTR es:[edi],eax
   13a8b:	stos   DWORD PTR es:[edi],eax
   13a8c:	stos   DWORD PTR es:[edi],eax
   13a8d:	and    DWORD PTR [ebp-0xc],0x0
   13a91:	and    DWORD PTR [ebp-0x8],0x0
   13a95:	lea    eax,[ebp-0x10]
   13a98:	push   eax
   13a99:	push   DWORD PTR [ebp+0x8]
   13a9c:	mov    DWORD PTR [ebp-0x10],0x10
   13aa3:	push   DWORD PTR ds:0x1770c
   13aa9:	call   DWORD PTR ds:0x174ac
   13aaf:	test   eax,eax
   13ab1:	jne    0x13b09
   13ab3:	mov    eax,DWORD PTR [ebx+0x4]
   13ab6:	mov    ecx,DWORD PTR [esi+0x5c]
   13ab9:	mov    edx,DWORD PTR [esi+0x44]
   13abc:	push   0x0
   13abe:	push   eax
   13abf:	push   ecx
   13ac0:	push   edx
   13ac1:	push   DWORD PTR ds:0x1770c
   13ac7:	call   DWORD PTR ds:0x1763c
   13acd:	test   eax,eax
   13acf:	jne    0x13b09
   13ad1:	push   ebx
   13ad2:	push   0x13a06
   13ad7:	push   DWORD PTR [esi+0x5c]
   13ada:	push   DWORD PTR ds:0x1770c
   13ae0:	call   DWORD PTR ds:0x174d8
   13ae6:	cmp    DWORD PTR [esi+0x80],0x0
   13aed:	jle    0x13b09
   13aef:	mov    eax,DWORD PTR [esi+0x44]
   13af2:	mov    ecx,DWORD PTR [esi+0x5c]
   13af5:	push   0x0
   13af7:	push   eax
   13af8:	push   ecx
   13af9:	push   DWORD PTR ds:0x1770c
   13aff:	call   DWORD PTR ds:0x174bc
   13b05:	test   al,al
   13b07:	jne    0x13b22
   13b09:	push   0x0
   13b0b:	push   0x0
   13b0d:	lea    eax,[esi+0x60]
   13b10:	push   eax
   13b11:	call   DWORD PTR ds:0x16014
   13b17:	xor    eax,eax
   13b19:	inc    eax
   13b1a:	add    esi,0xc8
   13b20:	xchg   DWORD PTR [esi],eax
   13b22:	pop    edi
   13b23:	pop    esi
   13b24:	pop    ebx
   13b25:	leave
   13b26:	ret    0x10
   13b29:	int3
   13b2a:	int3
   13b2b:	int3
   13b2c:	int3
   13b2d:	int3
   13b2e:	mov    edi,edi
   13b30:	push   ebp
   13b31:	mov    ebp,esp
   13b33:	mov    eax,DWORD PTR [ebp+0xc]
   13b36:	xor    ecx,ecx
   13b38:	cmp    BYTE PTR [eax+0x21],cl
   13b3b:	jne    0x13b42
   13b3d:	mov    eax,DWORD PTR [eax+0x18]
   13b40:	jmp    0x13b52
   13b42:	push   ecx
   13b43:	push   ecx
   13b44:	push   DWORD PTR [ebp+0x10]
   13b47:	call   DWORD PTR ds:0x16014
   13b4d:	mov    eax,0xc0000016
   13b52:	pop    ebp
   13b53:	ret    0xc
   13b56:	int3
   13b57:	int3
   13b58:	int3
   13b59:	int3
   13b5a:	int3
   13b5b:	int3
   13b5c:	mov    edi,edi
   13b5e:	push   ebp
   13b5f:	mov    ebp,esp
   13b61:	mov    edx,DWORD PTR [ebp+0x8]
   13b64:	mov    ecx,DWORD PTR ds:0x1770c
   13b6a:	sub    esp,0x10
   13b6d:	push   DWORD PTR ds:0x17034
   13b73:	call   DWORD PTR ds:0x173f0
   13b79:	cmp    BYTE PTR [eax+0x134],0x0
   13b80:	jne    0x13b9e
   13b82:	mov    eax,DWORD PTR [ebp+0xc]
   13b85:	inc    BYTE PTR [eax+0x23]
   13b88:	add    DWORD PTR [eax+0x60],0x24
   13b8c:	push   eax
   13b8d:	push   DWORD PTR [ebp+0x8]
   13b90:	push   DWORD PTR ds:0x1770c
   13b96:	call   DWORD PTR ds:0x17150
   13b9c:	jmp    0x13c12
   13b9e:	push   ebx
   13b9f:	mov    ebx,DWORD PTR [ebp+0xc]
   13ba2:	push   esi
   13ba3:	mov    esi,DWORD PTR [ebx+0x60]
   13ba6:	push   edi
   13ba7:	lea    eax,[esi-0x24]
   13baa:	push   0x7
   13bac:	pop    ecx
   13bad:	mov    edi,eax
   13baf:	rep movs DWORD PTR es:[edi],DWORD PTR ds:[esi]
   13bb1:	xor    esi,esi
   13bb3:	push   esi
   13bb4:	mov    BYTE PTR [eax+0x3],0x0
   13bb8:	push   0x1
   13bba:	lea    eax,[ebp-0x10]
   13bbd:	push   eax
   13bbe:	call   DWORD PTR ds:0x16024
   13bc4:	mov    eax,DWORD PTR [ebx+0x60]
   13bc7:	push   ebx
   13bc8:	push   DWORD PTR [ebp+0x8]
   13bcb:	sub    eax,0x24
   13bce:	lea    ecx,[ebp-0x10]
   13bd1:	mov    DWORD PTR [eax+0x1c],0x13b2e
   13bd8:	mov    DWORD PTR [eax+0x20],ecx
   13bdb:	mov    BYTE PTR [eax+0x3],0xe0
   13bdf:	push   DWORD PTR ds:0x1770c
   13be5:	call   DWORD PTR ds:0x17150
   13beb:	cmp    eax,0x103
   13bf0:	jne    0x13c0f
   13bf2:	push   esi
   13bf3:	push   esi
   13bf4:	push   esi
   13bf5:	push   esi
   13bf6:	lea    eax,[ebp-0x10]
   13bf9:	push   eax
   13bfa:	call   DWORD PTR ds:0x16048
   13c00:	mov    esi,DWORD PTR [ebx+0x18]
   13c03:	xor    dl,dl
   13c05:	mov    ecx,ebx
   13c07:	call   DWORD PTR ds:0x16030
   13c0d:	mov    eax,esi
   13c0f:	pop    edi
   13c10:	pop    esi
   13c11:	pop    ebx
   13c12:	leave
   13c13:	ret    0x8
   13c16:	int3
   13c17:	int3
   13c18:	int3
   13c19:	int3
   13c1a:	int3
   13c1b:	int3
   13c1c:	mov    edi,edi
   13c1e:	push   ebp
   13c1f:	mov    ebp,esp
   13c21:	sub    esp,0x2c
   13c24:	push   ebx
   13c25:	push   esi
   13c26:	mov    esi,DWORD PTR [ebp+0x8]
   13c29:	xor    ebx,ebx
   13c2b:	mov    DWORD PTR [ebp-0x8],ebx
   13c2e:	cmp    esi,ebx
   13c30:	je     0x13d67
   13c36:	lea    eax,[ebp-0x4]
   13c39:	push   eax
   13c3a:	push   ebx
   13c3b:	push   ebx
   13c3c:	mov    BYTE PTR [esi+0x74],bl
   13c3f:	push   DWORD PTR ds:0x1770c
   13c45:	call   DWORD PTR ds:0x174a4
   13c4b:	test   eax,eax
   13c4d:	jl     0x13d67
   13c53:	mov    eax,DWORD PTR [esi+0x40]
   13c56:	mov    edx,DWORD PTR [ebp-0x4]
   13c59:	push   edi
   13c5a:	push   0x8
   13c5c:	pop    ecx
   13c5d:	mov    DWORD PTR [ebp-0xc],eax
   13c60:	xor    eax,eax
   13c62:	lea    edi,[ebp-0x2c]
   13c65:	rep stos DWORD PTR es:[edi],eax
   13c67:	inc    eax
   13c68:	push   ebx
   13c69:	mov    DWORD PTR [ebp-0x20],eax
   13c6c:	mov    DWORD PTR [ebp-0x1c],eax
   13c6f:	lea    eax,[ebp-0x8]
   13c72:	push   eax
   13c73:	push   0x48
   13c75:	push   ebx
   13c76:	push   ebx
   13c77:	lea    eax,[ebp-0x2c]
   13c7a:	push   eax
   13c7b:	mov    DWORD PTR [esi+0x78],edx
   13c7e:	push   DWORD PTR ds:0x1770c
   13c84:	mov    DWORD PTR [ebp-0x2c],0x20
   13c8b:	mov    DWORD PTR [ebp-0x18],edx
   13c8e:	call   DWORD PTR ds:0x173c8
   13c94:	mov    edi,eax
   13c96:	cmp    edi,ebx
   13c98:	jl     0x13d54
   13c9e:	push   ebx
   13c9f:	push   DWORD PTR [ebp-0x8]
   13ca2:	push   DWORD PTR ds:0x1770c
   13ca8:	call   DWORD PTR ds:0x173d0
   13cae:	mov    esi,eax
   13cb0:	cmp    esi,ebx
   13cb2:	je     0x13d4d
   13cb8:	push   0x48
   13cba:	push   ebx
   13cbb:	push   esi
   13cbc:	call   0x14618
   13cc1:	add    esp,0xc
   13cc4:	push   0x48
   13cc6:	pop    eax
   13cc7:	push   0x9
   13cc9:	mov    WORD PTR [esi],ax
   13ccc:	pop    eax
   13ccd:	push   DWORD PTR [ebp-0xc]
   13cd0:	mov    WORD PTR [esi+0x2],ax
   13cd4:	push   DWORD PTR ds:0x1770c
   13cda:	call   DWORD PTR ds:0x17680
   13ce0:	push   ebx
   13ce1:	mov    DWORD PTR [esi+0x10],eax
   13ce4:	mov    DWORD PTR [esi+0x1c],ebx
   13ce7:	mov    DWORD PTR [esi+0x20],ebx
   13cea:	mov    DWORD PTR [esi+0x18],ebx
   13ced:	mov    DWORD PTR [esi+0x14],ebx
   13cf0:	mov    DWORD PTR [esi+0x24],ebx
   13cf3:	push   DWORD PTR [ebp-0x8]
   13cf6:	push   DWORD PTR [ebp-0x4]
   13cf9:	push   DWORD PTR [ebp-0xc]
   13cfc:	push   DWORD PTR ds:0x1770c
   13d02:	call   DWORD PTR ds:0x17658
   13d08:	mov    edi,eax
   13d0a:	cmp    edi,ebx
   13d0c:	jl     0x13d51
   13d0e:	push   DWORD PTR [ebp+0x8]
   13d11:	push   0x13842
   13d16:	push   DWORD PTR [ebp-0x4]
   13d19:	push   DWORD PTR ds:0x1770c
   13d1f:	call   DWORD PTR ds:0x174d8
   13d25:	push   ebx
   13d26:	push   DWORD PTR [ebp-0xc]
   13d29:	push   DWORD PTR [ebp-0x4]
   13d2c:	push   DWORD PTR ds:0x1770c
   13d32:	call   DWORD PTR ds:0x174bc
   13d38:	test   al,al
   13d3a:	jne    0x13d4d
   13d3c:	push   DWORD PTR [ebp-0x4]
   13d3f:	push   DWORD PTR ds:0x1770c
   13d45:	call   DWORD PTR ds:0x174c0
   13d4b:	mov    edi,eax
   13d4d:	cmp    edi,ebx
   13d4f:	jge    0x13d66
   13d51:	mov    esi,DWORD PTR [ebp+0x8]
   13d54:	push   DWORD PTR [esi+0x78]
   13d57:	push   DWORD PTR ds:0x1770c
   13d5d:	call   DWORD PTR ds:0x17408
   13d63:	mov    DWORD PTR [esi+0x78],ebx
   13d66:	pop    edi
   13d67:	pop    esi
   13d68:	pop    ebx
   13d69:	leave
   13d6a:	ret    0x4
   13d6d:	int3
   13d6e:	int3
   13d6f:	int3
   13d70:	int3
   13d71:	int3
   13d72:	mov    edi,edi
   13d74:	push   ebp
   13d75:	mov    ebp,esp
   13d77:	sub    esp,0x2c
   13d7a:	push   esi
   13d7b:	push   edi
   13d7c:	push   DWORD PTR [ebp+0x8]
   13d7f:	push   DWORD PTR ds:0x1770c
   13d85:	call   DWORD PTR ds:0x17290
   13d8b:	push   DWORD PTR ds:0x17034
   13d91:	mov    ecx,DWORD PTR ds:0x1770c
   13d97:	mov    edx,eax
   13d99:	call   DWORD PTR ds:0x173f0
   13d9f:	mov    esi,eax
   13da1:	xor    eax,eax
   13da3:	lea    edi,[ebp-0x2c]
   13da6:	stos   DWORD PTR es:[edi],eax
   13da7:	stos   DWORD PTR es:[edi],eax
   13da8:	stos   DWORD PTR es:[edi],eax
   13da9:	stos   DWORD PTR es:[edi],eax
   13daa:	stos   DWORD PTR es:[edi],eax
   13dab:	lea    eax,[ebp-0x2c]
   13dae:	push   eax
   13daf:	mov    DWORD PTR [ebp-0x2c],0x14
   13db6:	push   DWORD PTR [esi+0x40]
   13db9:	push   DWORD PTR ds:0x1770c
   13dbf:	call   DWORD PTR ds:0x1761c
   13dc5:	xor    ecx,ecx
   13dc7:	lea    eax,[esi+0x84]
   13dcd:	inc    ecx
   13dce:	xchg   DWORD PTR [eax],ecx
   13dd0:	test   ecx,ecx
   13dd2:	jne    0x13f55
   13dd8:	mov    eax,DWORD PTR [esi+0xc]
   13ddb:	push   ebx
   13ddc:	lea    ecx,[ebp+0x8]
   13ddf:	push   ecx
   13de0:	push   eax
   13de1:	push   DWORD PTR ds:0x1770c
   13de7:	call   DWORD PTR ds:0x17340
   13ded:	test   eax,eax
   13def:	jne    0x13f42
   13df5:	xor    ebx,ebx
   13df7:	lea    eax,[ebp-0x8]
   13dfa:	push   eax
   13dfb:	push   DWORD PTR [ebp+0x8]
   13dfe:	push   DWORD PTR ds:0x1770c
   13e04:	call   DWORD PTR ds:0x174f4
   13e0a:	cmp    eax,ebx
   13e0c:	jne    0x13f16
   13e12:	lea    eax,[ebp-0x4]
   13e15:	push   eax
   13e16:	push   DWORD PTR [ebp-0x8]
   13e19:	push   DWORD PTR ds:0x1770c
   13e1f:	call   DWORD PTR ds:0x173d0
   13e25:	mov    ecx,DWORD PTR [ebp-0x4]
   13e28:	sub    DWORD PTR [esi+0xe4],ecx
   13e2e:	cmp    eax,ebx
   13e30:	jne    0x13e3c
   13e32:	push   0xc000000d
   13e37:	jmp    0x13f17
   13e3c:	mov    eax,DWORD PTR [ebp-0x4]
   13e3f:	cmp    eax,ebx
   13e41:	jne    0x13e49
   13e43:	push   ebx
   13e44:	jmp    0x13f17
   13e49:	cmp    BYTE PTR [esi+0x14b],bl
   13e4f:	je     0x13e68
   13e51:	cmp    DWORD PTR [ebp-0x28],ebx
   13e54:	je     0x13e65
   13e56:	xor    edx,edx
   13e58:	div    DWORD PTR [ebp-0x28]
   13e5b:	test   edx,edx
   13e5d:	jne    0x13e65
   13e5f:	mov    BYTE PTR [esi+0x74],0x1
   13e63:	jmp    0x13e68
   13e65:	mov    BYTE PTR [esi+0x74],bl
   13e68:	mov    eax,DWORD PTR [esi+0x40]
   13e6b:	push   ebx
   13e6c:	push   DWORD PTR [ebp-0x8]
   13e6f:	push   DWORD PTR [ebp+0x8]
   13e72:	push   eax
   13e73:	push   DWORD PTR ds:0x1770c
   13e79:	call   DWORD PTR ds:0x17634
   13e7f:	cmp    eax,ebx
   13e81:	je     0x13e8b
   13e83:	mov    BYTE PTR [esi+0x74],bl
   13e86:	jmp    0x13f16
   13e8b:	mov    eax,DWORD PTR [ebp+0x8]
   13e8e:	push   esi
   13e8f:	push   0x13842
   13e94:	mov    DWORD PTR [esi+0xac],eax
   13e9a:	push   DWORD PTR [ebp+0x8]
   13e9d:	push   DWORD PTR ds:0x1770c
   13ea3:	call   DWORD PTR ds:0x174d8
   13ea9:	push   DWORD PTR [ebp-0x4]
   13eac:	push   esi
   13ead:	call   0x13322
   13eb2:	mov    ecx,eax
   13eb4:	or     eax,edx
   13eb6:	je     0x13ee6
   13eb8:	xor    eax,eax
   13eba:	lea    edi,[ebp-0x18]
   13ebd:	stos   DWORD PTR es:[edi],eax
   13ebe:	stos   DWORD PTR es:[edi],eax
   13ebf:	push   0xffffffff
   13ec1:	stos   DWORD PTR es:[edi],eax
   13ec2:	push   0xffffd8f0
   13ec7:	push   edx
   13ec8:	stos   DWORD PTR es:[edi],eax
   13ec9:	push   ecx
   13eca:	mov    DWORD PTR [ebp-0x18],0x10
   13ed1:	mov    DWORD PTR [ebp-0x14],0x1
   13ed8:	call   0x1460c
   13edd:	mov    DWORD PTR [ebp-0x10],eax
   13ee0:	mov    DWORD PTR [ebp-0xc],edx
   13ee3:	lea    eax,[ebp-0x18]
   13ee6:	mov    ecx,DWORD PTR [esi+0x40]
   13ee9:	push   eax
   13eea:	push   ecx
   13eeb:	push   DWORD PTR [ebp+0x8]
   13eee:	push   DWORD PTR ds:0x1770c
   13ef4:	call   DWORD PTR ds:0x174bc
   13efa:	test   al,al
   13efc:	jne    0x13f54
   13efe:	mov    BYTE PTR [esi+0x74],bl
   13f01:	mov    DWORD PTR [esi+0xac],ebx
   13f07:	push   DWORD PTR [ebp+0x8]
   13f0a:	push   DWORD PTR ds:0x1770c
   13f10:	call   DWORD PTR ds:0x174c0
   13f16:	push   eax
   13f17:	push   DWORD PTR [ebp+0x8]
   13f1a:	push   DWORD PTR ds:0x1770c
   13f20:	call   DWORD PTR ds:0x174e4
   13f26:	mov    eax,DWORD PTR [esi+0xc]
   13f29:	lea    ecx,[ebp+0x8]
   13f2c:	push   ecx
   13f2d:	push   eax
   13f2e:	push   DWORD PTR ds:0x1770c
   13f34:	call   DWORD PTR ds:0x17340
   13f3a:	test   eax,eax
   13f3c:	je     0x13df7
   13f42:	xor    ecx,ecx
   13f44:	lea    eax,[esi+0x84]
   13f4a:	xchg   DWORD PTR [eax],ecx
   13f4c:	push   0x4
   13f4e:	push   esi
   13f4f:	call   0x142a2
   13f54:	pop    ebx
   13f55:	pop    edi
   13f56:	pop    esi
   13f57:	leave
   13f58:	ret    0x4
   13f5b:	int3
   13f5c:	int3
   13f5d:	int3
   13f5e:	int3
   13f5f:	int3
   13f60:	mov    edi,edi
   13f62:	push   ebp
   13f63:	mov    ebp,esp
   13f65:	push   edi
   13f66:	mov    edi,DWORD PTR [ebp+0x8]
   13f69:	push   0x6
   13f6b:	xor    eax,eax
   13f6d:	pop    ecx
   13f6e:	add    edi,0x104
   13f74:	rep stos DWORD PTR es:[edi],eax
   13f76:	pop    edi
   13f77:	pop    ebp
   13f78:	ret    0x4
   13f7b:	int3
   13f7c:	int3
   13f7d:	int3
   13f7e:	int3
   13f7f:	int3
   13f80:	mov    edi,edi
   13f82:	push   ebp
   13f83:	mov    ebp,esp
   13f85:	mov    eax,DWORD PTR [ebp+0x8]
   13f88:	mov    eax,DWORD PTR [eax+0xcc]
   13f8e:	mov    ecx,DWORD PTR [ebp+0xc]
   13f91:	mov    DWORD PTR [ecx],eax
   13f93:	xor    eax,eax
   13f95:	pop    ebp
   13f96:	ret    0x8
   13f99:	int3
   13f9a:	int3
   13f9b:	int3
   13f9c:	int3
   13f9d:	int3
   13f9e:	mov    edi,edi
   13fa0:	push   ebp
   13fa1:	mov    ebp,esp
   13fa3:	push   esi
   13fa4:	mov    esi,DWORD PTR [ebp+0x8]
   13fa7:	push   edi
   13fa8:	mov    edi,DWORD PTR [ebp+0xc]
   13fab:	add    esi,0xd0
   13fb1:	movs   DWORD PTR es:[edi],DWORD PTR ds:[esi]
   13fb2:	movs   WORD PTR es:[edi],WORD PTR ds:[esi]
   13fb4:	pop    edi
   13fb5:	xor    eax,eax
   13fb7:	pop    esi
   13fb8:	pop    ebp
   13fb9:	ret    0x8
   13fbc:	int3
   13fbd:	int3
   13fbe:	int3
   13fbf:	int3
   13fc0:	int3
   13fc1:	int3
   13fc2:	mov    edi,edi
   13fc4:	push   ebp
   13fc5:	mov    ebp,esp
   13fc7:	push   esi
   13fc8:	mov    esi,DWORD PTR [ebp+0x8]
   13fcb:	push   edi
   13fcc:	mov    edi,DWORD PTR [ebp+0xc]
   13fcf:	push   0x5
   13fd1:	add    esi,0xd8
   13fd7:	pop    ecx
   13fd8:	rep movs DWORD PTR es:[edi],DWORD PTR ds:[esi]
   13fda:	pop    edi
   13fdb:	xor    eax,eax
   13fdd:	pop    esi
   13fde:	pop    ebp
   13fdf:	ret    0x8
   13fe2:	int3
   13fe3:	int3
   13fe4:	int3
   13fe5:	int3
   13fe6:	int3
   13fe7:	int3
   13fe8:	mov    edi,edi
   13fea:	push   ebp
   13feb:	mov    ebp,esp
   13fed:	push   esi
   13fee:	mov    esi,DWORD PTR [ebp+0x8]
   13ff1:	push   edi
   13ff2:	mov    edi,DWORD PTR [ebp+0xc]
   13ff5:	add    esi,0xec
   13ffb:	movs   DWORD PTR es:[edi],DWORD PTR ds:[esi]
   13ffc:	movs   DWORD PTR es:[edi],DWORD PTR ds:[esi]
   13ffd:	movs   DWORD PTR es:[edi],DWORD PTR ds:[esi]
   13ffe:	movs   DWORD PTR es:[edi],DWORD PTR ds:[esi]
   13fff:	pop    edi
   14000:	xor    eax,eax
   14002:	pop    esi
   14003:	pop    ebp
   14004:	ret    0x8
   14007:	int3
   14008:	int3
   14009:	int3
   1400a:	int3
   1400b:	int3
   1400c:	mov    edi,edi
   1400e:	push   ebp
   1400f:	mov    ebp,esp
   14011:	push   esi
   14012:	mov    esi,DWORD PTR [ebp+0x8]
   14015:	push   edi
   14016:	mov    edi,DWORD PTR [ebp+0xc]
   14019:	add    esi,0xfc
   1401f:	movs   WORD PTR es:[edi],WORD PTR ds:[esi]
   14021:	movs   BYTE PTR es:[edi],BYTE PTR ds:[esi]
   14022:	pop    edi
   14023:	xor    eax,eax
   14025:	pop    esi
   14026:	pop    ebp
   14027:	ret    0x8
   1402a:	int3
   1402b:	int3
   1402c:	int3
   1402d:	int3
   1402e:	int3
   1402f:	int3
   14030:	mov    edi,edi
   14032:	push   ebp
   14033:	mov    ebp,esp
   14035:	mov    eax,DWORD PTR [ebp+0x8]
   14038:	mov    eax,DWORD PTR [eax+0x100]
   1403e:	mov    ecx,DWORD PTR [ebp+0xc]
   14041:	mov    DWORD PTR [ecx],eax
   14043:	xor    eax,eax
   14045:	pop    ebp
   14046:	ret    0x8
   14049:	int3
   1404a:	int3
   1404b:	int3
   1404c:	int3
   1404d:	int3
   1404e:	mov    edi,edi
   14050:	push   ebp
   14051:	mov    ebp,esp
   14053:	push   ebx
   14054:	push   esi
   14055:	mov    esi,DWORD PTR [ebp+0xc]
   14058:	push   0x40
   1405a:	push   0x0
   1405c:	push   esi
   1405d:	call   0x14618
   14062:	and    DWORD PTR [esi+0xc],0x0
   14066:	add    esp,0xc
   14069:	push   0x40
   1406b:	pop    eax
   1406c:	mov    WORD PTR [esi],ax
   1406f:	push   0x2
   14071:	pop    edx
   14072:	mov    eax,edx
   14074:	mov    WORD PTR [esi+0x2],ax
   14078:	mov    eax,DWORD PTR [ebp+0x8]
   1407b:	xor    ecx,ecx
   1407d:	inc    ecx
   1407e:	add    eax,0xc0
   14083:	mov    DWORD PTR [esi+0x4],ecx
   14086:	mov    ebx,DWORD PTR [eax]
   14088:	mov    DWORD PTR [esi+0x10],ebx
   1408b:	mov    DWORD PTR [esi+0x14],0x10000000
   14092:	mov    DWORD PTR [esi+0x18],ecx
   14095:	mov    DWORD PTR [esi+0x1c],0x40
   1409c:	mov    DWORD PTR [esi+0x20],edx
   1409f:	mov    DWORD PTR [esi+0x24],0x1007fffb
   140a6:	mov    eax,DWORD PTR [eax]
   140a8:	mov    DWORD PTR [esi+0x30],eax
   140ab:	pop    esi
   140ac:	xor    eax,eax
   140ae:	pop    ebx
   140af:	pop    ebp
   140b0:	ret    0x8
   140b3:	int3
   140b4:	int3
   140b5:	int3
   140b6:	int3
   140b7:	int3
   140b8:	mov    edi,edi
   140ba:	push   ebp
   140bb:	mov    ebp,esp
   140bd:	push   esi
   140be:	mov    esi,DWORD PTR [ebp+0x8]
   140c1:	push   edi
   140c2:	mov    edi,DWORD PTR [ebp+0xc]
   140c5:	push   0x6
   140c7:	add    esi,0x104
   140cd:	pop    ecx
   140ce:	rep movs DWORD PTR es:[edi],DWORD PTR ds:[esi]
   140d0:	pop    edi
   140d1:	xor    eax,eax
   140d3:	pop    esi
   140d4:	pop    ebp
   140d5:	ret    0x8
   140d8:	int3
   140d9:	int3
   140da:	int3
   140db:	int3
   140dc:	int3
   140dd:	int3
   140de:	mov    edi,edi
   140e0:	push   ebp
   140e1:	mov    ebp,esp
   140e3:	push   esi
   140e4:	mov    esi,DWORD PTR [ebp+0x8]
   140e7:	push   edi
   140e8:	mov    edi,DWORD PTR [ebp+0xc]
   140eb:	push   0x5
   140ed:	add    esi,0x11c
   140f3:	pop    ecx
   140f4:	rep movs DWORD PTR es:[edi],DWORD PTR ds:[esi]
   140f6:	pop    edi
   140f7:	xor    eax,eax
   140f9:	pop    esi
   140fa:	pop    ebp
   140fb:	ret    0x8
   140fe:	int3
   140ff:	int3
   14100:	int3
   14101:	int3
   14102:	int3
   14103:	int3
   14104:	mov    edi,edi
   14106:	push   ebp
   14107:	mov    ebp,esp
   14109:	mov    eax,DWORD PTR [ebp+0x8]
   1410c:	mov    eax,DWORD PTR [eax+0x130]
   14112:	mov    ecx,DWORD PTR [ebp+0xc]
   14115:	mov    DWORD PTR [ecx],eax
   14117:	xor    eax,eax
   14119:	pop    ebp
   1411a:	ret    0x8
   1411d:	int3
   1411e:	int3
   1411f:	int3
   14120:	int3
   14121:	int3
   14122:	mov    edi,edi
   14124:	push   ebp
   14125:	mov    ebp,esp
   14127:	mov    eax,DWORD PTR [ebp+0xc]
   1412a:	mov    eax,DWORD PTR [eax]
   1412c:	mov    ecx,DWORD PTR [ebp+0x8]
   1412f:	mov    DWORD PTR [ecx+0xcc],eax
   14135:	xor    eax,eax
   14137:	pop    ebp
   14138:	ret    0x8
   1413b:	int3
   1413c:	int3
   1413d:	int3
   1413e:	int3
   1413f:	int3
   14140:	mov    edi,edi
   14142:	push   ebp
   14143:	mov    ebp,esp
   14145:	push   esi
   14146:	mov    esi,DWORD PTR [ebp+0xc]
   14149:	push   edi
   1414a:	mov    edi,DWORD PTR [ebp+0x8]
   1414d:	add    edi,0xd0
   14153:	movs   DWORD PTR es:[edi],DWORD PTR ds:[esi]
   14154:	movs   WORD PTR es:[edi],WORD PTR ds:[esi]
   14156:	pop    edi
   14157:	xor    eax,eax
   14159:	pop    esi
   1415a:	pop    ebp
   1415b:	ret    0x8
   1415e:	int3
   1415f:	int3
   14160:	int3
   14161:	int3
   14162:	int3
   14163:	int3
   14164:	mov    edi,edi
   14166:	push   ebp
   14167:	mov    ebp,esp
   14169:	mov    eax,DWORD PTR [ebp+0x8]
   1416c:	cmp    BYTE PTR [eax+0x137],0x0
   14173:	je     0x1417c
   14175:	or     DWORD PTR [eax+0x100],0x20
   1417c:	xor    eax,eax
   1417e:	pop    ebp
   1417f:	ret    0x4
   14182:	int3
   14183:	int3
   14184:	int3
   14185:	int3
   14186:	int3
   14187:	int3
   14188:	mov    edi,edi
   1418a:	push   ebp
   1418b:	mov    ebp,esp
   1418d:	push   esi
   1418e:	mov    esi,DWORD PTR [ebp+0xc]
   14191:	push   edi
   14192:	mov    edi,DWORD PTR [ebp+0x8]
   14195:	add    edi,0xec
   1419b:	movs   DWORD PTR es:[edi],DWORD PTR ds:[esi]
   1419c:	movs   DWORD PTR es:[edi],DWORD PTR ds:[esi]
   1419d:	movs   DWORD PTR es:[edi],DWORD PTR ds:[esi]
   1419e:	movs   DWORD PTR es:[edi],DWORD PTR ds:[esi]
   1419f:	pop    edi
   141a0:	xor    eax,eax
   141a2:	pop    esi
   141a3:	pop    ebp
   141a4:	ret    0x8
   141a7:	int3
   141a8:	int3
   141a9:	int3
   141aa:	int3
   141ab:	int3
   141ac:	mov    edi,edi
   141ae:	push   ebp
   141af:	mov    ebp,esp
   141b1:	push   esi
   141b2:	mov    esi,DWORD PTR [ebp+0xc]
   141b5:	push   edi
   141b6:	mov    edi,DWORD PTR [ebp+0x8]
   141b9:	add    edi,0xfc
   141bf:	movs   WORD PTR es:[edi],WORD PTR ds:[esi]
   141c1:	movs   BYTE PTR es:[edi],BYTE PTR ds:[esi]
   141c2:	pop    edi
   141c3:	xor    eax,eax
   141c5:	pop    esi
   141c6:	pop    ebp
   141c7:	ret    0x8
   141ca:	int3
   141cb:	int3
   141cc:	int3
   141cd:	int3
   141ce:	int3
   141cf:	int3
   141d0:	mov    edi,edi
   141d2:	push   ebp
   141d3:	mov    ebp,esp
   141d5:	push   esi
   141d6:	mov    esi,DWORD PTR [ebp+0xc]
   141d9:	cmp    DWORD PTR [esi],0xffffffff
   141dc:	jne    0x141f1
   141de:	cmp    DWORD PTR [esi+0x4],0xffffffff
   141e2:	jne    0x141f1
   141e4:	cmp    DWORD PTR [esi+0x8],0xffffffff
   141e8:	jne    0x141f1
   141ea:	mov    eax,0xc000000d
   141ef:	jmp    0x14203
   141f1:	push   edi
   141f2:	mov    edi,DWORD PTR [ebp+0x8]
   141f5:	push   0x5
   141f7:	add    edi,0x11c
   141fd:	pop    ecx
   141fe:	rep movs DWORD PTR es:[edi],DWORD PTR ds:[esi]
   14200:	xor    eax,eax
   14202:	pop    edi
   14203:	pop    esi
   14204:	pop    ebp
   14205:	ret    0x8
   14208:	int3
   14209:	int3
   1420a:	int3
   1420b:	int3
   1420c:	int3
   1420d:	int3
   1420e:	xor    eax,eax
   14210:	ret    0x8
   14213:	int3
   14214:	int3
   14215:	int3
   14216:	int3
   14217:	int3
   14218:	mov    edi,edi
   1421a:	push   ebp
   1421b:	mov    ebp,esp
   1421d:	push   ecx
   1421e:	push   ecx
   1421f:	push   ebx
   14220:	push   esi
   14221:	mov    esi,DWORD PTR [ebp+0x8]
   14224:	xor    ebx,ebx
   14226:	push   edi
   14227:	mov    edi,DWORD PTR [esi+0x14]
   1422a:	mov    DWORD PTR [ebp-0x4],ebx
   1422d:	mov    DWORD PTR [ebp-0x8],ebx
   14230:	cmp    edi,ebx
   14232:	je     0x14295
   14234:	push   edi
   14235:	mov    DWORD PTR [esi+0x14],ebx
   14238:	call   0x11088
   1423d:	cmp    eax,0xc0000120
   14242:	je     0x14295
   14244:	lea    eax,[ebp-0x8]
   14247:	push   eax
   14248:	lea    eax,[ebp-0x4]
   1424b:	push   eax
   1424c:	push   0x4
   1424e:	push   edi
   1424f:	push   DWORD PTR ds:0x1770c
   14255:	call   DWORD PTR ds:0x17500
   1425b:	cmp    eax,ebx
   1425d:	je     0x1426f
   1425f:	push   eax
   14260:	push   edi
   14261:	push   DWORD PTR ds:0x1770c
   14267:	call   DWORD PTR ds:0x174e4
   1426d:	jmp    0x14295
   1426f:	mov    eax,DWORD PTR [ebp+0xc]
   14272:	mov    ecx,DWORD PTR [ebp-0x4]
   14275:	mov    DWORD PTR [ecx],eax
   14277:	cmp    eax,ebx
   14279:	jne    0x14280
   1427b:	mov    DWORD PTR [esi+0x10],ebx
   1427e:	jmp    0x14285
   14280:	not    eax
   14282:	and    DWORD PTR [esi+0x10],eax
   14285:	push   0x4
   14287:	push   ebx
   14288:	push   edi
   14289:	push   DWORD PTR ds:0x1770c
   1428f:	call   DWORD PTR ds:0x174ec
   14295:	pop    edi
   14296:	pop    esi
   14297:	pop    ebx
   14298:	leave
   14299:	ret    0x8
   1429c:	int3
   1429d:	int3
   1429e:	int3
   1429f:	int3
   142a0:	int3
   142a1:	int3
   142a2:	mov    edi,edi
   142a4:	push   ebp
   142a5:	mov    ebp,esp
   142a7:	mov    eax,DWORD PTR [ebp+0x8]
   142aa:	mov    ecx,DWORD PTR [ebp+0xc]
   142ad:	or     DWORD PTR [eax+0x10],ecx
   142b0:	mov    edx,DWORD PTR [eax+0x10]
   142b3:	push   esi
   142b4:	mov    esi,DWORD PTR [eax+0x130]
   142ba:	mov    ecx,esi
   142bc:	and    ecx,edx
   142be:	test   cl,0x10
   142c1:	je     0x142c8
   142c3:	or     ecx,0x8
   142c6:	jmp    0x142cb
   142c8:	and    ecx,0xfffffff7
   142cb:	test   ecx,ecx
   142cd:	jne    0x142d7
   142cf:	test   edx,edx
   142d1:	je     0x142e6
   142d3:	test   esi,esi
   142d5:	jne    0x142e6
   142d7:	push   DWORD PTR [eax+0x20]
   142da:	push   DWORD PTR ds:0x1770c
   142e0:	call   DWORD PTR ds:0x17288
   142e6:	pop    esi
   142e7:	pop    ebp
   142e8:	ret    0x8
   142eb:	int3
   142ec:	int3
   142ed:	int3
   142ee:	int3
   142ef:	int3
   142f0:	mov    edi,edi
   142f2:	push   ebp
   142f3:	mov    ebp,esp
   142f5:	push   ebx
   142f6:	xor    ebx,ebx
   142f8:	cmp    DWORD PTR [ebp+0xc],ebx
   142fb:	je     0x143d9
   14301:	test   DWORD PTR [ebp+0xc],0xfffffff0
   14308:	jne    0x143d9
   1430e:	test   BYTE PTR [ebp+0xc],0x2
   14312:	push   esi
   14313:	mov    esi,DWORD PTR [ebp+0x8]
   14316:	push   edi
   14317:	mov    edi,0xc0000120
   1431c:	je     0x14385
   1431e:	jmp    0x14330
   14320:	push   edi
   14321:	push   DWORD PTR [ebp+0x8]
   14324:	push   DWORD PTR ds:0x1770c
   1432a:	call   DWORD PTR ds:0x174e4
   14330:	mov    eax,DWORD PTR [esi+0x8]
   14333:	lea    ecx,[ebp+0x8]
   14336:	push   ecx
   14337:	push   eax
   14338:	push   DWORD PTR ds:0x1770c
   1433e:	call   DWORD PTR ds:0x17340
   14344:	test   eax,eax
   14346:	je     0x14320
   14348:	lea    eax,[esi+0x88]
   1434e:	mov    ecx,DWORD PTR [eax]
   14350:	mov    DWORD PTR [ebp+0x8],ecx
   14353:	mov    DWORD PTR [eax],ebx
   14355:	cmp    ecx,ebx
   14357:	je     0x14385
   14359:	push   ecx
   1435a:	call   0x11088
   1435f:	mov    DWORD PTR [esi+0x8c],ebx
   14365:	mov    DWORD PTR [esi+0x90],ebx
   1436b:	mov    DWORD PTR [esi+0x94],ebx
   14371:	cmp    eax,edi
   14373:	je     0x14385
   14375:	push   edi
   14376:	push   DWORD PTR [ebp+0x8]
   14379:	push   DWORD PTR ds:0x1770c
   1437f:	call   DWORD PTR ds:0x174e4
   14385:	test   BYTE PTR [ebp+0xc],0x8
   14389:	je     0x1439d
   1438b:	lea    eax,[esi+0xb0]
   14391:	push   eax
   14392:	call   0x11c28
   14397:	mov    DWORD PTR [esi+0xe0],ebx
   1439d:	test   BYTE PTR [ebp+0xc],0x1
   143a1:	je     0x143d3
   143a3:	jmp    0x143b5
   143a5:	push   edi
   143a6:	push   DWORD PTR [ebp+0x8]
   143a9:	push   DWORD PTR ds:0x1770c
   143af:	call   DWORD PTR ds:0x174e4
   143b5:	mov    eax,DWORD PTR [esi+0xc]
   143b8:	lea    ecx,[ebp+0x8]
   143bb:	push   ecx
   143bc:	push   eax
   143bd:	push   DWORD PTR ds:0x1770c
   143c3:	call   DWORD PTR ds:0x17340
   143c9:	test   eax,eax
   143cb:	je     0x143a5
   143cd:	mov    DWORD PTR [esi+0xe4],ebx
   143d3:	pop    edi
   143d4:	xor    eax,eax
   143d6:	pop    esi
   143d7:	jmp    0x143de
   143d9:	mov    eax,0xc000000d
   143de:	pop    ebx
   143df:	pop    ebp
   143e0:	ret    0x8
   143e3:	int3
   143e4:	int3
   143e5:	int3
   143e6:	int3
   143e7:	int3
   143e8:	mov    edi,edi
   143ea:	push   ebp
   143eb:	mov    ebp,esp
   143ed:	mov    eax,DWORD PTR [ebp+0x8]
   143f0:	lea    ecx,[eax+0x138]
   143f6:	xor    dl,dl
   143f8:	cmp    BYTE PTR [ecx],dl
   143fa:	je     0x1441c
   143fc:	mov    BYTE PTR [ecx],dl
   143fe:	cmp    BYTE PTR [eax+0x137],dl
   14404:	je     0x14412
   14406:	or     DWORD PTR [eax+0x100],0x80
   14410:	jmp    0x1441c
   14412:	and    DWORD PTR [eax+0x100],0xffffff7f
   1441c:	pop    ebp
   1441d:	ret    0x4
   14420:	int3
   14421:	int3
   14422:	int3
   14423:	int3
   14424:	int3
   14425:	int3
   14426:	mov    edi,edi
   14428:	push   ebp
   14429:	mov    ebp,esp
   1442b:	push   esi
   1442c:	mov    esi,DWORD PTR [ebp+0x8]
   1442f:	and    DWORD PTR [esi+0x100],0xffffff5f
   14439:	push   esi
   1443a:	mov    BYTE PTR [esi+0x137],0x0
   14441:	mov    BYTE PTR [esi+0x138],0x1
   14448:	call   0x143e8
   1444d:	test   BYTE PTR [esi+0x130],0x20
   14454:	je     0x1445e
   14456:	push   0x20
   14458:	push   esi
   14459:	call   0x142a2
   1445e:	xor    eax,eax
   14460:	pop    esi
   14461:	pop    ebp
   14462:	ret    0x4
   14465:	int3
   14466:	int3
   14467:	int3
   14468:	int3
   14469:	int3
   1446a:	mov    edi,edi
   1446c:	push   ebp
   1446d:	mov    ebp,esp
   1446f:	push   ebx
   14470:	mov    ebx,DWORD PTR [ebp+0xc]
   14473:	test   DWORD PTR [ebx],0xfffff800
   14479:	je     0x14482
   1447b:	mov    eax,0xc000000d
   14480:	jmp    0x144bd
   14482:	push   esi
   14483:	push   edi
   14484:	mov    edi,DWORD PTR [ebp+0x8]
   14487:	lea    esi,[edi+0xa8]
   1448d:	push   DWORD PTR [esi]
   1448f:	push   DWORD PTR ds:0x1770c
   14495:	call   DWORD PTR ds:0x175b8
   1449b:	push   0x0
   1449d:	push   edi
   1449e:	call   0x14218
   144a3:	mov    eax,DWORD PTR [ebx]
   144a5:	push   DWORD PTR [esi]
   144a7:	mov    DWORD PTR [edi+0x130],eax
   144ad:	push   DWORD PTR ds:0x1770c
   144b3:	call   DWORD PTR ds:0x175bc
   144b9:	pop    edi
   144ba:	xor    eax,eax
   144bc:	pop    esi
   144bd:	pop    ebx
   144be:	pop    ebp
   144bf:	ret    0x8
   144c2:	int3
   144c3:	int3
   144c4:	int3
   144c5:	int3
   144c6:	int3
   144c7:	int3
   144c8:	mov    edi,edi
   144ca:	push   ebp
   144cb:	mov    ebp,esp
   144cd:	push   ecx
   144ce:	push   ebx
   144cf:	push   esi
   144d0:	mov    esi,DWORD PTR [ebp+0x8]
   144d3:	xor    ebx,ebx
   144d5:	push   ebx
   144d6:	push   esi
   144d7:	mov    DWORD PTR [ebp-0x4],ebx
   144da:	call   0x14218
   144df:	cmp    DWORD PTR [esi+0x130],ebx
   144e5:	jne    0x14503
   144e7:	mov    esi,0xc0000120
   144ec:	push   esi
   144ed:	push   DWORD PTR [ebp+0xc]
   144f0:	push   DWORD PTR ds:0x1770c
   144f6:	call   DWORD PTR ds:0x174e4
   144fc:	mov    eax,esi
   144fe:	jmp    0x145b1
   14503:	mov    ecx,DWORD PTR ds:0x1770c
   14509:	push   edi
   1450a:	mov    edi,DWORD PTR [ebp+0xc]
   1450d:	push   DWORD PTR ds:0x1700c
   14513:	mov    edx,edi
   14515:	call   DWORD PTR ds:0x173f0
   1451b:	mov    DWORD PTR [eax],ebx
   1451d:	mov    DWORD PTR [eax+0x4],ebx
   14520:	mov    DWORD PTR [eax+0x8],ebx
   14523:	mov    ecx,DWORD PTR [esi]
   14525:	push   0x130f4
   1452a:	mov    DWORD PTR [eax],ecx
   1452c:	push   edi
   1452d:	mov    DWORD PTR [esi+0x14],edi
   14530:	call   0x1102a
   14535:	mov    ebx,eax
   14537:	test   ebx,ebx
   14539:	je     0x14551
   1453b:	push   ebx
   1453c:	push   edi
   1453d:	push   DWORD PTR ds:0x1770c
   14543:	call   DWORD PTR ds:0x174e4
   14549:	and    DWORD PTR [esi+0x14],0x0
   1454d:	mov    eax,ebx
   1454f:	jmp    0x145b0
   14551:	lea    ebx,[esi+0xb0]
   14557:	push   ebx
   14558:	call   0x11ba8
   1455d:	test   al,al
   1455f:	jne    0x145a2
   14561:	push   ebx
   14562:	mov    DWORD PTR [ebp-0x4],0x1
   14569:	call   0x11b80
   1456e:	push   ebx
   1456f:	mov    edi,eax
   14571:	call   0x11b94
   14576:	mov    DWORD PTR [ebp+0xc],eax
   14579:	cmp    edi,eax
   1457b:	je     0x145a2
   1457d:	mov    al,BYTE PTR [esi+0xd3]
   14583:	cmp    BYTE PTR [edi],al
   14585:	jne    0x1458b
   14587:	test   al,al
   14589:	jne    0x1459b
   1458b:	push   edi
   1458c:	push   ebx
   1458d:	call   0x11b64
   14592:	mov    edi,eax
   14594:	cmp    edi,DWORD PTR [ebp+0xc]
   14597:	jne    0x1457d
   14599:	jmp    0x145a2
   1459b:	mov    DWORD PTR [ebp-0x4],0x3
   145a2:	push   DWORD PTR [ebp-0x4]
   145a5:	push   esi
   145a6:	call   0x142a2
   145ab:	mov    eax,0x103
   145b0:	pop    edi
   145b1:	pop    esi
   145b2:	pop    ebx
   145b3:	leave
   145b4:	ret    0x8
   145b7:	int3
   145b8:	int3
   145b9:	int3
   145ba:	int3
   145bb:	int3
   145bc:	ret    0x8
   145bf:	int3
   145c0:	int3
   145c1:	int3
   145c2:	int3
   145c3:	int3
   145c4:	ret    0x4
   145c7:	int3
   145c8:	int3
   145c9:	int3
   145ca:	int3
   145cb:	int3
   145cc:	cmp    ecx,DWORD PTR ds:0x17044
   145d2:	jne    0x145d7
   145d4:	ret    0x0
   145d7:	jmp    0x145e1
   145dc:	int3
   145dd:	int3
   145de:	int3
   145df:	int3
   145e0:	int3
   145e1:	mov    edi,edi
   145e3:	push   ebp
   145e4:	mov    ebp,esp
   145e6:	push   ecx
   145e7:	mov    DWORD PTR [ebp-0x4],ecx
   145ea:	push   0x0
   145ec:	push   DWORD PTR ds:0x17048
   145f2:	push   DWORD PTR ds:0x17044
   145f8:	push   DWORD PTR [ebp-0x4]
   145fb:	push   0xf7
   14600:	call   DWORD PTR ds:0x16038
   14606:	int3
   14607:	int3
   14608:	int3
   14609:	int3
   1460a:	int3
   1460b:	int3
   1460c:	jmp    DWORD PTR ds:0x16054
   14612:	int3
   14613:	int3
   14614:	int3
   14615:	int3
   14616:	int3
   14617:	int3
   14618:	jmp    DWORD PTR ds:0x1604c
   1461e:	int3
   1461f:	int3
   14620:	int3
   14621:	int3
   14622:	int3
   14623:	mov    edi,edi
   14625:	push   esi
   14626:	mov    esi,0x1704c
   1462b:	push   esi
   1462c:	call   0x147c9
   14631:	push   DWORD PTR ds:0x1770c
   14637:	push   esi
   14638:	push   0x176fc
   1463d:	call   0x15600
   14642:	pop    esi
   14643:	ret
   14644:	int3
   14645:	int3
   14646:	int3
   14647:	int3
   14648:	int3
   14649:	mov    edi,edi
   1464b:	push   ebp
   1464c:	mov    ebp,esp
   1464e:	mov    eax,ds:0x17704
   14653:	test   eax,eax
   14655:	je     0x14663
   14657:	cmp    eax,0x14649
   1465c:	je     0x14663
   1465e:	push   DWORD PTR [ebp+0x8]
   14661:	call   eax
   14663:	call   0x14623
   14668:	pop    ebp
   14669:	ret    0x4
   1466c:	int3
   1466d:	int3
   1466e:	int3
   1466f:	int3
   14670:	int3
   14671:	call   0x14623
   14676:	ret    0x8
   14679:	int3
   1467a:	int3
   1467b:	int3
   1467c:	int3
   1467d:	int3
   1467e:	mov    edi,edi
   14680:	push   ebp
   14681:	mov    ebp,esp
   14683:	push   edi
   14684:	mov    edi,DWORD PTR [ebp+0x8]
   14687:	test   edi,edi
   14689:	jne    0x14699
   1468b:	push   DWORD PTR [ebp+0xc]
   1468e:	push   edi
   1468f:	call   0x110de
   14694:	jmp    0x1474a
   14699:	push   ebx
   1469a:	push   esi
   1469b:	push   DWORD PTR [ebp+0xc]
   1469e:	xor    eax,eax
   146a0:	mov    ds:0x176fc,ax
   146a6:	mov    eax,0x208
   146ab:	mov    esi,0x176fc
   146b0:	push   esi
   146b1:	mov    DWORD PTR ds:0x17710,edi
   146b7:	mov    ds:0x176fe,ax
   146bd:	mov    DWORD PTR ds:0x17700,0x17718
   146c7:	call   DWORD PTR ds:0x1603c
   146cd:	push   0x1770c
   146d2:	mov    ebx,0x1704c
   146d7:	push   ebx
   146d8:	push   esi
   146d9:	push   edi
   146da:	call   0x1560c
   146df:	test   eax,eax
   146e1:	jl     0x14748
   146e3:	push   ebx
   146e4:	call   0x14769
   146e9:	mov    esi,eax
   146eb:	test   esi,esi
   146ed:	jl     0x14703
   146ef:	call   0x1481a
   146f4:	push   DWORD PTR [ebp+0xc]
   146f7:	push   edi
   146f8:	call   0x110de
   146fd:	mov    esi,eax
   146ff:	test   esi,esi
   14701:	jge    0x1470c
   14703:	call   0x14623
   14708:	mov    eax,esi
   1470a:	jmp    0x14748
   1470c:	mov    eax,ds:0x1770c
   14711:	cmp    BYTE PTR [eax+0x2c],0x0
   14715:	je     0x1472c
   14717:	mov    eax,DWORD PTR [edi+0x34]
   1471a:	test   eax,eax
   1471c:	je     0x14723
   1471e:	mov    ds:0x17704,eax
   14723:	mov    DWORD PTR [edi+0x34],0x14649
   1472a:	jmp    0x14746
   1472c:	test   BYTE PTR [eax+0x4],0x2
   14730:	je     0x14746
   14732:	mov    eax,ds:0x173ec
   14737:	mov    ds:0x17708,eax
   1473c:	mov    DWORD PTR ds:0x173ec,0x14671
   14746:	xor    eax,eax
   14748:	pop    esi
   14749:	pop    ebx
   1474a:	pop    edi
   1474b:	pop    ebp
   1474c:	ret    0x8
   1474f:	int3
   14750:	int3
   14751:	int3
   14752:	int3
   14753:	int3
   14754:	mov    edi,edi
   14756:	push   ebp
   14757:	mov    ebp,esp
   14759:	call   0x18005
   1475e:	pop    ebp
   1475f:	jmp    0x1467e
   14764:	int3
   14765:	int3
   14766:	int3
   14767:	int3
   14768:	int3
   14769:	mov    edi,edi
   1476b:	push   ebp
   1476c:	mov    ebp,esp
   1476e:	push   esi
   1476f:	mov    esi,0x17098
   14774:	push   edi
   14775:	mov    ecx,esi
   14777:	mov    edi,0x17098
   1477c:	xor    eax,eax
   1477e:	cmp    ecx,edi
   14780:	jae    0x147be
   14782:	cmp    DWORD PTR [esi],0x2c
   14785:	jne    0x147b9
   14787:	mov    eax,DWORD PTR [esi+0x20]
   1478a:	push   esi
   1478b:	push   DWORD PTR ds:0x1770c
   14791:	mov    DWORD PTR ds:0x1709c,esi
   14797:	push   DWORD PTR [ebp+0x8]
   1479a:	test   eax,eax
   1479c:	je     0x147a7
   1479e:	push   0x15618
   147a3:	call   eax
   147a5:	jmp    0x147ac
   147a7:	call   0x15618
   147ac:	test   eax,eax
   147ae:	jl     0x147be
   147b0:	add    esi,0x2c
   147b3:	cmp    esi,edi
   147b5:	jb     0x14782
   147b7:	jmp    0x147be
   147b9:	mov    eax,0xc0000004
   147be:	pop    edi
   147bf:	pop    esi
   147c0:	pop    ebp
   147c1:	ret    0x4
   147c4:	int3
   147c5:	int3
   147c6:	int3
   147c7:	int3
   147c8:	int3
   147c9:	mov    edi,edi
   147cb:	push   ebp
   147cc:	mov    ebp,esp
   147ce:	mov    eax,ds:0x1709c
   147d3:	mov    ecx,0x17098
   147d8:	push   esi
   147d9:	mov    esi,ecx
   147db:	cmp    eax,0x17090
   147e0:	je     0x14810
   147e2:	cmp    eax,ecx
   147e4:	jb     0x14810
   147e6:	mov    eax,DWORD PTR [esi+0x24]
   147e9:	push   esi
   147ea:	push   DWORD PTR ds:0x1770c
   147f0:	push   DWORD PTR [ebp+0x8]
   147f3:	test   eax,eax
   147f5:	je     0x14800
   147f7:	push   0x15624
   147fc:	call   eax
   147fe:	jmp    0x14805
   14800:	call   0x15624
   14805:	add    esi,0x2c
   14808:	cmp    esi,DWORD PTR ds:0x1709c
   1480e:	jbe    0x147e6
   14810:	pop    esi
   14811:	pop    ebp
   14812:	ret    0x4
   14815:	int3
   14816:	int3
   14817:	int3
   14818:	int3
   14819:	int3
   1481a:	mov    ecx,0x170a8
   1481f:	mov    edx,ecx
   14821:	mov    eax,0x170a8
   14826:	cmp    edx,eax
   14828:	jae    0x14851
   1482a:	push   esi
   1482b:	push   edi
   1482c:	sub    eax,ecx
   1482e:	push   0x14
   14830:	dec    eax
   14831:	xor    edx,edx
   14833:	pop    ecx
   14834:	div    ecx
   14836:	mov    edi,0x170b8
   1483b:	mov    esi,eax
   1483d:	inc    esi
   1483e:	mov    eax,DWORD PTR [edi]
   14840:	test   eax,eax
   14842:	je     0x14849
   14844:	call   eax
   14846:	mov    DWORD PTR [edi-0x4],eax
   14849:	add    edi,0x14
   1484c:	dec    esi
   1484d:	jne    0x1483e
   1484f:	pop    edi
   14850:	pop    esi
   14851:	ret
   14852:	int3
   14853:	int3
   14854:	int3
   14855:	int3
   14856:	int3
   14857:	int3
   14858:	mov    edi,edi
   1485a:	push   ebp
   1485b:	mov    ebp,esp
   1485d:	mov    ecx,DWORD PTR [ebp+0x8]
   14860:	xor    eax,eax
   14862:	test   ecx,ecx
   14864:	jne    0x1486f
   14866:	test   DWORD PTR [ebp+0x10],0x100
   1486d:	jne    0x148ab
   1486f:	push   ebx
   14870:	movzx  ebx,WORD PTR [ecx]
   14873:	test   bl,0x1
   14876:	jne    0x148a5
   14878:	movzx  edx,WORD PTR [ecx+0x2]
   1487c:	test   dl,0x1
   1487f:	jne    0x148a5
   14881:	cmp    bx,dx
   14884:	ja     0x148a5
   14886:	push   esi
   14887:	mov    esi,DWORD PTR [ebp+0xc]
   1488a:	push   edi
   1488b:	movzx  edi,dx
   1488e:	add    esi,esi
   14890:	cmp    edi,esi
   14892:	pop    edi
   14893:	pop    esi
   14894:	ja     0x148a5
   14896:	cmp    DWORD PTR [ecx+0x4],eax
   14899:	jne    0x148aa
   1489b:	test   bx,bx
   1489e:	jne    0x148a5
   148a0:	test   dx,dx
   148a3:	je     0x148aa
   148a5:	mov    eax,0xc000000d
   148aa:	pop    ebx
   148ab:	pop    ebp
   148ac:	ret    0xc
   148af:	int3
   148b0:	int3
   148b1:	int3
   148b2:	int3
   148b3:	int3
   148b4:	mov    edi,edi
   148b6:	push   ebp
   148b7:	mov    ebp,esp
   148b9:	mov    eax,DWORD PTR [ebp+0x14]
   148bc:	push   ebx
   148bd:	mov    ebx,DWORD PTR [ebp+0x10]
   148c0:	push   esi
   148c1:	xor    ecx,ecx
   148c3:	push   edi
   148c4:	mov    edi,DWORD PTR [ebp+0xc]
   148c7:	mov    DWORD PTR [edi],ecx
   148c9:	mov    DWORD PTR [ebx],ecx
   148cb:	cmp    eax,ecx
   148cd:	je     0x148d1
   148cf:	mov    DWORD PTR [eax],ecx
   148d1:	push   DWORD PTR [ebp+0x1c]
   148d4:	mov    esi,DWORD PTR [ebp+0x8]
   148d7:	push   DWORD PTR [ebp+0x18]
   148da:	push   esi
   148db:	call   0x14858
   148e0:	test   eax,eax
   148e2:	jl     0x14903
   148e4:	test   esi,esi
   148e6:	je     0x14903
   148e8:	mov    ecx,DWORD PTR [esi+0x4]
   148eb:	mov    DWORD PTR [edi],ecx
   148ed:	movzx  ecx,WORD PTR [esi+0x2]
   148f1:	shr    ecx,1
   148f3:	mov    DWORD PTR [ebx],ecx
   148f5:	mov    ecx,DWORD PTR [ebp+0x14]
   148f8:	test   ecx,ecx
   148fa:	je     0x14903
   148fc:	movzx  edx,WORD PTR [esi]
   148ff:	shr    edx,1
   14901:	mov    DWORD PTR [ecx],edx
   14903:	pop    edi
   14904:	pop    esi
   14905:	pop    ebx
   14906:	pop    ebp
   14907:	ret    0x18
   1490a:	int3
   1490b:	int3
   1490c:	int3
   1490d:	int3
   1490e:	int3
   1490f:	int3
   14910:	mov    edi,edi
   14912:	push   ebp
   14913:	mov    ebp,esp
   14915:	push   esi
   14916:	mov    esi,DWORD PTR [ebp+0xc]
   14919:	push   edi
   1491a:	push   DWORD PTR [ebp+0x18]
   1491d:	xor    edi,edi
   1491f:	push   DWORD PTR [ebp+0x14]
   14922:	push   esi
   14923:	push   DWORD PTR [ebp+0x8]
   14926:	call   0x14a17
   1492b:	add    esp,0x10
   1492e:	test   eax,eax
   14930:	jl     0x1493d
   14932:	cmp    eax,esi
   14934:	ja     0x1493d
   14936:	mov    ecx,DWORD PTR [ebp+0x10]
   14939:	mov    DWORD PTR [ecx],eax
   1493b:	jmp    0x14947
   1493d:	mov    eax,DWORD PTR [ebp+0x10]
   14940:	mov    DWORD PTR [eax],esi
   14942:	mov    edi,0x80000005
   14947:	mov    eax,edi
   14949:	pop    edi
   1494a:	pop    esi
   1494b:	pop    ebp
   1494c:	ret    0x14
   1494f:	int3
   14950:	int3
   14951:	int3
   14952:	int3
   14953:	int3
   14954:	mov    edi,edi
   14956:	push   ebp
   14957:	mov    ebp,esp
   14959:	sub    esp,0x20
   1495c:	push   ebx
   1495d:	xor    ebx,ebx
   1495f:	cmp    DWORD PTR [ebp+0x10],ebx
   14962:	jne    0x14979
   14964:	push   ebx
   14965:	push   ebx
   14966:	push   ebx
   14967:	push   ebx
   14968:	push   ebx
   14969:	call   0x14a4f
   1496e:	add    esp,0x14
   14971:	or     eax,0xffffffff
   14974:	jmp    0x14a0f
   14979:	mov    eax,DWORD PTR [ebp+0xc]
   1497c:	push   esi
   1497d:	mov    esi,DWORD PTR [ebp+0x8]
   14980:	cmp    eax,ebx
   14982:	je     0x1499a
   14984:	cmp    esi,ebx
   14986:	jne    0x1499a
   14988:	push   ebx
   14989:	push   ebx
   1498a:	push   ebx
   1498b:	push   ebx
   1498c:	push   ebx
   1498d:	call   0x14a4f
   14992:	add    esp,0x14
   14995:	or     eax,0xffffffff
   14998:	jmp    0x14a0e
   1499a:	mov    DWORD PTR [ebp-0x14],0x42
   149a1:	mov    DWORD PTR [ebp-0x18],esi
   149a4:	mov    DWORD PTR [ebp-0x20],esi
   149a7:	cmp    eax,0x3fffffff
   149ac:	jbe    0x149b7
   149ae:	mov    DWORD PTR [ebp-0x1c],0x7fffffff
   149b5:	jmp    0x149bc
   149b7:	add    eax,eax
   149b9:	mov    DWORD PTR [ebp-0x1c],eax
   149bc:	push   edi
   149bd:	push   DWORD PTR [ebp+0x18]
   149c0:	lea    eax,[ebp-0x20]
   149c3:	push   DWORD PTR [ebp+0x14]
   149c6:	push   DWORD PTR [ebp+0x10]
   149c9:	push   eax
   149ca:	call   0x14b17
   149cf:	add    esp,0x10
   149d2:	mov    edi,eax
   149d4:	cmp    esi,ebx
   149d6:	je     0x14a0d
   149d8:	dec    DWORD PTR [ebp-0x1c]
   149db:	js     0x149e7
   149dd:	mov    eax,DWORD PTR [ebp-0x20]
   149e0:	mov    BYTE PTR [eax],bl
   149e2:	inc    DWORD PTR [ebp-0x20]
   149e5:	jmp    0x149f3
   149e7:	lea    eax,[ebp-0x20]
   149ea:	push   eax
   149eb:	push   ebx
   149ec:	call   0x14a39
   149f1:	pop    ecx
   149f2:	pop    ecx
   149f3:	dec    DWORD PTR [ebp-0x1c]
   149f6:	js     0x149ff
   149f8:	mov    eax,DWORD PTR [ebp-0x20]
   149fb:	mov    BYTE PTR [eax],bl
   149fd:	jmp    0x14a0b
   149ff:	lea    eax,[ebp-0x20]
   14a02:	push   eax
   14a03:	push   ebx
   14a04:	call   0x14a39
   14a09:	pop    ecx
   14a0a:	pop    ecx
   14a0b:	mov    eax,edi
   14a0d:	pop    edi
   14a0e:	pop    esi
   14a0f:	pop    ebx
   14a10:	leave
   14a11:	ret
   14a12:	int3
   14a13:	int3
   14a14:	int3
   14a15:	int3
   14a16:	int3
   14a17:	mov    edi,edi
   14a19:	push   ebp
   14a1a:	mov    ebp,esp
   14a1c:	push   DWORD PTR [ebp+0x14]
   14a1f:	push   0x0
   14a21:	push   DWORD PTR [ebp+0x10]
   14a24:	push   DWORD PTR [ebp+0xc]
   14a27:	push   DWORD PTR [ebp+0x8]
   14a2a:	call   0x14954
   14a2f:	add    esp,0x14
   14a32:	pop    ebp
   14a33:	ret
   14a34:	int3
   14a35:	int3
   14a36:	int3
   14a37:	int3
   14a38:	int3
   14a39:	mov    edi,edi
   14a3b:	push   ebp
   14a3c:	mov    ebp,esp
   14a3e:	mov    eax,DWORD PTR [ebp+0xc]
   14a41:	or     DWORD PTR [eax+0xc],0x20
   14a45:	or     eax,0xffffffff
   14a48:	pop    ebp
   14a49:	ret
   14a4a:	int3
   14a4b:	int3
   14a4c:	int3
   14a4d:	int3
   14a4e:	int3
   14a4f:	ret
   14a50:	int3
   14a51:	int3
   14a52:	int3
   14a53:	int3
   14a54:	int3
   14a55:	mov    edi,edi
   14a57:	push   ebp
   14a58:	mov    ebp,esp
   14a5a:	test   BYTE PTR [esi+0xc],0x40
   14a5e:	je     0x14a66
   14a60:	cmp    DWORD PTR [esi+0x8],0x0
   14a64:	je     0x14a86
   14a66:	push   esi
   14a67:	push   DWORD PTR [ebp+0x8]
   14a6a:	call   0x1554a
   14a6f:	pop    ecx
   14a70:	pop    ecx
   14a71:	mov    ecx,0xffff
   14a76:	cmp    ax,cx
   14a79:	jne    0x14a86
   14a7b:	test   BYTE PTR [esi+0xc],0x20
   14a7f:	je     0x14a86
   14a81:	or     DWORD PTR [edi],0xffffffff
   14a84:	pop    ebp
   14a85:	ret
   14a86:	inc    DWORD PTR [edi]
   14a88:	pop    ebp
   14a89:	ret
   14a8a:	int3
   14a8b:	int3
   14a8c:	int3
   14a8d:	int3
   14a8e:	int3
   14a8f:	mov    edi,edi
   14a91:	push   ebp
   14a92:	mov    ebp,esp
   14a94:	cmp    DWORD PTR [ebp+0xc],0x0
   14a98:	push   edi
   14a99:	mov    edi,eax
   14a9b:	jle    0x14ab9
   14a9d:	push   esi
   14a9e:	push   DWORD PTR [ebp+0x8]
   14aa1:	mov    esi,DWORD PTR [ebp+0x10]
   14aa4:	dec    DWORD PTR [ebp+0xc]
   14aa7:	call   0x14a55
   14aac:	cmp    DWORD PTR [edi],0xffffffff
   14aaf:	pop    ecx
   14ab0:	je     0x14ab8
   14ab2:	cmp    DWORD PTR [ebp+0xc],0x0
   14ab6:	jg     0x14a9e
   14ab8:	pop    esi
   14ab9:	pop    edi
   14aba:	pop    ebp
   14abb:	ret
   14abc:	int3
   14abd:	int3
   14abe:	int3
   14abf:	int3
   14ac0:	int3
   14ac1:	mov    edi,edi
   14ac3:	push   ebp
   14ac4:	mov    ebp,esp
   14ac6:	push   ebx
   14ac7:	push   esi
   14ac8:	mov    esi,ecx
   14aca:	test   BYTE PTR [esi+0xc],0x40
   14ace:	push   edi
   14acf:	mov    edi,eax
   14ad1:	mov    ebx,edx
   14ad3:	je     0x14b07
   14ad5:	cmp    DWORD PTR [esi+0x8],0x0
   14ad9:	jne    0x14b07
   14adb:	mov    eax,DWORD PTR [ebp+0x8]
   14ade:	add    DWORD PTR [edi],eax
   14ae0:	jmp    0x14b0d
   14ae2:	movzx  eax,WORD PTR [ebx]
   14ae5:	dec    DWORD PTR [ebp+0x8]
   14ae8:	push   eax
   14ae9:	call   0x14a55
   14aee:	inc    ebx
   14aef:	inc    ebx
   14af0:	cmp    DWORD PTR [edi],0xffffffff
   14af3:	pop    ecx
   14af4:	jne    0x14b07
   14af6:	cmp    DWORD PTR ds:0x17928,0x2a
   14afd:	jne    0x14b0d
   14aff:	push   0x3f
   14b01:	call   0x14a55
   14b06:	pop    ecx
   14b07:	cmp    DWORD PTR [ebp+0x8],0x0
   14b0b:	jg     0x14ae2
   14b0d:	pop    edi
   14b0e:	pop    esi
   14b0f:	pop    ebx
   14b10:	pop    ebp
   14b11:	ret
   14b12:	int3
   14b13:	int3
   14b14:	int3
   14b15:	int3
   14b16:	int3
   14b17:	mov    edi,edi
   14b19:	push   ebp
   14b1a:	mov    ebp,esp
   14b1c:	sub    esp,0x454
   14b22:	mov    eax,ds:0x17044
   14b27:	xor    eax,ebp
   14b29:	mov    DWORD PTR [ebp-0x4],eax
   14b2c:	mov    eax,DWORD PTR [ebp+0x8]
   14b2f:	mov    ecx,DWORD PTR [ebp+0x14]
   14b32:	push   edi
   14b33:	xor    edi,edi
   14b35:	mov    DWORD PTR [ebp-0x42c],eax
   14b3b:	mov    DWORD PTR [ebp-0x41c],ecx
   14b41:	mov    DWORD PTR [ebp-0x440],edi
   14b47:	mov    DWORD PTR [ebp-0x408],edi
   14b4d:	mov    DWORD PTR [ebp-0x430],edi
   14b53:	mov    DWORD PTR [ebp-0x40c],edi
   14b59:	mov    DWORD PTR [ebp-0x424],edi
   14b5f:	mov    DWORD PTR [ebp-0x43c],edi
   14b65:	mov    DWORD PTR [ebp-0x428],edi
   14b6b:	cmp    eax,edi
   14b6d:	jne    0x14b84
   14b6f:	push   edi
   14b70:	push   edi
   14b71:	push   edi
   14b72:	push   edi
   14b73:	push   edi
   14b74:	call   0x14a4f
   14b79:	add    esp,0x14
   14b7c:	or     eax,0xffffffff
   14b7f:	jmp    0x15462
   14b84:	mov    edx,DWORD PTR [ebp+0xc]
   14b87:	cmp    edx,edi
   14b89:	je     0x14b6f
   14b8b:	push   ebx
   14b8c:	push   esi
   14b8d:	movzx  esi,WORD PTR [edx]
   14b90:	mov    DWORD PTR [ebp-0x418],edi
   14b96:	mov    DWORD PTR [ebp-0x414],edi
   14b9c:	cmp    si,di
   14b9f:	je     0x1545a
   14ba5:	push   0x2
   14ba7:	pop    ebx
   14ba8:	add    edx,ebx
   14baa:	cmp    DWORD PTR [ebp-0x418],0x0
   14bb1:	mov    DWORD PTR [ebp+0xc],edx
   14bb4:	jl     0x1545a
   14bba:	lea    eax,[esi-0x20]
   14bbd:	cmp    ax,0x58
   14bc1:	ja     0x14bd2
   14bc3:	movzx  eax,si
   14bc6:	movsx  eax,BYTE PTR [eax+0x160f0]
   14bcd:	and    eax,0xf
   14bd0:	jmp    0x14bd4
   14bd2:	xor    eax,eax
   14bd4:	movsx  eax,BYTE PTR [edi+eax*8+0x16110]
   14bdc:	push   0x7
   14bde:	sar    eax,0x4
   14be1:	pop    edi
   14be2:	mov    DWORD PTR [ebp-0x448],eax
   14be8:	cmp    eax,edi
   14bea:	ja     0x1542a
   14bf0:	jmp    DWORD PTR [eax*4+0x1546f]
   14bf7:	xor    eax,eax
   14bf9:	or     DWORD PTR [ebp-0x40c],0xffffffff
   14c00:	mov    DWORD PTR [ebp-0x43c],eax
   14c06:	mov    DWORD PTR [ebp-0x430],eax
   14c0c:	mov    DWORD PTR [ebp-0x424],eax
   14c12:	mov    DWORD PTR [ebp-0x408],eax
   14c18:	mov    DWORD PTR [ebp-0x428],eax
   14c1e:	jmp    0x1542a
   14c23:	movzx  eax,si
   14c26:	sub    eax,0x20
   14c29:	je     0x14c75
   14c2b:	sub    eax,0x3
   14c2e:	je     0x14c66
   14c30:	sub    eax,0x8
   14c33:	je     0x14c5a
   14c35:	sub    eax,ebx
   14c37:	je     0x14c4e
   14c39:	sub    eax,0x3
   14c3c:	jne    0x1542a
   14c42:	or     DWORD PTR [ebp-0x408],0x8
   14c49:	jmp    0x1542a
   14c4e:	or     DWORD PTR [ebp-0x408],0x4
   14c55:	jmp    0x1542a
   14c5a:	or     DWORD PTR [ebp-0x408],0x1
   14c61:	jmp    0x1542a
   14c66:	or     DWORD PTR [ebp-0x408],0x80
   14c70:	jmp    0x1542a
   14c75:	or     DWORD PTR [ebp-0x408],ebx
   14c7b:	jmp    0x1542a
   14c80:	cmp    si,0x2a
   14c84:	jne    0x14cb2
   14c86:	add    ecx,0x4
   14c89:	mov    DWORD PTR [ebp-0x41c],ecx
   14c8f:	mov    ecx,DWORD PTR [ecx-0x4]
   14c92:	mov    DWORD PTR [ebp-0x430],ecx
   14c98:	test   ecx,ecx
   14c9a:	jge    0x1542a
   14ca0:	or     DWORD PTR [ebp-0x408],0x4
   14ca7:	neg    DWORD PTR [ebp-0x430]
   14cad:	jmp    0x1542a
   14cb2:	mov    eax,DWORD PTR [ebp-0x430]
   14cb8:	imul   eax,eax,0xa
   14cbb:	movzx  ecx,si
   14cbe:	lea    eax,[eax+ecx*1-0x30]
   14cc2:	mov    DWORD PTR [ebp-0x430],eax
   14cc8:	jmp    0x1542a
   14ccd:	and    DWORD PTR [ebp-0x40c],0x0
   14cd4:	jmp    0x1542a
   14cd9:	cmp    si,0x2a
   14cdd:	jne    0x14d05
   14cdf:	add    ecx,0x4
   14ce2:	mov    DWORD PTR [ebp-0x41c],ecx
   14ce8:	mov    ecx,DWORD PTR [ecx-0x4]
   14ceb:	mov    DWORD PTR [ebp-0x40c],ecx
   14cf1:	test   ecx,ecx
   14cf3:	jge    0x1542a
   14cf9:	or     DWORD PTR [ebp-0x40c],0xffffffff
   14d00:	jmp    0x1542a
   14d05:	mov    eax,DWORD PTR [ebp-0x40c]
   14d0b:	imul   eax,eax,0xa
   14d0e:	movzx  ecx,si
   14d11:	lea    eax,[eax+ecx*1-0x30]
   14d15:	mov    DWORD PTR [ebp-0x40c],eax
   14d1b:	jmp    0x1542a
   14d20:	movzx  eax,si
   14d23:	cmp    eax,0x49
   14d26:	je     0x14d7c
   14d28:	cmp    eax,0x68
   14d2b:	je     0x14d70
   14d2d:	cmp    eax,0x6c
   14d30:	je     0x14d4a
   14d32:	cmp    eax,0x77
   14d35:	jne    0x1542a
   14d3b:	or     DWORD PTR [ebp-0x408],0x800
   14d45:	jmp    0x1542a
   14d4a:	cmp    WORD PTR [edx],0x6c
   14d4e:	jne    0x14d64
   14d50:	add    edx,ebx
   14d52:	or     DWORD PTR [ebp-0x408],0x1000
   14d5c:	mov    DWORD PTR [ebp+0xc],edx
   14d5f:	jmp    0x1542a
   14d64:	or     DWORD PTR [ebp-0x408],0x10
   14d6b:	jmp    0x1542a
   14d70:	or     DWORD PTR [ebp-0x408],0x20
   14d77:	jmp    0x1542a
   14d7c:	movzx  eax,WORD PTR [edx]
   14d7f:	cmp    ax,0x36
   14d83:	jne    0x14da1
   14d85:	cmp    WORD PTR [edx+0x2],0x34
   14d8a:	jne    0x14da1
   14d8c:	add    edx,0x4
   14d8f:	or     DWORD PTR [ebp-0x408],0x8000
   14d99:	mov    DWORD PTR [ebp+0xc],edx
   14d9c:	jmp    0x1542a
   14da1:	cmp    ax,0x33
   14da5:	jne    0x14dc3
   14da7:	cmp    WORD PTR [edx+0x2],0x32
   14dac:	jne    0x14dc3
   14dae:	add    edx,0x4
   14db1:	and    DWORD PTR [ebp-0x408],0xffff7fff
   14dbb:	mov    DWORD PTR [ebp+0xc],edx
   14dbe:	jmp    0x1542a
   14dc3:	cmp    ax,0x64
   14dc7:	je     0x1542a
   14dcd:	cmp    ax,0x69
   14dd1:	je     0x1542a
   14dd7:	cmp    ax,0x6f
   14ddb:	je     0x1542a
   14de1:	cmp    ax,0x75
   14de5:	je     0x1542a
   14deb:	cmp    ax,0x78
   14def:	je     0x1542a
   14df5:	cmp    ax,0x58
   14df9:	je     0x1542a
   14dff:	and    DWORD PTR [ebp-0x448],0x0
   14e06:	push   esi
   14e07:	mov    esi,DWORD PTR [ebp-0x42c]
   14e0d:	lea    edi,[ebp-0x418]
   14e13:	mov    DWORD PTR [ebp-0x428],0x1
   14e1d:	call   0x14a55
   14e22:	pop    ecx
   14e23:	jmp    0x1542a
   14e28:	movzx  eax,si
   14e2b:	cmp    eax,0x69
   14e2e:	jg     0x15029
   14e34:	je     0x14e65
   14e36:	sub    eax,0x43
   14e39:	je     0x14f9f
   14e3f:	sub    eax,0x10
   14e42:	je     0x14f12
   14e48:	sub    eax,0x5
   14e4b:	je     0x150a1
   14e51:	sub    eax,ebx
   14e53:	je     0x14e7b
   14e55:	sub    eax,0x9
   14e58:	je     0x14fb2
   14e5e:	dec    eax
   14e5f:	jne    0x15282
   14e65:	or     DWORD PTR [ebp-0x408],0x40
   14e6c:	mov    DWORD PTR [ebp-0x420],0xa
   14e76:	jmp    0x150f9
   14e7b:	mov    eax,DWORD PTR [ecx]
   14e7d:	add    ecx,0x4
   14e80:	mov    DWORD PTR [ebp-0x41c],ecx
   14e86:	test   eax,eax
   14e88:	je     0x14ef9
   14e8a:	mov    esi,DWORD PTR [eax+0x4]
   14e8d:	test   esi,esi
   14e8f:	je     0x14ef9
   14e91:	movzx  ecx,WORD PTR [eax]
   14e94:	cmp    WORD PTR [eax+0x2],cx
   14e98:	jb     0x15446
   14e9e:	test   DWORD PTR [ebp-0x408],0x800
   14ea8:	movzx  eax,cx
   14eab:	je     0x14ee1
   14ead:	xor    ecx,ecx
   14eaf:	mov    edx,eax
   14eb1:	not    edx
   14eb3:	inc    ecx
   14eb4:	test   cl,dl
   14eb6:	je     0x15446
   14ebc:	mov    edx,esi
   14ebe:	not    edx
   14ec0:	test   cl,dl
   14ec2:	je     0x15446
   14ec8:	shr    eax,1
   14eca:	mov    DWORD PTR [ebp-0x410],esi
   14ed0:	mov    DWORD PTR [ebp-0x414],eax
   14ed6:	mov    DWORD PTR [ebp-0x428],ecx
   14edc:	jmp    0x15282
   14ee1:	and    DWORD PTR [ebp-0x428],0x0
   14ee8:	mov    DWORD PTR [ebp-0x410],esi
   14eee:	mov    DWORD PTR [ebp-0x414],eax
   14ef4:	jmp    0x15282
   14ef9:	mov    eax,ds:0x1706c
   14efe:	mov    DWORD PTR [ebp-0x410],eax
   14f04:	lea    edx,[eax+0x1]
   14f07:	mov    cl,BYTE PTR [eax]
   14f09:	inc    eax
   14f0a:	test   cl,cl
   14f0c:	jne    0x14f07
   14f0e:	sub    eax,edx
   14f10:	jmp    0x14eee
   14f12:	test   DWORD PTR [ebp-0x408],0x830
   14f1c:	jne    0x14f25
   14f1e:	or     DWORD PTR [ebp-0x408],0x20
   14f25:	cmp    DWORD PTR [ebp-0x40c],0xffffffff
   14f2c:	mov    edx,0x7fffffff
   14f31:	je     0x14f39
   14f33:	mov    edx,DWORD PTR [ebp-0x40c]
   14f39:	add    ecx,0x4
   14f3c:	test   BYTE PTR [ebp-0x408],0x20
   14f43:	mov    DWORD PTR [ebp-0x41c],ecx
   14f49:	mov    ecx,DWORD PTR [ecx-0x4]
   14f4c:	mov    DWORD PTR [ebp-0x410],ecx
   14f52:	je     0x15062
   14f58:	test   ecx,ecx
   14f5a:	jne    0x14f67
   14f5c:	mov    eax,ds:0x1706c
   14f61:	mov    DWORD PTR [ebp-0x410],eax
   14f67:	and    DWORD PTR [ebp-0x414],0x0
   14f6e:	test   edx,edx
   14f70:	jle    0x15282
   14f76:	mov    eax,DWORD PTR [ebp-0x410]
   14f7c:	mov    ecx,DWORD PTR [ebp-0x414]
   14f82:	cmp    BYTE PTR [eax+ecx*1],0x0
   14f86:	je     0x15282
   14f8c:	inc    DWORD PTR [ebp-0x414]
   14f92:	cmp    DWORD PTR [ebp-0x414],edx
   14f98:	jl     0x14f76
   14f9a:	jmp    0x15282
   14f9f:	test   DWORD PTR [ebp-0x408],0x830
   14fa9:	jne    0x14fb2
   14fab:	or     DWORD PTR [ebp-0x408],0x20
   14fb2:	movzx  eax,WORD PTR [ecx]
   14fb5:	add    ecx,0x4
   14fb8:	xor    edi,edi
   14fba:	inc    edi
   14fbb:	test   BYTE PTR [ebp-0x408],0x20
   14fc2:	mov    DWORD PTR [ebp-0x428],edi
   14fc8:	mov    DWORD PTR [ebp-0x41c],ecx
   14fce:	mov    DWORD PTR [ebp-0x44c],eax
   14fd4:	je     0x1500b
   14fd6:	push   DWORD PTR ds:0x17080
   14fdc:	mov    BYTE PTR [ebp-0x438],al
   14fe2:	lea    eax,[ebp-0x438]
   14fe8:	push   eax
   14fe9:	lea    eax,[ebp-0x404]
   14fef:	push   eax
   14ff0:	mov    BYTE PTR [ebp-0x437],0x0
   14ff7:	call   0x15594
   14ffc:	add    esp,0xc
   14fff:	test   eax,eax
   15001:	jge    0x15012
   15003:	mov    DWORD PTR [ebp-0x43c],edi
   15009:	jmp    0x15012
   1500b:	mov    WORD PTR [ebp-0x404],ax
   15012:	lea    eax,[ebp-0x404]
   15018:	mov    DWORD PTR [ebp-0x410],eax
   1501e:	mov    DWORD PTR [ebp-0x414],edi
   15024:	jmp    0x15282
   15029:	sub    eax,0x6e
   1502c:	je     0x15243
   15032:	dec    eax
   15033:	je     0x150dc
   15039:	dec    eax
   1503a:	je     0x15097
   1503c:	sub    eax,0x3
   1503f:	je     0x14f25
   15045:	sub    eax,ebx
   15047:	je     0x14e6c
   1504d:	sub    eax,0x3
   15050:	jne    0x15282
   15056:	mov    DWORD PTR [ebp-0x440],0x27
   15060:	jmp    0x150a7
   15062:	test   ecx,ecx
   15064:	jne    0x15073
   15066:	mov    eax,ds:0x17070
   1506b:	mov    DWORD PTR [ebp-0x410],eax
   15071:	mov    ecx,eax
   15073:	mov    DWORD PTR [ebp-0x428],0x1
   1507d:	mov    eax,ecx
   1507f:	jmp    0x1508a
   15081:	dec    edx
   15082:	cmp    WORD PTR [eax],0x0
   15086:	je     0x1508e
   15088:	add    eax,ebx
   1508a:	test   edx,edx
   1508c:	jne    0x15081
   1508e:	sub    eax,ecx
   15090:	sar    eax,1
   15092:	jmp    0x14eee
   15097:	mov    DWORD PTR [ebp-0x40c],0x8
   150a1:	mov    DWORD PTR [ebp-0x440],edi
   150a7:	test   BYTE PTR [ebp-0x408],0x80
   150ae:	mov    DWORD PTR [ebp-0x420],0x10
   150b8:	je     0x150f9
   150ba:	push   0x30
   150bc:	pop    eax
   150bd:	mov    WORD PTR [ebp-0x434],ax
   150c4:	mov    eax,DWORD PTR [ebp-0x440]
   150ca:	add    eax,0x51
   150cd:	mov    WORD PTR [ebp-0x432],ax
   150d4:	mov    DWORD PTR [ebp-0x424],ebx
   150da:	jmp    0x150f9
   150dc:	test   BYTE PTR [ebp-0x408],0x80
   150e3:	mov    DWORD PTR [ebp-0x420],0x8
   150ed:	je     0x150f9
   150ef:	or     DWORD PTR [ebp-0x408],0x200
   150f9:	mov    ebx,DWORD PTR [ebp-0x408]
   150ff:	test   ebx,0x8000
   15105:	je     0x15111
   15107:	mov    eax,DWORD PTR [ecx]
   15109:	mov    edx,DWORD PTR [ecx+0x4]
   1510c:	add    ecx,0x8
   1510f:	jmp    0x15146
   15111:	test   ebx,0x1000
   15117:	jne    0x15107
   15119:	add    ecx,0x4
   1511c:	test   bl,0x20
   1511f:	je     0x15139
   15121:	mov    DWORD PTR [ebp-0x41c],ecx
   15127:	test   bl,0x40
   1512a:	je     0x15132
   1512c:	movsx  eax,WORD PTR [ecx-0x4]
   15130:	jmp    0x15136
   15132:	movzx  eax,WORD PTR [ecx-0x4]
   15136:	cdq
   15137:	jmp    0x1514c
   15139:	mov    eax,DWORD PTR [ecx-0x4]
   1513c:	test   bl,0x40
   1513f:	je     0x15144
   15141:	cdq
   15142:	jmp    0x15146
   15144:	xor    edx,edx
   15146:	mov    DWORD PTR [ebp-0x41c],ecx
   1514c:	test   bl,0x40
   1514f:	je     0x1516c
   15151:	test   edx,edx
   15153:	jg     0x1516c
   15155:	jl     0x1515b
   15157:	test   eax,eax
   15159:	jae    0x1516c
   1515b:	neg    eax
   1515d:	adc    edx,0x0
   15160:	neg    edx
   15162:	or     DWORD PTR [ebp-0x408],0x100
   1516c:	test   DWORD PTR [ebp-0x408],0x9000
   15176:	mov    ebx,edx
   15178:	mov    esi,eax
   1517a:	jne    0x1517e
   1517c:	xor    ebx,ebx
   1517e:	cmp    DWORD PTR [ebp-0x40c],0x0
   15185:	jge    0x15193
   15187:	mov    DWORD PTR [ebp-0x40c],0x1
   15191:	jmp    0x151ad
   15193:	and    DWORD PTR [ebp-0x408],0xfffffff7
   1519a:	mov    eax,0x200
   1519f:	cmp    DWORD PTR [ebp-0x40c],eax
   151a5:	jle    0x151ad
   151a7:	mov    DWORD PTR [ebp-0x40c],eax
   151ad:	mov    eax,esi
   151af:	or     eax,ebx
   151b1:	jne    0x151b9
   151b3:	and    DWORD PTR [ebp-0x424],eax
   151b9:	lea    edi,[ebp-0x205]
   151bf:	mov    eax,DWORD PTR [ebp-0x40c]
   151c5:	dec    DWORD PTR [ebp-0x40c]
   151cb:	test   eax,eax
   151cd:	jg     0x151d5
   151cf:	mov    eax,esi
   151d1:	or     eax,ebx
   151d3:	je     0x15202
   151d5:	mov    eax,DWORD PTR [ebp-0x420]
   151db:	cdq
   151dc:	push   edx
   151dd:	push   eax
   151de:	push   ebx
   151df:	push   esi
   151e0:	call   0x154b0
   151e5:	add    ecx,0x30
   151e8:	cmp    ecx,0x39
   151eb:	mov    DWORD PTR [ebp-0x450],ebx
   151f1:	mov    esi,eax
   151f3:	mov    ebx,edx
   151f5:	jle    0x151fd
   151f7:	add    ecx,DWORD PTR [ebp-0x440]
   151fd:	mov    BYTE PTR [edi],cl
   151ff:	dec    edi
   15200:	jmp    0x151bf
   15202:	lea    eax,[ebp-0x205]
   15208:	sub    eax,edi
   1520a:	inc    edi
   1520b:	test   DWORD PTR [ebp-0x408],0x200
   15215:	mov    DWORD PTR [ebp-0x414],eax
   1521b:	mov    DWORD PTR [ebp-0x410],edi
   15221:	je     0x15282
   15223:	test   eax,eax
   15225:	je     0x1522e
   15227:	mov    ecx,edi
   15229:	cmp    BYTE PTR [ecx],0x30
   1522c:	je     0x15282
   1522e:	dec    DWORD PTR [ebp-0x410]
   15234:	mov    ecx,DWORD PTR [ebp-0x410]
   1523a:	mov    BYTE PTR [ecx],0x30
   1523d:	inc    eax
   1523e:	jmp    0x14eee
   15243:	mov    esi,DWORD PTR [ecx]
   15245:	add    ecx,0x4
   15248:	mov    DWORD PTR [ebp-0x41c],ecx
   1524e:	call   0x15494
   15253:	test   eax,eax
   15255:	je     0x15446
   1525b:	test   BYTE PTR [ebp-0x408],0x20
   15262:	je     0x15270
   15264:	mov    ax,WORD PTR [ebp-0x418]
   1526b:	mov    WORD PTR [esi],ax
   1526e:	jmp    0x15278
   15270:	mov    eax,DWORD PTR [ebp-0x418]
   15276:	mov    DWORD PTR [esi],eax
   15278:	mov    DWORD PTR [ebp-0x43c],0x1
   15282:	cmp    DWORD PTR [ebp-0x43c],0x0
   15289:	jne    0x1542a
   1528f:	mov    ecx,DWORD PTR [ebp-0x408]
   15295:	test   cl,0x40
   15298:	je     0x152d8
   1529a:	test   ecx,0x100
   152a0:	je     0x152a6
   152a2:	push   0x2d
   152a4:	jmp    0x152c6
   152a6:	xor    eax,eax
   152a8:	inc    eax
   152a9:	test   al,cl
   152ab:	je     0x152bf
   152ad:	push   0x2b
   152af:	pop    ecx
   152b0:	mov    WORD PTR [ebp-0x434],cx
   152b7:	mov    DWORD PTR [ebp-0x424],eax
   152bd:	jmp    0x152d8
   152bf:	test   cl,0x2
   152c2:	je     0x152d8
   152c4:	push   0x20
   152c6:	pop    eax
   152c7:	mov    DWORD PTR [ebp-0x424],0x1
   152d1:	mov    WORD PTR [ebp-0x434],ax
   152d8:	mov    ebx,DWORD PTR [ebp-0x430]
   152de:	mov    esi,DWORD PTR [ebp-0x414]
   152e4:	sub    ebx,esi
   152e6:	sub    ebx,DWORD PTR [ebp-0x424]
   152ec:	test   BYTE PTR [ebp-0x408],0xc
   152f3:	jne    0x1530c
   152f5:	push   DWORD PTR [ebp-0x42c]
   152fb:	lea    eax,[ebp-0x418]
   15301:	push   ebx
   15302:	push   0x20
   15304:	call   0x14a8f
   15309:	add    esp,0xc
   1530c:	push   DWORD PTR [ebp-0x424]
   15312:	mov    ecx,DWORD PTR [ebp-0x42c]
   15318:	lea    eax,[ebp-0x418]
   1531e:	lea    edx,[ebp-0x434]
   15324:	call   0x14ac1
   15329:	test   BYTE PTR [ebp-0x408],0x8
   15330:	pop    ecx
   15331:	je     0x15353
   15333:	test   BYTE PTR [ebp-0x408],0x4
   1533a:	jne    0x15353
   1533c:	push   DWORD PTR [ebp-0x42c]
   15342:	lea    eax,[ebp-0x418]
   15348:	push   ebx
   15349:	push   0x30
   1534b:	call   0x14a8f
   15350:	add    esp,0xc
   15353:	cmp    DWORD PTR [ebp-0x428],0x0
   1535a:	jne    0x153e8
   15360:	test   esi,esi
   15362:	jle    0x153e8
   15368:	mov    eax,DWORD PTR [ebp-0x410]
   1536e:	mov    DWORD PTR [ebp-0x444],eax
   15374:	mov    DWORD PTR [ebp-0x420],esi
   1537a:	push   DWORD PTR ds:0x17080
   15380:	dec    DWORD PTR [ebp-0x420]
   15386:	push   DWORD PTR [ebp-0x444]
   1538c:	lea    eax,[ebp-0x44c]
   15392:	push   eax
   15393:	call   0x15594
   15398:	add    esp,0xc
   1539b:	mov    DWORD PTR [ebp-0x450],eax
   153a1:	cmp    eax,0x2
   153a4:	jne    0x153ac
   153a6:	dec    DWORD PTR [ebp-0x420]
   153ac:	test   eax,eax
   153ae:	jle    0x153df
   153b0:	push   DWORD PTR [ebp-0x44c]
   153b6:	mov    esi,DWORD PTR [ebp-0x42c]
   153bc:	lea    edi,[ebp-0x418]
   153c2:	call   0x14a55
   153c7:	mov    eax,DWORD PTR [ebp-0x450]
   153cd:	add    DWORD PTR [ebp-0x444],eax
   153d3:	cmp    DWORD PTR [ebp-0x420],0x0
   153da:	pop    ecx
   153db:	jg     0x1537a
   153dd:	jmp    0x15401
   153df:	or     DWORD PTR [ebp-0x418],0xffffffff
   153e6:	jmp    0x15401
   153e8:	mov    ecx,DWORD PTR [ebp-0x42c]
   153ee:	mov    edx,DWORD PTR [ebp-0x410]
   153f4:	push   esi
   153f5:	lea    eax,[ebp-0x418]
   153fb:	call   0x14ac1
   15400:	pop    ecx
   15401:	cmp    DWORD PTR [ebp-0x418],0x0
   15408:	jl     0x1542a
   1540a:	test   BYTE PTR [ebp-0x408],0x4
   15411:	je     0x1542a
   15413:	push   DWORD PTR [ebp-0x42c]
   15419:	lea    eax,[ebp-0x418]
   1541f:	push   ebx
   15420:	push   0x20
   15422:	call   0x14a8f
   15427:	add    esp,0xc
   1542a:	mov    edx,DWORD PTR [ebp+0xc]
   1542d:	movzx  esi,WORD PTR [edx]
   15430:	test   si,si
   15433:	je     0x1545a
   15435:	mov    edi,DWORD PTR [ebp-0x448]
   1543b:	mov    ecx,DWORD PTR [ebp-0x41c]
   15441:	jmp    0x14ba5
   15446:	xor    eax,eax
   15448:	push   eax
   15449:	push   eax
   1544a:	push   eax
   1544b:	push   eax
   1544c:	push   eax
   1544d:	call   0x14a4f
   15452:	add    esp,0x14
   15455:	or     eax,0xffffffff
   15458:	jmp    0x15460
   1545a:	mov    eax,DWORD PTR [ebp-0x418]
   15460:	pop    esi
   15461:	pop    ebx
   15462:	mov    ecx,DWORD PTR [ebp-0x4]
   15465:	xor    ecx,ebp
   15467:	pop    edi
   15468:	call   0x145cc
   1546d:	leave
   1546e:	ret
   1546f:	push   es
   15470:	dec    esi
   15471:	add    DWORD PTR [eax],eax
   15473:	test   DWORD PTR [ebx+0x1],0x14c2300
   1547a:	add    BYTE PTR [eax-0x32fffeb4],al
   15480:	dec    esp
   15481:	add    DWORD PTR [eax],eax
   15483:	(bad)  [ecx+eax*1+0x0]
   15487:	and    BYTE PTR [ebp+0x1],cl
   1548a:	add    BYTE PTR [eax],ch
   1548c:	dec    esi
   1548d:	add    DWORD PTR [eax],eax
   1548f:	int3
   15490:	int3
   15491:	int3
   15492:	int3
   15493:	int3
   15494:	mov    eax,ds:0x17044
   15499:	or     eax,0x1
   1549c:	xor    ecx,ecx
   1549e:	cmp    DWORD PTR ds:0x17924,eax
   154a4:	sete   cl
   154a7:	mov    eax,ecx
   154a9:	ret
   154aa:	int3
   154ab:	int3
   154ac:	int3
   154ad:	int3
   154ae:	int3
   154af:	int3
   154b0:	push   esi
   154b1:	mov    eax,DWORD PTR [esp+0x14]
   154b5:	or     eax,eax
   154b7:	jne    0x154e1
   154b9:	mov    ecx,DWORD PTR [esp+0x10]
   154bd:	mov    eax,DWORD PTR [esp+0xc]
   154c1:	xor    edx,edx
   154c3:	div    ecx
   154c5:	mov    ebx,eax
   154c7:	mov    eax,DWORD PTR [esp+0x8]
   154cb:	div    ecx
   154cd:	mov    esi,eax
   154cf:	mov    eax,ebx
   154d1:	mul    DWORD PTR [esp+0x10]
   154d5:	mov    ecx,eax
   154d7:	mov    eax,esi
   154d9:	mul    DWORD PTR [esp+0x10]
   154dd:	add    edx,ecx
   154df:	jmp    0x15528
   154e1:	mov    ecx,eax
   154e3:	mov    ebx,DWORD PTR [esp+0x10]
   154e7:	mov    edx,DWORD PTR [esp+0xc]
   154eb:	mov    eax,DWORD PTR [esp+0x8]
   154ef:	shr    ecx,1
   154f1:	rcr    ebx,1
   154f3:	shr    edx,1
   154f5:	rcr    eax,1
   154f7:	or     ecx,ecx
   154f9:	jne    0x154ef
   154fb:	div    ebx
   154fd:	mov    esi,eax
   154ff:	mul    DWORD PTR [esp+0x14]
   15503:	mov    ecx,eax
   15505:	mov    eax,DWORD PTR [esp+0x10]
   15509:	mul    esi
   1550b:	add    edx,ecx
   1550d:	jb     0x1551d
   1550f:	cmp    edx,DWORD PTR [esp+0xc]
   15513:	ja     0x1551d
   15515:	jb     0x15526
   15517:	cmp    eax,DWORD PTR [esp+0x8]
   1551b:	jbe    0x15526
   1551d:	dec    esi
   1551e:	sub    eax,DWORD PTR [esp+0x10]
   15522:	sbb    edx,DWORD PTR [esp+0x14]
   15526:	xor    ebx,ebx
   15528:	sub    eax,DWORD PTR [esp+0x8]
   1552c:	sbb    edx,DWORD PTR [esp+0xc]
   15530:	neg    edx
   15532:	neg    eax
   15534:	sbb    edx,0x0
   15537:	mov    ecx,edx
   15539:	mov    edx,ebx
   1553b:	mov    ebx,ecx
   1553d:	mov    ecx,eax
   1553f:	mov    eax,esi
   15541:	pop    esi
   15542:	ret    0x10
   15545:	int3
   15546:	int3
   15547:	int3
   15548:	int3
   15549:	int3
   1554a:	mov    edi,edi
   1554c:	push   ebp
   1554d:	mov    ebp,esp
   1554f:	mov    ecx,DWORD PTR [ebp+0xc]
   15552:	xor    eax,eax
   15554:	cmp    ecx,eax
   15556:	jne    0x1556c
   15558:	push   eax
   15559:	push   eax
   1555a:	push   eax
   1555b:	push   eax
   1555c:	push   eax
   1555d:	call   0x14a4f
   15562:	add    esp,0x14
   15565:	mov    eax,0xffff
   1556a:	pop    ebp
   1556b:	ret
   1556c:	add    DWORD PTR [ecx+0x4],0xfffffffe
   15570:	js     0x15580
   15572:	mov    edx,DWORD PTR [ecx]
   15574:	mov    ax,WORD PTR [ebp+0x8]
   15578:	mov    WORD PTR [edx],ax
   1557b:	add    DWORD PTR [ecx],0x2
   1557e:	pop    ebp
   1557f:	ret
   15580:	movzx  eax,WORD PTR [ebp+0x8]
   15584:	push   ecx
   15585:	push   eax
   15586:	call   0x155db
   1558b:	pop    ecx
   1558c:	pop    ecx
   1558d:	pop    ebp
   1558e:	ret
   1558f:	int3
   15590:	int3
   15591:	int3
   15592:	int3
   15593:	int3
   15594:	mov    edi,edi
   15596:	push   ebp
   15597:	mov    ebp,esp
   15599:	push   esi
   1559a:	mov    esi,DWORD PTR [ebp+0xc]
   1559d:	test   esi,esi
   1559f:	je     0x155b8
   155a1:	cmp    DWORD PTR [ebp+0x10],0x0
   155a5:	je     0x155b8
   155a7:	cmp    BYTE PTR [esi],0x0
   155aa:	jne    0x155bd
   155ac:	mov    eax,DWORD PTR [ebp+0x8]
   155af:	test   eax,eax
   155b1:	je     0x155b8
   155b3:	xor    ecx,ecx
   155b5:	mov    WORD PTR [eax],cx
   155b8:	xor    eax,eax
   155ba:	pop    esi
   155bb:	pop    ebp
   155bc:	ret
   155bd:	lea    eax,[ebp+0xc]
   155c0:	push   eax
   155c1:	mov    DWORD PTR [ebp+0xc],esi
   155c4:	call   0x155f4
   155c9:	mov    ecx,DWORD PTR [ebp+0x8]
   155cc:	mov    WORD PTR [ecx],ax
   155cf:	mov    eax,DWORD PTR [ebp+0xc]
   155d2:	sub    eax,esi
   155d4:	jmp    0x155ba
   155d6:	int3
   155d7:	int3
   155d8:	int3
   155d9:	int3
   155da:	int3
   155db:	mov    edi,edi
   155dd:	push   ebp
   155de:	mov    ebp,esp
   155e0:	mov    eax,DWORD PTR [ebp+0xc]
   155e3:	or     DWORD PTR [eax+0xc],0x20
   155e7:	mov    eax,0xffff
   155ec:	pop    ebp
   155ed:	ret
   155ee:	int3
   155ef:	int3
   155f0:	int3
   155f1:	int3
   155f2:	int3
   155f3:	int3
   155f4:	jmp    DWORD PTR ds:0x16040
   155fa:	int3
   155fb:	int3
   155fc:	int3
   155fd:	int3
   155fe:	int3
   155ff:	int3
   15600:	jmp    DWORD PTR ds:0x16008
   15606:	int3
   15607:	int3
   15608:	int3
   15609:	int3
   1560a:	int3
   1560b:	int3
   1560c:	jmp    DWORD PTR ds:0x16004
   15612:	int3
   15613:	int3
   15614:	int3
   15615:	int3
   15616:	int3
   15617:	int3
   15618:	jmp    DWORD PTR ds:0x16000
   1561e:	int3
   1561f:	int3
   15620:	int3
   15621:	int3
   15622:	int3
   15623:	int3
   15624:	jmp    DWORD PTR ds:0x1600c
   1562a:	push   eax
   1562b:	add    BYTE PTR [edi+0x0],ch
   1562e:	jb     0x15630
   15630:	je     0x15632
   15632:	dec    esi
   15633:	add    BYTE PTR [ecx+0x0],ah
   15636:	ins    DWORD PTR es:[edi],dx
   15637:	add    BYTE PTR [ebp+0x0],ah
   1563a:	add    BYTE PTR [eax],al
   1563c:	push   ebx
   1563d:	add    BYTE PTR [ebp+0x0],al
   15640:	push   edx
   15641:	add    BYTE PTR [ecx+0x0],cl
   15644:	inc    ecx
   15645:	add    BYTE PTR [eax+eax*1+0x43],cl
   15649:	add    BYTE PTR [edi+0x0],cl
   1564c:	dec    ebp
   1564d:	add    BYTE PTR [ebp+0x0],cl
   15650:	add    BYTE PTR [eax],al
   15652:	and    eax,0x73007700
   15657:	add    BYTE PTR ds:0x73007700,ah
   1565d:	add    BYTE PTR [eax],al
   1565f:	add    BYTE PTR [eax+eax*1+0x44],bl
   15663:	add    BYTE PTR [edi+0x0],ch
   15666:	jae    0x15668
   15668:	inc    esp
   15669:	add    BYTE PTR [ebp+0x0],ah
   1566c:	jbe    0x1566e
   1566e:	imul   eax,DWORD PTR [eax],0x650063
   15674:	jae    0x15676
   15676:	pop    esp
   15677:	add    BYTE PTR [eax],al
   15679:	add    BYTE PTR [ebp+0x0],dl
   1567c:	jae    0x1567e
   1567e:	bound  eax,QWORD PTR [eax]
   15680:	inc    ebp
   15681:	add    BYTE PTR [esi+0x0],ch
   15684:	popa
   15685:	add    BYTE PTR [edx+0x0],ah
   15688:	ins    BYTE PTR es:[edi],dx
   15689:	add    BYTE PTR [ebp+0x0],ah
   1568c:	pop    edx
   1568d:	add    BYTE PTR [eax+eax*1+0x50],cl
   15691:	add    BYTE PTR [eax],al
   15693:	add    BYTE PTR [edx+0x0],al
   15696:	jne    0x15698
   15698:	ins    BYTE PTR es:[edi],dx
   15699:	add    BYTE PTR [ebx+0x0],ch
   1569c:	dec    ecx
   1569d:	add    BYTE PTR [esi+0x0],ch
   156a0:	inc    edx
   156a1:	add    BYTE PTR [ebp+0x0],dh
   156a4:	data16 add BYTE PTR [ebx+0x0],dl
   156a8:	imul   eax,DWORD PTR [eax],0x65007a
   156ae:	add    BYTE PTR [eax],al
   156b0:	push   edx
   156b1:	add    BYTE PTR [eax+0x0],bh
   156b4:	inc    esi
   156b5:	add    BYTE PTR [ecx+0x0],ch
   156b8:	data16 add BYTE PTR [edi+0x0],ch
   156bc:	push   ebx
   156bd:	add    BYTE PTR [ecx+0x0],ch
   156c0:	jp     0x156c2
   156c2:	add    BYTE PTR gs:[eax],al
   156c5:	add    BYTE PTR [ebp+0x0],dl
   156c8:	jae    0x156ca
   156ca:	add    BYTE PTR gs:[ebx+0x0],al
   156ce:	outs   dx,DWORD PTR ds:[esi]
   156cf:	add    BYTE PTR [esi+0x0],ch
   156d2:	je     0x156d4
   156d4:	imul   eax,DWORD PTR [eax],0x75006e
   156da:	outs   dx,DWORD PTR ds:[esi]
   156db:	add    BYTE PTR [ebp+0x0],dh
   156de:	jae    0x156e0
   156e0:	push   edx
   156e1:	add    BYTE PTR [ebp+0x0],ah
   156e4:	popa
   156e5:	add    BYTE PTR [eax+eax*1+0x0],ah
   156e9:	add    BYTE PTR [ebx+0x0],al
   156ec:	add    BYTE PTR fs:[ebx+0x0],ah
   156f0:	inc    ebx
   156f1:	add    BYTE PTR [edi+0x0],ch
   156f4:	outs   dx,BYTE PTR ds:[esi]
   156f5:	add    BYTE PTR [eax+eax*1+0x72],dh
   156f9:	add    BYTE PTR [edi+0x0],ch
   156fc:	ins    BYTE PTR es:[edi],dx
   156fd:	add    BYTE PTR [eax+eax*1+0x69],cl
   15701:	add    BYTE PTR [esi+0x0],ch
   15704:	add    BYTE PTR gs:[ebx+0x0],dl
   15708:	je     0x1570a
   1570a:	popa
   1570b:	add    BYTE PTR [eax+eax*1+0x65],dh
   1570f:	add    BYTE PTR [eax],al
   15711:	add    BYTE PTR [ebx+0x0],dl
   15714:	jo     0x15716
   15716:	jb     0x15718
   15718:	add    BYTE PTR fs:[esi+0x0],dl
   1571c:	add    BYTE PTR gs:[esi+0x0],ch
   15720:	add    BYTE PTR fs:[edi+0x0],ch
   15724:	jb     0x15726
   15726:	push   edx
   15727:	add    BYTE PTR [ebp+0x0],ah
   1572a:	jno    0x1572c
   1572c:	jne    0x1572e
   1572e:	add    BYTE PTR gs:[ebx+0x0],dh
   15732:	je     0x15734
   15734:	add    BYTE PTR [eax],al
   15736:	push   esi
   15737:	add    BYTE PTR [ebp+0x0],ah
   1573a:	outs   dx,BYTE PTR ds:[esi]
   1573b:	add    BYTE PTR [eax+eax*1+0x6f],ah
   1573f:	add    BYTE PTR [edx+0x0],dh
   15742:	push   edx
   15743:	add    BYTE PTR [ebp+0x0],ah
   15746:	jno    0x15748
   15748:	jne    0x1574a
   1574a:	add    BYTE PTR gs:[ebx+0x0],dh
   1574e:	je     0x15750
   15750:	push   esp
   15751:	add    BYTE PTR [ecx+0x0],ch
   15754:	ins    DWORD PTR es:[edi],dx
   15755:	add    BYTE PTR [ebp+0x0],ah
   15758:	outs   dx,DWORD PTR ds:[esi]
   15759:	add    BYTE PTR [ebp+0x0],dh
   1575c:	je     0x1575e
   1575e:	push   esi
   1575f:	add    BYTE PTR [ecx+0x0],ah
   15762:	ins    BYTE PTR es:[edi],dx
   15763:	add    BYTE PTR [ebp+0x0],dh
   15766:	add    BYTE PTR gs:[eax],al
   15769:	add    BYTE PTR ds:0x73007700,ah
   1576f:	add    BYTE PTR ds:0x6400,ah
   15775:	add    BYTE PTR [eax+eax*1+0x44],bl
   15779:	add    BYTE PTR [ebp+0x0],ah
   1577c:	jbe    0x1577e
   1577e:	imul   eax,DWORD PTR [eax],0x650063
   15784:	pop    esp
   15785:	add    BYTE PTR [ebx+0x0],dh
   15788:	jo     0x1578a
   1578a:	jb     0x1578c
   1578c:	add    BYTE PTR fs:[edi+0x0],bl
   15790:	jne    0x15792
   15792:	jae    0x15794
   15794:	bound  eax,QWORD PTR [eax]
   15796:	arpl   WORD PTR [eax],ax
   15798:	outs   dx,DWORD PTR ds:[esi]
   15799:	add    BYTE PTR [ebp+0x0],ch
   1579c:	ins    DWORD PTR es:[edi],dx
   1579d:	add    BYTE PTR [edi+0x0],bl
   157a0:	jae    0x157a2
   157a2:	add    BYTE PTR gs:[edx+0x0],dh
   157a6:	imul   eax,DWORD PTR [eax],0x6c0061
   157ac:	add    BYTE PTR [eax],al
   157ae:	inc    ebx
   157af:	dec    edi
   157b0:	dec    esi
   157b1:	dec    esi
   157b2:	inc    ebp
   157b3:	inc    ebx
   157b4:	push   esp
	...

Disassembly of section INIT:

00018000 <INIT>:
   18000:	add    BYTE PTR [eax],al
   18002:	add    BYTE PTR [eax],al
   18004:	add    BYTE PTR [ecx+0x17044],ah
   1800a:	mov    ecx,0xbb40e64e
   1800f:	test   eax,eax
   18011:	je     0x18017
   18013:	cmp    eax,ecx
   18015:	jne    0x18031
   18017:	mov    eax,ds:0x16034
   1801c:	mov    eax,DWORD PTR [eax]
   1801e:	xor    eax,0x17044
   18023:	mov    ds:0x17044,eax
   18028:	jne    0x18031
   1802a:	mov    eax,ecx
   1802c:	mov    ds:0x17044,eax
   18031:	not    eax
   18033:	mov    ds:0x17048,eax
   18038:	ret
   18039:	int3
   1803a:	int3
   1803b:	int3
   1803c:	mov    WORD PTR [eax+0x0],es
   18042:	add    BYTE PTR [eax],al
   18044:	add    BYTE PTR [eax],al
   18046:	add    BYTE PTR [eax],al
   18048:	out    dx,al
   18049:	add    DWORD PTR [eax],0x601400
   1804f:	add    BYTE PTR [eax-0x80],bh
	...
   1805a:	add    BYTE PTR [eax],al
   1805c:	test   BYTE PTR [edx+0x60000000],al
	...
   18076:	add    BYTE PTR [eax],al
   18078:	push   esi
   18079:	add    BYTE PTR [eax],0x0
   1807c:	inc    esp
   1807d:	add    BYTE PTR [eax],0x0
   18080:	xor    BYTE PTR [edx-0x7d940000],al
   18086:	add    BYTE PTR [eax],al
   18088:	add    BYTE PTR [eax],al
   1808a:	add    BYTE PTR [eax],al
   1808c:	xor    BYTE PTR [ecx-0x7ec20000],al
   18092:	add    BYTE PTR [eax],al
   18094:	dec    esi
   18095:	add    DWORD PTR [eax],0x816800
   1809b:	add    BYTE PTR [eax-0x63ffff7f],cl
   180a1:	add    DWORD PTR [eax],0x811800
   180a7:	add    BYTE PTR [edx-0x2fffff7f],bh
   180ad:	add    DWORD PTR [eax],0x81de00
   180b3:	add    ah,bh
   180b5:	add    DWORD PTR [eax],0x821400
   180bb:	add    BYTE PTR [eax],al
   180bd:	add    DWORD PTR [eax],0x80e800
   180c3:	add    dh,bl
   180c5:	add    BYTE PTR [eax],0x0
   180c8:	mov    al,0x81
   180ca:	add    BYTE PTR [eax],al
   180cc:	aam    0x80
   180ce:	add    BYTE PTR [eax],al
   180d0:	add    BYTE PTR [eax],al
   180d2:	add    BYTE PTR [eax],al
   180d4:	inc    BYTE PTR [edi]
   180d6:	pop    edi
   180d7:	popa
   180d8:	ins    BYTE PTR es:[edi],dx
   180d9:	ins    BYTE PTR es:[edi],dx
   180da:	ins    DWORD PTR es:[edi],dx
   180db:	jne    0x18149
   180dd:	add    BYTE PTR [edi+0x8],cl
   180e0:	ins    DWORD PTR es:[edi],dx
   180e1:	gs ins DWORD PTR es:[edi],dx
   180e3:	jae    0x1814a
   180e5:	je     0x180e7
   180e7:	add    BYTE PTR [ebp+0x57654b03],ah
   180ed:	popa
   180ee:	imul   esi,DWORD PTR [esi+eax*2+0x6f],0x6e695372
   180f6:	ins    BYTE PTR es:[di],dx
   180f8:	gs dec edi
   180fa:	bound  ebp,QWORD PTR [edx+0x65]
   180fd:	arpl   WORD PTR [eax+eax*1-0x12],si
   18101:	add    eax,0x496c7452
   18106:	outs   dx,BYTE PTR ds:[esi]
   18107:	imul   esi,DWORD PTR [ebp+edx*2+0x6e],0x646f6369
   1810f:	gs push ebx
   18111:	je     0x18185
   18113:	imul   ebp,DWORD PTR [esi+0x67],0x6a40000
   1811a:	push   edx
   1811b:	je     0x18189
   1811d:	push   edi
   1811e:	jb     0x18189
   18120:	je     0x18187
   18122:	push   edx
   18123:	imul   esi,DWORD PTR gs:[bp+di+0x74],0x61567972
   1812c:	ins    BYTE PTR es:[edi],dx
   1812d:	jne    0x18194
   1812f:	add    BYTE PTR [ebx+eax*1+0x6553654b],al
   18136:	je     0x1817d
   18138:	jbe    0x1819f
   1813a:	outs   dx,BYTE PTR ds:[esi]
   1813b:	je     0x1813d
   1813d:	add    dl,ah
   1813f:	add    cl,BYTE PTR [ebx+0x65]
   18142:	inc    ebx
   18143:	ins    BYTE PTR es:[edi],dx
   18144:	gs popa
   18146:	jb     0x1818d
   18148:	jbe    0x181af
   1814a:	outs   dx,BYTE PTR ds:[esi]
   1814b:	je     0x1814d
   1814d:	add    BYTE PTR [ebx+0x6c745205],dl
   18153:	inc    esp
   18154:	gs ins BYTE PTR es:[edi],dx
   18156:	gs je  0x181be
   18159:	push   edx
   1815a:	imul   esi,DWORD PTR gs:[bp+di+0x74],0x61567972
   18163:	ins    BYTE PTR es:[edi],dx
   18164:	jne    0x181cb
   18166:	add    BYTE PTR [eax],al
   18168:	sbb    eax,DWORD PTR [edx]
   1816a:	dec    ecx
   1816b:	outs   dx,DWORD PTR ds:[esi]
   1816c:	inc    edi
   1816d:	gs je  0x181b3
   18170:	outs   dx,DWORD PTR ds:[esi]
   18171:	outs   dx,BYTE PTR ds:[esi]
   18172:	imul   sp,WORD PTR [edi+0x75],0x6172
   18178:	je     0x181e3
   1817a:	outs   dx,DWORD PTR ds:[esi]
   1817b:	outs   dx,BYTE PTR ds:[esi]
   1817c:	dec    ecx
   1817d:	outs   dx,BYTE PTR ds:[esi]
   1817e:	outs   dx,WORD PTR ds:[esi]
   18180:	jb     0x181ef
   18182:	popa
   18183:	je     0x181ee
   18185:	outs   dx,DWORD PTR ds:[esi]
   18186:	outs   dx,BYTE PTR ds:[esi]
   18187:	add    BYTE PTR [esi],dl
   18189:	add    ecx,DWORD PTR [ebx+0x65]
   1818c:	dec    ecx
   1818d:	outs   dx,BYTE PTR ds:[esi]
   1818e:	imul   esi,DWORD PTR [ecx+ebp*2+0x61],0x657a696c
   18196:	inc    ebp
   18197:	jbe    0x181fe
   18199:	outs   dx,BYTE PTR ds:[esi]
   1819a:	je     0x1819c
   1819c:	push   eax
   1819d:	add    ecx,DWORD PTR [ebx+0x65]
   181a0:	push   ecx
   181a1:	jne    0x18208
   181a3:	jb     0x1821e
   181a5:	push   ebx
   181a6:	jns    0x1821b
   181a8:	je     0x1820f
   181aa:	ins    DWORD PTR es:[edi],dx
   181ab:	push   esp
   181ac:	imul   ebp,DWORD PTR [ebp+0x65],0x73086000
   181b3:	je     0x18227
   181b5:	outs   dx,BYTE PTR ds:[esi]
   181b6:	arpl   WORD PTR [ebp+0x70],bp
   181b9:	add    BYTE PTR [edx+0x666f4902],bh
   181bf:	inc    ebx
   181c0:	outs   dx,DWORD PTR ds:[esi]
   181c1:	ins    DWORD PTR es:[edi],dx
   181c2:	jo     0x18230
   181c4:	gs je  0x1822c
   181c7:	push   edx
   181c8:	gs jno 0x18240
   181cb:	gs jae 0x18242
   181ce:	add    BYTE PTR [eax],al
   181d0:	pushf
   181d1:	add    ecx,DWORD PTR [ebx+0x65]
   181d4:	push   esp
   181d5:	imul   esp,DWORD PTR [ebx+0x6b],0x6e756f43
   181dc:	je     0x181de
   181de:	fld    QWORD PTR [edx]
   181e0:	dec    ebx
   181e1:	gs inc edx
   181e3:	jne    0x1824c
   181e5:	inc    ebx
   181e6:	push   0x456b6365
   181eb:	js     0x181ed
   181ed:	add    BYTE PTR [esi+0x74],ch
   181f0:	outs   dx,DWORD PTR ds:[esi]
   181f1:	jae    0x1825e
   181f3:	jb     0x18263
   181f5:	ins    BYTE PTR es:[edi],dx
   181f6:	cs gs js 0x1825f
   181fa:	add    BYTE PTR [eax],al
   181fc:	jge    0x18203
   181fe:	push   edx
   181ff:	je     0x1826d
   18201:	inc    ebx
   18202:	outs   dx,DWORD PTR ds:[esi]
   18203:	jo     0x1827e
   18205:	push   ebp
   18206:	outs   dx,BYTE PTR ds:[esi]
   18207:	imul   esp,DWORD PTR [ebx+0x6f],0x74536564
   1820e:	jb     0x18279
   18210:	outs   dx,BYTE PTR ds:[esi]
   18211:	add    BYTE PTR [bx+si],al
   18214:	push   ebp
   18215:	add    eax,0x416c7452
   1821a:	outs   dx,BYTE PTR ds:[esi]
   1821b:	jae    0x18286
   1821d:	inc    ebx
   1821e:	push   0x6f547261
   18223:	push   ebp
   18224:	outs   dx,BYTE PTR ds:[esi]
   18225:	imul   esp,DWORD PTR [ebx+0x6f],0x68436564
   1822c:	popa
   1822d:	jb     0x1822f
   1822f:	add    BYTE PTR [eax],cl
   18231:	add    BYTE PTR [edi+0x64],dl
   18234:	push   si
   18236:	gs jb  0x182ac
   18239:	imul   ebp,DWORD PTR [edi+0x6e],0x69626e55
   18240:	outs   dx,BYTE PTR ds:[esi]
   18241:	add    BYTE PTR fs:[eax],al
   18244:	push   es
   18245:	add    BYTE PTR [edi+0x64],dl
   18248:	push   si
   1824a:	gs jb  0x182c0
   1824d:	imul   ebp,DWORD PTR [edi+0x6e],0x646e6942
   18254:	add    BYTE PTR [eax],al
   18256:	pop    es
   18257:	add    BYTE PTR [edi+0x64],dl
   1825a:	push   si
   1825c:	gs jb  0x182d2
   1825f:	imul   ebp,DWORD PTR [edi+0x6e],0x646e6942
   18266:	inc    ebx
   18267:	ins    BYTE PTR es:[edi],dx
   18268:	popa
   18269:	jae    0x182de
   1826b:	add    BYTE PTR [ecx],cl
   1826d:	add    BYTE PTR [edi+0x64],dl
   18270:	push   si
   18272:	gs jb  0x182e8
   18275:	imul   ebp,DWORD PTR [edi+0x6e],0x69626e55
   1827c:	outs   dx,BYTE PTR ds:[esi]
   1827d:	fs inc ebx
   1827f:	ins    BYTE PTR es:[edi],dx
   18280:	popa
   18281:	jae    0x182f6
   18283:	add    BYTE PTR [edi+0x44],dl
   18286:	inc    esi
   18287:	dec    esp
   18288:	inc    esp
   18289:	push   edx
   1828a:	cs push ebx
   1828c:	pop    ecx
   1828d:	push   ebx
	...
