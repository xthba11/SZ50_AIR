; Static disassembly: Drivers/i386/sprdvmdm.sys
; Addresses are as reported by objdump. No original symbols or C source are implied.

Drivers/i386/sprdvmdm.sys:     file format pei-i386


Disassembly of section .text:

00011000 <.text>:
   11000:	add    BYTE PTR [eax],al
   11002:	add    BYTE PTR [eax],al
   11004:	add    BYTE PTR [eax],al
   11006:	mov    edi,edi
   11008:	push   ebp
   11009:	mov    ebp,esp
   1100b:	push   DWORD PTR [ebp+0x8]
   1100e:	push   DWORD PTR ds:0x1770c
   11014:	call   DWORD PTR ds:0x172a0
   1101a:	push   eax
   1101b:	call   0x13918
   11020:	pop    ebp
   11021:	ret    0x4
   11024:	int3
   11025:	int3
   11026:	int3
   11027:	int3
   11028:	int3
   11029:	int3
   1102a:	mov    edi,edi
   1102c:	push   ebp
   1102d:	mov    ebp,esp
   1102f:	mov    edx,DWORD PTR [ebp+0x8]
   11032:	mov    ecx,DWORD PTR ds:0x1770c
   11038:	push   esi
   11039:	push   DWORD PTR ds:0x1700c
   1103f:	call   DWORD PTR ds:0x173f0
   11045:	push   DWORD PTR [ebp+0x8]
   11048:	mov    esi,eax
   1104a:	push   DWORD PTR ds:0x1770c
   11050:	call   DWORD PTR ds:0x174cc
   11056:	test   al,al
   11058:	je     0x11061
   1105a:	mov    eax,0xc0000001
   1105f:	jmp    0x1107d
   11061:	mov    eax,DWORD PTR [ebp+0xc]
   11064:	or     DWORD PTR [esi+0x8],0x1
   11068:	push   eax
   11069:	push   DWORD PTR [ebp+0x8]
   1106c:	mov    DWORD PTR [esi+0x4],eax
   1106f:	push   DWORD PTR ds:0x1770c
   11075:	call   DWORD PTR ds:0x174c4
   1107b:	xor    eax,eax
   1107d:	pop    esi
   1107e:	pop    ebp
   1107f:	ret    0x8
   11082:	int3
   11083:	int3
   11084:	int3
   11085:	int3
   11086:	int3
   11087:	int3
   11088:	mov    edi,edi
   1108a:	push   ebp
   1108b:	mov    ebp,esp
   1108d:	mov    edx,DWORD PTR [ebp+0x8]
   11090:	mov    ecx,DWORD PTR ds:0x1770c
   11096:	push   esi
   11097:	push   DWORD PTR ds:0x1700c
   1109d:	call   DWORD PTR ds:0x173f0
   110a3:	mov    esi,eax
   110a5:	test   BYTE PTR [esi+0x8],0x1
   110a9:	jne    0x110af
   110ab:	xor    eax,eax
   110ad:	jmp    0x110d4
   110af:	push   DWORD PTR [ebp+0x8]
   110b2:	push   DWORD PTR ds:0x1770c
   110b8:	call   DWORD PTR ds:0x174c8
   110be:	test   eax,eax
   110c0:	jl     0x110d4
   110c2:	mov    ecx,DWORD PTR [esi+0x8]
   110c5:	test   cl,0x1
   110c8:	je     0x110d4
   110ca:	and    ecx,0xfffffffe
   110cd:	and    DWORD PTR [esi+0x4],0x0
   110d1:	mov    DWORD PTR [esi+0x8],ecx
   110d4:	pop    esi
   110d5:	pop    ebp
   110d6:	ret    0x4
   110d9:	int3
   110da:	int3
   110db:	int3
   110dc:	int3
   110dd:	int3
   110de:	mov    edi,edi
   110e0:	push   ebp
   110e1:	mov    ebp,esp
   110e3:	sub    esp,0x14
   110e6:	push   esi
   110e7:	push   edi
   110e8:	push   DWORD PTR [ebp+0xc]
   110eb:	push   DWORD PTR [ebp+0x8]
   110ee:	call   0x144ba
   110f3:	xor    eax,eax
   110f5:	lea    edi,[ebp-0x14]
   110f8:	stos   DWORD PTR es:[edi],eax
   110f9:	stos   DWORD PTR es:[edi],eax
   110fa:	stos   DWORD PTR es:[edi],eax
   110fb:	stos   DWORD PTR es:[edi],eax
   110fc:	stos   DWORD PTR es:[edi],eax
   110fd:	push   0x0
   110ff:	lea    eax,[ebp-0x14]
   11102:	push   eax
   11103:	push   0x0
   11105:	push   DWORD PTR [ebp+0xc]
   11108:	mov    DWORD PTR [ebp-0x14],0x14
   1110f:	push   DWORD PTR [ebp+0x8]
   11112:	mov    DWORD PTR [ebp-0x10],0x1281c
   11119:	push   DWORD PTR ds:0x1770c
   1111f:	mov    DWORD PTR [ebp-0xc],0x11006
   11126:	call   DWORD PTR ds:0x17298
   1112c:	mov    esi,eax
   1112e:	test   esi,esi
   11130:	jge    0x1113a
   11132:	push   DWORD PTR [ebp+0x8]
   11135:	call   0x13918
   1113a:	pop    edi
   1113b:	mov    eax,esi
   1113d:	pop    esi
   1113e:	leave
   1113f:	ret    0x8
   11142:	int3
   11143:	int3
   11144:	int3
   11145:	int3
   11146:	int3
   11147:	int3
   11148:	mov    edi,edi
   1114a:	push   ebp
   1114b:	mov    ebp,esp
   1114d:	sub    esp,0xc
   11150:	push   esi
   11151:	mov    esi,DWORD PTR [ebp+0x8]
   11154:	push   0x0
   11156:	push   0x7fff
   1115b:	push   0x0
   1115d:	lea    eax,[ebp-0x8]
   11160:	push   eax
   11161:	lea    eax,[ebp-0xc]
   11164:	push   eax
   11165:	push   esi
   11166:	call   0x147aa
   1116b:	test   eax,eax
   1116d:	jl     0x11191
   1116f:	and    DWORD PTR [ebp-0x4],0x0
   11173:	lea    eax,[ebp+0x10]
   11176:	push   eax
   11177:	push   DWORD PTR [ebp+0xc]
   1117a:	lea    eax,[ebp-0x4]
   1117d:	push   eax
   1117e:	push   DWORD PTR [ebp-0x8]
   11181:	push   DWORD PTR [ebp-0xc]
   11184:	call   0x14806
   11189:	mov    ecx,DWORD PTR [ebp-0x4]
   1118c:	add    ecx,ecx
   1118e:	mov    WORD PTR [esi],cx
   11191:	pop    esi
   11192:	leave
   11193:	ret
   11194:	int3
   11195:	int3
   11196:	int3
   11197:	int3
   11198:	int3
   11199:	int3
   1119a:	mov    edi,edi
   1119c:	push   ebp
   1119d:	mov    ebp,esp
   1119f:	sub    esp,0x20
   111a2:	push   ebx
   111a3:	push   esi
   111a4:	mov    esi,DWORD PTR [ebp+0x8]
   111a7:	push   edi
   111a8:	push   0x8
   111aa:	pop    ecx
   111ab:	xor    eax,eax
   111ad:	lea    edi,[ebp-0x20]
   111b0:	rep stos DWORD PTR es:[edi],eax
   111b2:	mov    eax,ds:0x17020
   111b7:	mov    DWORD PTR [ebp-0x4],eax
   111ba:	mov    eax,DWORD PTR [esi]
   111bc:	lea    edi,[esi+0x5c]
   111bf:	push   edi
   111c0:	mov    DWORD PTR [ebp-0xc],eax
   111c3:	push   0x0
   111c5:	lea    eax,[ebp-0x20]
   111c8:	push   eax
   111c9:	push   DWORD PTR ds:0x1770c
   111cf:	xor    ebx,ebx
   111d1:	inc    ebx
   111d2:	mov    DWORD PTR [ebp-0x20],0x20
   111d9:	mov    DWORD PTR [ebp-0x14],ebx
   111dc:	mov    DWORD PTR [ebp-0x10],ebx
   111df:	call   DWORD PTR ds:0x174a4
   111e5:	test   eax,eax
   111e7:	jne    0x11244
   111e9:	push   DWORD PTR ds:0x17020
   111ef:	mov    edx,DWORD PTR [edi]
   111f1:	mov    ecx,DWORD PTR ds:0x1770c
   111f7:	call   DWORD PTR ds:0x173f0
   111fd:	mov    ecx,DWORD PTR [esi]
   111ff:	mov    DWORD PTR [eax],ecx
   11201:	push   0x8
   11203:	pop    ecx
   11204:	lea    edx,[eax+0x4]
   11207:	and    DWORD PTR [edx],0x0
   1120a:	push   0x0
   1120c:	xor    eax,eax
   1120e:	push   edx
   1120f:	lea    edi,[ebp-0x20]
   11212:	rep stos DWORD PTR es:[edi],eax
   11214:	mov    eax,DWORD PTR [esi]
   11216:	mov    esi,DWORD PTR [esi+0x144]
   1121c:	push   esi
   1121d:	push   0x6d6f6355
   11222:	mov    DWORD PTR [ebp-0xc],eax
   11225:	push   0x0
   11227:	lea    eax,[ebp-0x20]
   1122a:	push   eax
   1122b:	push   DWORD PTR ds:0x1770c
   11231:	mov    DWORD PTR [ebp-0x20],0x20
   11238:	mov    DWORD PTR [ebp-0x14],ebx
   1123b:	mov    DWORD PTR [ebp-0x10],ebx
   1123e:	call   DWORD PTR ds:0x173c8
   11244:	pop    edi
   11245:	pop    esi
   11246:	pop    ebx
   11247:	leave
   11248:	ret    0x4
   1124b:	int3
   1124c:	int3
   1124d:	int3
   1124e:	int3
   1124f:	int3
   11250:	mov    edi,edi
   11252:	push   ebp
   11253:	mov    ebp,esp
   11255:	sub    esp,0xc
   11258:	mov    eax,DWORD PTR [ebp+0x8]
   1125b:	mov    eax,DWORD PTR [eax]
   1125d:	and    DWORD PTR [ebp-0x4],0x0
   11261:	push   edi
   11262:	lea    ecx,[ebp-0x4]
   11265:	push   ecx
   11266:	push   0x0
   11268:	push   0x1f0000
   1126d:	push   0x1
   1126f:	push   eax
   11270:	push   DWORD PTR ds:0x1770c
   11276:	call   DWORD PTR ds:0x17188
   1127c:	mov    edi,eax
   1127e:	test   edi,edi
   11280:	jne    0x112aa
   11282:	push   0x1552a
   11287:	lea    eax,[ebp-0xc]
   1128a:	push   eax
   1128b:	call   DWORD PTR ds:0x16040
   11291:	push   DWORD PTR [ebp+0xc]
   11294:	lea    eax,[ebp-0xc]
   11297:	push   edi
   11298:	push   eax
   11299:	push   DWORD PTR [ebp-0x4]
   1129c:	push   DWORD PTR ds:0x1770c
   112a2:	call   DWORD PTR ds:0x17480
   112a8:	mov    edi,eax
   112aa:	cmp    DWORD PTR [ebp-0x4],0x0
   112ae:	je     0x112bf
   112b0:	push   DWORD PTR [ebp-0x4]
   112b3:	push   DWORD PTR ds:0x1770c
   112b9:	call   DWORD PTR ds:0x17464
   112bf:	mov    eax,edi
   112c1:	pop    edi
   112c2:	leave
   112c3:	ret    0x8
   112c6:	int3
   112c7:	int3
   112c8:	int3
   112c9:	int3
   112ca:	int3
   112cb:	int3
   112cc:	mov    edi,edi
   112ce:	push   ebp
   112cf:	mov    ebp,esp
   112d1:	sub    esp,0x238
   112d7:	mov    eax,ds:0x17044
   112dc:	xor    eax,ebp
   112de:	mov    DWORD PTR [ebp-0x4],eax
   112e1:	push   ebx
   112e2:	push   esi
   112e3:	mov    esi,DWORD PTR [ebp+0x8]
   112e6:	push   edi
   112e7:	xor    eax,eax
   112e9:	push   0xfe
   112ee:	push   eax
   112ef:	mov    WORD PTR [ebp-0x104],ax
   112f6:	lea    eax,[ebp-0x102]
   112fc:	push   eax
   112fd:	call   0x1450e
   11302:	xor    eax,eax
   11304:	and    DWORD PTR [ebp-0x208],0x0
   1130b:	mov    WORD PTR [ebp-0x210],ax
   11312:	add    esp,0xc
   11315:	mov    ebx,0x100
   1131a:	mov    eax,ebx
   1131c:	mov    WORD PTR [ebp-0x20e],ax
   11323:	push   0x8
   11325:	pop    ecx
   11326:	lea    eax,[ebp-0x204]
   1132c:	mov    DWORD PTR [ebp-0x20c],eax
   11332:	xor    eax,eax
   11334:	lea    edi,[ebp-0x238]
   1133a:	rep stos DWORD PTR es:[edi],eax
   1133c:	mov    eax,DWORD PTR [esi]
   1133e:	mov    DWORD PTR [ebp-0x224],eax
   11344:	lea    eax,[ebp-0x208]
   1134a:	push   eax
   1134b:	lea    eax,[ebp-0x238]
   11351:	push   eax
   11352:	push   0x0
   11354:	push   DWORD PTR ds:0x1770c
   1135a:	xor    edi,edi
   1135c:	inc    edi
   1135d:	mov    DWORD PTR [ebp-0x238],0x20
   11367:	mov    DWORD PTR [ebp-0x22c],edi
   1136d:	mov    DWORD PTR [ebp-0x228],edi
   11373:	call   DWORD PTR ds:0x17598
   11379:	test   eax,eax
   1137b:	jne    0x1147d
   11381:	push   DWORD PTR [ebp-0x208]
   11387:	mov    eax,DWORD PTR [esi]
   11389:	push   eax
   1138a:	push   DWORD PTR ds:0x1770c
   11390:	call   DWORD PTR ds:0x17168
   11396:	test   eax,eax
   11398:	jne    0x1147d
   1139e:	lea    eax,[esi+0x24]
   113a1:	push   eax
   113a2:	push   DWORD PTR [ebp-0x208]
   113a8:	push   DWORD PTR ds:0x1770c
   113ae:	call   DWORD PTR ds:0x1759c
   113b4:	xor    eax,eax
   113b6:	mov    WORD PTR [ebp-0x218],ax
   113bd:	lea    eax,[ebp-0x104]
   113c3:	mov    DWORD PTR [ebp-0x214],eax
   113c9:	lea    eax,[ebp-0x218]
   113cf:	push   eax
   113d0:	push   esi
   113d1:	mov    WORD PTR [ebp-0x216],bx
   113d8:	call   0x11250
   113dd:	test   eax,eax
   113df:	jne    0x1147d
   113e5:	lea    eax,[ebp-0x104]
   113eb:	push   eax
   113ec:	push   0x15560
   113f1:	lea    eax,[ebp-0x210]
   113f7:	push   0x15552
   113fc:	push   eax
   113fd:	call   0x11148
   11402:	add    esp,0x10
   11405:	test   eax,eax
   11407:	jne    0x1147d
   11409:	mov    eax,DWORD PTR [esi]
   1140b:	lea    ecx,[ebp-0x210]
   11411:	push   ecx
   11412:	push   eax
   11413:	push   DWORD PTR ds:0x1770c
   11419:	call   DWORD PTR ds:0x17208
   1141f:	test   eax,eax
   11421:	jne    0x1147d
   11423:	lea    eax,[ebp-0x104]
   11429:	mov    BYTE PTR [esi+0x71],0x1
   1142d:	lea    ecx,[eax+0x2]
   11430:	mov    dx,WORD PTR [eax]
   11433:	inc    eax
   11434:	inc    eax
   11435:	test   dx,dx
   11438:	jne    0x11430
   1143a:	sub    eax,ecx
   1143c:	sar    eax,1
   1143e:	lea    eax,[eax+eax*1+0x2]
   11442:	push   eax
   11443:	lea    eax,[ebp-0x104]
   11449:	push   eax
   1144a:	push   edi
   1144b:	push   DWORD PTR [esi+0x28]
   1144e:	push   0x1553c
   11453:	push   0x4
   11455:	call   DWORD PTR ds:0x1602c
   1145b:	test   eax,eax
   1145d:	jne    0x1147d
   1145f:	mov    eax,DWORD PTR [esi]
   11461:	push   0x0
   11463:	push   0x160cc
   11468:	push   eax
   11469:	mov    BYTE PTR [esi+0x72],0x1
   1146d:	push   DWORD PTR ds:0x1770c
   11473:	call   DWORD PTR ds:0x171fc
   11479:	test   eax,eax
   1147b:	je     0x11481
   1147d:	and    DWORD PTR [esi+0x28],0x0
   11481:	mov    ecx,DWORD PTR [ebp-0x4]
   11484:	pop    edi
   11485:	pop    esi
   11486:	xor    ecx,ebp
   11488:	pop    ebx
   11489:	call   0x144c2
   1148e:	leave
   1148f:	ret    0x4
   11492:	int3
   11493:	int3
   11494:	int3
   11495:	int3
   11496:	int3
   11497:	int3
   11498:	mov    edi,edi
   1149a:	push   ebp
   1149b:	mov    ebp,esp
   1149d:	mov    ecx,DWORD PTR [ebp+0x8]
   114a0:	mov    eax,DWORD PTR [ecx+0x14c]
   114a6:	test   eax,eax
   114a8:	je     0x114ad
   114aa:	push   ecx
   114ab:	call   eax
   114ad:	pop    ebp
   114ae:	ret    0x4
   114b1:	int3
   114b2:	int3
   114b3:	int3
   114b4:	int3
   114b5:	int3
   114b6:	mov    edi,edi
   114b8:	push   ebp
   114b9:	mov    ebp,esp
   114bb:	mov    ecx,DWORD PTR [ebp+0x8]
   114be:	mov    eax,DWORD PTR [ecx+0x150]
   114c4:	test   eax,eax
   114c6:	je     0x114cb
   114c8:	push   ecx
   114c9:	call   eax
   114cb:	pop    ebp
   114cc:	ret    0x4
   114cf:	int3
   114d0:	int3
   114d1:	int3
   114d2:	int3
   114d3:	int3
   114d4:	mov    edi,edi
   114d6:	push   ebp
   114d7:	mov    ebp,esp
   114d9:	mov    ecx,DWORD PTR [ebp+0x8]
   114dc:	mov    eax,DWORD PTR [ecx+0x154]
   114e2:	test   eax,eax
   114e4:	je     0x114e9
   114e6:	push   ecx
   114e7:	call   eax
   114e9:	pop    ebp
   114ea:	ret    0x4
   114ed:	int3
   114ee:	int3
   114ef:	int3
   114f0:	int3
   114f1:	int3
   114f2:	mov    edi,edi
   114f4:	push   ebp
   114f5:	mov    ebp,esp
   114f7:	mov    edx,DWORD PTR [ebp+0x8]
   114fa:	mov    ecx,DWORD PTR ds:0x1770c
   11500:	push   esi
   11501:	push   edi
   11502:	push   DWORD PTR ds:0x17034
   11508:	xor    edi,edi
   1150a:	call   DWORD PTR ds:0x173f0
   11510:	mov    esi,eax
   11512:	cmp    DWORD PTR [esi+0x7c],edi
   11515:	je     0x1153f
   11517:	push   esi
   11518:	call   0x114b6
   1151d:	mov    edi,eax
   1151f:	xor    eax,eax
   11521:	inc    eax
   11522:	lea    ecx,[esi+0x80]
   11528:	xchg   DWORD PTR [ecx],eax
   1152a:	test   eax,eax
   1152c:	jne    0x1153f
   1152e:	push   DWORD PTR [esi+0x44]
   11531:	push   DWORD PTR ds:0x1770c
   11537:	call   DWORD PTR ds:0x17374
   1153d:	mov    edi,eax
   1153f:	mov    eax,edi
   11541:	pop    edi
   11542:	pop    esi
   11543:	pop    ebp
   11544:	ret    0x8
   11547:	int3
   11548:	int3
   11549:	int3
   1154a:	int3
   1154b:	int3
   1154c:	mov    edi,edi
   1154e:	push   ebp
   1154f:	mov    ebp,esp
   11551:	mov    edx,DWORD PTR [ebp+0x8]
   11554:	mov    ecx,DWORD PTR ds:0x1770c
   1155a:	push   esi
   1155b:	push   edi
   1155c:	push   DWORD PTR ds:0x17034
   11562:	xor    edi,edi
   11564:	call   DWORD PTR ds:0x173f0
   1156a:	mov    esi,eax
   1156c:	cmp    DWORD PTR [esi+0x7c],edi
   1156f:	je     0x11598
   11571:	xor    eax,eax
   11573:	lea    ecx,[esi+0x80]
   11579:	xchg   DWORD PTR [ecx],eax
   1157b:	cmp    eax,0x1
   1157e:	jne    0x11590
   11580:	push   eax
   11581:	push   DWORD PTR [esi+0x44]
   11584:	push   DWORD PTR ds:0x1770c
   1158a:	call   DWORD PTR ds:0x17378
   11590:	push   esi
   11591:	call   0x114d4
   11596:	mov    edi,eax
   11598:	mov    eax,edi
   1159a:	pop    edi
   1159b:	pop    esi
   1159c:	pop    ebp
   1159d:	ret    0x8
   115a0:	int3
   115a1:	int3
   115a2:	int3
   115a3:	int3
   115a4:	int3
   115a5:	int3
   115a6:	mov    edi,edi
   115a8:	push   ebp
   115a9:	mov    ebp,esp
   115ab:	sub    esp,0x14
   115ae:	push   esi
   115af:	mov    esi,DWORD PTR [ebp+0x8]
   115b2:	mov    eax,DWORD PTR [esi+0x2c]
   115b5:	lea    ecx,[ebp+0xc]
   115b8:	push   ecx
   115b9:	push   0x0
   115bb:	push   eax
   115bc:	push   DWORD PTR ds:0x1770c
   115c2:	call   DWORD PTR ds:0x175f0
   115c8:	test   eax,eax
   115ca:	jne    0x11651
   115d0:	push   DWORD PTR [esi+0x2c]
   115d3:	push   DWORD PTR ds:0x1770c
   115d9:	call   DWORD PTR ds:0x175ec
   115df:	test   al,al
   115e1:	jbe    0x1164f
   115e3:	mov    eax,DWORD PTR [ebp+0x18]
   115e6:	mov    DWORD PTR [esi+0x30],eax
   115e9:	mov    al,BYTE PTR [ebp+0x14]
   115ec:	mov    BYTE PTR [esi+0x3c],al
   115ef:	cmp    al,0x2
   115f1:	jae    0x115fa
   115f3:	mov    eax,0xc0000001
   115f8:	jmp    0x11651
   115fa:	mov    BYTE PTR [ebp+0x8],0x0
   115fe:	test   al,al
   11600:	jbe    0x1164f
   11602:	push   edi
   11603:	xor    eax,eax
   11605:	lea    edi,[ebp-0x14]
   11608:	stos   DWORD PTR es:[edi],eax
   11609:	stos   DWORD PTR es:[edi],eax
   1160a:	stos   DWORD PTR es:[edi],eax
   1160b:	stos   DWORD PTR es:[edi],eax
   1160c:	lea    ecx,[ebp-0x14]
   1160f:	push   ecx
   11610:	push   DWORD PTR [ebp+0x8]
   11613:	stos   DWORD PTR es:[edi],eax
   11614:	mov    eax,DWORD PTR [esi+0x30]
   11617:	push   eax
   11618:	push   DWORD PTR ds:0x1770c
   1161e:	mov    DWORD PTR [ebp-0x14],0x14
   11625:	call   DWORD PTR ds:0x1767c
   1162b:	test   eax,eax
   1162d:	je     0x11643
   1162f:	cmp    DWORD PTR [ebp-0x8],0x3
   11633:	jne    0x11643
   11635:	test   BYTE PTR [ebp-0xc],0x80
   11639:	je     0x11640
   1163b:	mov    DWORD PTR [esi+0x44],eax
   1163e:	jmp    0x11643
   11640:	mov    DWORD PTR [esi+0x40],eax
   11643:	inc    BYTE PTR [ebp+0x8]
   11646:	mov    al,BYTE PTR [ebp+0x8]
   11649:	cmp    al,BYTE PTR [esi+0x3c]
   1164c:	jb     0x11603
   1164e:	pop    edi
   1164f:	xor    eax,eax
   11651:	pop    esi
   11652:	leave
   11653:	ret    0x18
   11656:	int3
   11657:	int3
   11658:	int3
   11659:	int3
   1165a:	int3
   1165b:	int3
   1165c:	mov    edi,edi
   1165e:	push   ebp
   1165f:	mov    ebp,esp
   11661:	sub    esp,0x1c
   11664:	push   esi
   11665:	mov    esi,DWORD PTR [ebp+0x8]
   11668:	mov    eax,DWORD PTR [esi+0x2c]
   1166b:	lea    ecx,[ebp+0xc]
   1166e:	push   ecx
   1166f:	push   0x0
   11671:	push   eax
   11672:	push   DWORD PTR ds:0x1770c
   11678:	call   DWORD PTR ds:0x175f0
   1167e:	test   eax,eax
   11680:	jne    0x11746
   11686:	push   ebx
   11687:	push   edi
   11688:	push   DWORD PTR [esi+0x2c]
   1168b:	push   DWORD PTR ds:0x1770c
   11691:	call   DWORD PTR ds:0x175ec
   11697:	test   al,al
   11699:	jbe    0x11742
   1169f:	mov    al,BYTE PTR [ebp+0x1c]
   116a2:	mov    BYTE PTR [esi+0x135],al
   116a8:	mov    BYTE PTR [ebp-0x8],0x0
   116ac:	test   al,al
   116ae:	jbe    0x11742
   116b4:	push   DWORD PTR [ebp-0x8]
   116b7:	mov    eax,DWORD PTR [esi+0x2c]
   116ba:	push   eax
   116bb:	push   DWORD PTR ds:0x1770c
   116c1:	call   DWORD PTR ds:0x17670
   116c7:	mov    ebx,eax
   116c9:	test   ebx,ebx
   116cb:	je     0x1174b
   116cd:	push   ebx
   116ce:	push   DWORD PTR ds:0x1770c
   116d4:	call   DWORD PTR ds:0x17678
   116da:	mov    BYTE PTR [ebp+0xb],al
   116dd:	mov    BYTE PTR [ebp-0x4],0x0
   116e1:	test   al,al
   116e3:	jbe    0x11730
   116e5:	xor    eax,eax
   116e7:	lea    edi,[ebp-0x1c]
   116ea:	stos   DWORD PTR es:[edi],eax
   116eb:	stos   DWORD PTR es:[edi],eax
   116ec:	stos   DWORD PTR es:[edi],eax
   116ed:	stos   DWORD PTR es:[edi],eax
   116ee:	stos   DWORD PTR es:[edi],eax
   116ef:	lea    eax,[ebp-0x1c]
   116f2:	push   eax
   116f3:	push   DWORD PTR [ebp-0x4]
   116f6:	mov    DWORD PTR [ebp-0x1c],0x14
   116fd:	push   ebx
   116fe:	push   DWORD PTR ds:0x1770c
   11704:	call   DWORD PTR ds:0x1767c
   1170a:	test   eax,eax
   1170c:	je     0x11725
   1170e:	cmp    DWORD PTR [ebp-0x10],0x3
   11712:	jne    0x11725
   11714:	test   BYTE PTR [ebp-0x14],0x80
   11718:	je     0x1171f
   1171a:	mov    DWORD PTR [esi+0x44],eax
   1171d:	jmp    0x11722
   1171f:	mov    DWORD PTR [esi+0x40],eax
   11722:	mov    DWORD PTR [esi+0x30],ebx
   11725:	inc    BYTE PTR [ebp-0x4]
   11728:	mov    al,BYTE PTR [ebp-0x4]
   1172b:	cmp    al,BYTE PTR [ebp+0xb]
   1172e:	jb     0x116e5
   11730:	inc    BYTE PTR [ebp-0x8]
   11733:	mov    al,BYTE PTR [ebp-0x8]
   11736:	cmp    al,BYTE PTR [esi+0x135]
   1173c:	jb     0x116b4
   11742:	xor    eax,eax
   11744:	pop    edi
   11745:	pop    ebx
   11746:	pop    esi
   11747:	leave
   11748:	ret    0x18
   1174b:	mov    eax,0xc0000001
   11750:	jmp    0x11744
   11752:	int3
   11753:	int3
   11754:	int3
   11755:	int3
   11756:	int3
   11757:	int3
   11758:	mov    edi,edi
   1175a:	push   ebp
   1175b:	mov    ebp,esp
   1175d:	mov    edx,DWORD PTR [ebp+0x8]
   11760:	mov    ecx,DWORD PTR ds:0x1770c
   11766:	push   esi
   11767:	push   DWORD PTR ds:0x17034
   1176d:	call   DWORD PTR ds:0x173f0
   11773:	mov    esi,eax
   11775:	push   0xf
   11777:	push   esi
   11778:	call   0x141ee
   1177d:	push   0x0
   1177f:	push   esi
   11780:	call   0x14116
   11785:	xor    eax,eax
   11787:	pop    esi
   11788:	pop    ebp
   11789:	ret    0x8
   1178c:	int3
   1178d:	int3
   1178e:	int3
   1178f:	int3
   11790:	int3
   11791:	int3
   11792:	mov    edi,edi
   11794:	push   ebp
   11795:	mov    ebp,esp
   11797:	push   DWORD PTR ds:0x17034
   1179d:	mov    edx,DWORD PTR [ebp+0x8]
   117a0:	mov    ecx,DWORD PTR ds:0x1770c
   117a6:	call   DWORD PTR ds:0x173f0
   117ac:	pop    ebp
   117ad:	ret    0x4
   117b0:	int3
   117b1:	int3
   117b2:	int3
   117b3:	int3
   117b4:	int3
   117b5:	int3
   117b6:	mov    edi,edi
   117b8:	push   ebp
   117b9:	mov    ebp,esp
   117bb:	sub    esp,0x10
   117be:	push   esi
   117bf:	mov    esi,DWORD PTR [ebp+0x8]
   117c2:	cmp    BYTE PTR [esi+0x14a],0x0
   117c9:	je     0x117e2
   117cb:	push   DWORD PTR [esi+0x44]
   117ce:	push   DWORD PTR ds:0x1770c
   117d4:	call   DWORD PTR ds:0x17374
   117da:	mov    DWORD PTR [ebp+0x8],eax
   117dd:	jmp    0x11898
   117e2:	mov    edx,DWORD PTR [esi+0x5c]
   117e5:	mov    ecx,DWORD PTR ds:0x1770c
   117eb:	push   ebx
   117ec:	push   edi
   117ed:	push   DWORD PTR ds:0x17020
   117f3:	call   DWORD PTR ds:0x173f0
   117f9:	mov    ebx,eax
   117fb:	xor    eax,eax
   117fd:	lea    edi,[ebp-0x10]
   11800:	stos   DWORD PTR es:[edi],eax
   11801:	stos   DWORD PTR es:[edi],eax
   11802:	stos   DWORD PTR es:[edi],eax
   11803:	stos   DWORD PTR es:[edi],eax
   11804:	mov    eax,DWORD PTR [esi+0x5c]
   11807:	lea    ecx,[ebp-0x10]
   1180a:	push   ecx
   1180b:	push   eax
   1180c:	push   DWORD PTR ds:0x1770c
   11812:	xor    edi,edi
   11814:	mov    DWORD PTR [ebp-0x10],0x10
   1181b:	mov    DWORD PTR [ebp-0xc],edi
   1181e:	mov    DWORD PTR [ebp-0x8],edi
   11821:	call   DWORD PTR ds:0x174ac
   11827:	mov    DWORD PTR [ebp+0x8],eax
   1182a:	cmp    eax,edi
   1182c:	jne    0x11896
   1182e:	mov    eax,DWORD PTR [ebx+0x4]
   11831:	mov    ecx,DWORD PTR [esi+0x5c]
   11834:	mov    edx,DWORD PTR [esi+0x44]
   11837:	push   edi
   11838:	push   eax
   11839:	push   ecx
   1183a:	push   edx
   1183b:	push   DWORD PTR ds:0x1770c
   11841:	call   DWORD PTR ds:0x1763c
   11847:	mov    DWORD PTR [ebp+0x8],eax
   1184a:	cmp    eax,edi
   1184c:	jne    0x11896
   1184e:	push   ebx
   1184f:	push   0x139e8
   11854:	push   DWORD PTR [esi+0x5c]
   11857:	push   DWORD PTR ds:0x1770c
   1185d:	call   DWORD PTR ds:0x174d8
   11863:	lea    ebx,[esi+0x60]
   11866:	push   ebx
   11867:	call   DWORD PTR ds:0x16018
   1186d:	mov    eax,DWORD PTR [esi+0x44]
   11870:	mov    esi,DWORD PTR [esi+0x5c]
   11873:	push   edi
   11874:	push   eax
   11875:	push   esi
   11876:	push   DWORD PTR ds:0x1770c
   1187c:	call   DWORD PTR ds:0x174bc
   11882:	test   al,al
   11884:	jne    0x11896
   11886:	push   edi
   11887:	push   edi
   11888:	push   ebx
   11889:	mov    DWORD PTR [ebp+0x8],0xc0000001
   11890:	call   DWORD PTR ds:0x16014
   11896:	pop    edi
   11897:	pop    ebx
   11898:	mov    eax,DWORD PTR [ebp+0x8]
   1189b:	pop    esi
   1189c:	leave
   1189d:	ret    0x4
   118a0:	int3
   118a1:	int3
   118a2:	int3
   118a3:	int3
   118a4:	int3
   118a5:	int3
   118a6:	mov    edi,edi
   118a8:	push   ebp
   118a9:	mov    ebp,esp
   118ab:	push   ebx
   118ac:	push   esi
   118ad:	mov    esi,DWORD PTR [ebp+0x8]
   118b0:	xor    ebx,ebx
   118b2:	cmp    BYTE PTR [esi+0x14a],bl
   118b8:	je     0x118cd
   118ba:	push   0x1
   118bc:	push   DWORD PTR [esi+0x44]
   118bf:	push   DWORD PTR ds:0x1770c
   118c5:	call   DWORD PTR ds:0x17378
   118cb:	jmp    0x118ea
   118cd:	push   DWORD PTR [esi+0x5c]
   118d0:	push   DWORD PTR ds:0x1770c
   118d6:	call   DWORD PTR ds:0x174d0
   118dc:	push   ebx
   118dd:	push   ebx
   118de:	push   ebx
   118df:	push   ebx
   118e0:	add    esi,0x60
   118e3:	push   esi
   118e4:	call   DWORD PTR ds:0x16044
   118ea:	pop    esi
   118eb:	pop    ebx
   118ec:	pop    ebp
   118ed:	ret    0x4
   118f0:	int3
   118f1:	int3
   118f2:	int3
   118f3:	int3
   118f4:	int3
   118f5:	int3
   118f6:	mov    edi,edi
   118f8:	push   ebp
   118f9:	mov    ebp,esp
   118fb:	push   ecx
   118fc:	and    DWORD PTR [ebp-0x4],0x0
   11900:	push   esi
   11901:	push   edi
   11902:	push   DWORD PTR [ebp+0x8]
   11905:	push   DWORD PTR ds:0x1770c
   1190b:	call   DWORD PTR ds:0x172f4
   11911:	push   DWORD PTR ds:0x17034
   11917:	mov    ecx,DWORD PTR ds:0x1770c
   1191d:	mov    edx,eax
   1191f:	call   DWORD PTR ds:0x173f0
   11925:	mov    esi,eax
   11927:	lea    eax,[ebp-0x4]
   1192a:	push   eax
   1192b:	push   esi
   1192c:	call   0x14368
   11931:	xor    eax,eax
   11933:	lea    ecx,[esi+0x80]
   11939:	xchg   DWORD PTR [ecx],eax
   1193b:	xor    edi,edi
   1193d:	inc    edi
   1193e:	cmp    eax,edi
   11940:	jne    0x11948
   11942:	push   esi
   11943:	call   0x118a6
   11948:	push   edi
   11949:	push   DWORD PTR [esi+0x4]
   1194c:	push   DWORD PTR ds:0x1770c
   11952:	call   DWORD PTR ds:0x175c8
   11958:	push   edi
   11959:	push   DWORD PTR [esi+0x20]
   1195c:	push   DWORD PTR ds:0x1770c
   11962:	call   DWORD PTR ds:0x1728c
   11968:	push   edi
   11969:	push   DWORD PTR [esi+0x18]
   1196c:	push   DWORD PTR ds:0x1770c
   11972:	call   DWORD PTR ds:0x1728c
   11978:	push   edi
   11979:	push   DWORD PTR [esi+0x1c]
   1197c:	push   DWORD PTR ds:0x1770c
   11982:	call   DWORD PTR ds:0x1728c
   11988:	push   esi
   11989:	call   0x114d4
   1198e:	xor    eax,eax
   11990:	lea    ecx,[esi+0x7c]
   11993:	xchg   DWORD PTR [ecx],eax
   11995:	push   edi
   11996:	push   DWORD PTR [esi]
   11998:	push   DWORD PTR ds:0x1770c
   1199e:	call   DWORD PTR ds:0x171f8
   119a4:	pop    edi
   119a5:	pop    esi
   119a6:	leave
   119a7:	ret    0x4
   119aa:	int3
   119ab:	int3
   119ac:	int3
   119ad:	int3
   119ae:	int3
   119af:	int3
   119b0:	mov    edi,edi
   119b2:	push   ebp
   119b3:	mov    ebp,esp
   119b5:	push   ecx
   119b6:	push   DWORD PTR [ebp+0x8]
   119b9:	and    DWORD PTR [ebp-0x4],0x0
   119bd:	push   DWORD PTR ds:0x1770c
   119c3:	call   DWORD PTR ds:0x172f4
   119c9:	push   DWORD PTR ds:0x17034
   119cf:	mov    ecx,DWORD PTR ds:0x1770c
   119d5:	mov    edx,eax
   119d7:	call   DWORD PTR ds:0x173f0
   119dd:	lea    ecx,[ebp-0x4]
   119e0:	push   ecx
   119e1:	push   eax
   119e2:	call   0x14368
   119e7:	leave
   119e8:	ret    0x4
   119eb:	int3
   119ec:	int3
   119ed:	int3
   119ee:	int3
   119ef:	int3
   119f0:	mov    edi,edi
   119f2:	push   ebp
   119f3:	mov    ebp,esp
   119f5:	push   esi
   119f6:	push   DWORD PTR [ebp+0x8]
   119f9:	push   DWORD PTR ds:0x1770c
   119ff:	call   DWORD PTR ds:0x175cc
   11a05:	push   DWORD PTR ds:0x17034
   11a0b:	mov    ecx,DWORD PTR ds:0x1770c
   11a11:	mov    edx,eax
   11a13:	call   DWORD PTR ds:0x173f0
   11a19:	mov    esi,eax
   11a1b:	push   esi
   11a1c:	call   0x142e6
   11a21:	push   esi
   11a22:	call   0x13918
   11a27:	push   esi
   11a28:	call   0x13920
   11a2d:	pop    esi
   11a2e:	pop    ebp
   11a2f:	ret    0x4
   11a32:	int3
   11a33:	int3
   11a34:	int3
   11a35:	int3
   11a36:	int3
   11a37:	int3
   11a38:	mov    edi,edi
   11a3a:	push   ebp
   11a3b:	mov    ebp,esp
   11a3d:	mov    edx,DWORD PTR [ebp+0x8]
   11a40:	mov    ecx,DWORD PTR ds:0x1770c
   11a46:	push   esi
   11a47:	push   edi
   11a48:	push   DWORD PTR ds:0x17034
   11a4e:	call   DWORD PTR ds:0x173f0
   11a54:	mov    esi,eax
   11a56:	cmp    BYTE PTR [esi+0x73],0x0
   11a5a:	mov    edi,DWORD PTR [esi+0x28]
   11a5d:	je     0x11a6a
   11a5f:	call   DWORD PTR ds:0x16020
   11a65:	add    eax,0x14
   11a68:	dec    DWORD PTR [eax]
   11a6a:	test   edi,edi
   11a6c:	je     0x11a82
   11a6e:	cmp    BYTE PTR [esi+0x72],0x0
   11a72:	je     0x11a82
   11a74:	push   edi
   11a75:	push   0x1553c
   11a7a:	push   0x4
   11a7c:	call   DWORD PTR ds:0x1601c
   11a82:	pop    edi
   11a83:	pop    esi
   11a84:	pop    ebp
   11a85:	ret    0x4
   11a88:	int3
   11a89:	int3
   11a8a:	int3
   11a8b:	int3
   11a8c:	int3
   11a8d:	int3
   11a8e:	mov    edi,edi
   11a90:	push   ebp
   11a91:	mov    ebp,esp
   11a93:	sub    esp,0x1c
   11a96:	mov    eax,ds:0x17044
   11a9b:	xor    eax,ebp
   11a9d:	mov    DWORD PTR [ebp-0x4],eax
   11aa0:	xor    eax,eax
   11aa2:	push   esi
   11aa3:	mov    esi,DWORD PTR [ebp+0x8]
   11aa6:	mov    ecx,DWORD PTR [esi+0x13c]
   11aac:	push   edi
   11aad:	lea    edi,[ebp-0xc]
   11ab0:	stos   DWORD PTR es:[edi],eax
   11ab1:	stos   DWORD PTR es:[edi],eax
   11ab2:	mov    al,BYTE PTR [ebp-0xc]
   11ab5:	and    al,0x1c
   11ab7:	or     al,0x21
   11ab9:	mov    BYTE PTR [ebp-0xc],al
   11abc:	mov    al,BYTE PTR [ebp+0xc]
   11abf:	mov    BYTE PTR [ebp-0xb],al
   11ac2:	mov    ax,WORD PTR [ebp+0x10]
   11ac6:	mov    WORD PTR [ebp-0xa],ax
   11aca:	mov    ax,WORD PTR [ebp+0x14]
   11ace:	mov    WORD PTR [ebp-0x8],ax
   11ad2:	xor    eax,eax
   11ad4:	test   ecx,ecx
   11ad6:	je     0x11b05
   11ad8:	lea    edi,[ebp-0x1c]
   11adb:	stos   DWORD PTR es:[edi],eax
   11adc:	stos   DWORD PTR es:[edi],eax
   11add:	push   0xffffffff
   11adf:	stos   DWORD PTR es:[edi],eax
   11ae0:	push   0xff676980
   11ae5:	push   0x0
   11ae7:	stos   DWORD PTR es:[edi],eax
   11ae8:	push   ecx
   11ae9:	mov    DWORD PTR [ebp-0x1c],0x10
   11af0:	mov    DWORD PTR [ebp-0x18],0x1
   11af7:	call   0x14502
   11afc:	mov    DWORD PTR [ebp-0x14],eax
   11aff:	mov    DWORD PTR [ebp-0x10],edx
   11b02:	lea    eax,[ebp-0x1c]
   11b05:	mov    esi,DWORD PTR [esi+0x2c]
   11b08:	push   0x0
   11b0a:	push   0x0
   11b0c:	lea    ecx,[ebp-0xc]
   11b0f:	push   ecx
   11b10:	push   eax
   11b11:	push   0x0
   11b13:	push   esi
   11b14:	push   DWORD PTR ds:0x1770c
   11b1a:	call   DWORD PTR ds:0x175fc
   11b20:	mov    ecx,DWORD PTR [ebp-0x4]
   11b23:	pop    edi
   11b24:	xor    ecx,ebp
   11b26:	pop    esi
   11b27:	call   0x144c2
   11b2c:	leave
   11b2d:	ret    0x10
   11b30:	int3
   11b31:	int3
   11b32:	int3
   11b33:	int3
   11b34:	int3
   11b35:	int3
   11b36:	mov    edi,edi
   11b38:	push   ebp
   11b39:	mov    ebp,esp
   11b3b:	mov    eax,DWORD PTR [ebp+0xc]
   11b3e:	mov    ecx,DWORD PTR [ebp+0x8]
   11b41:	mov    edx,DWORD PTR [ebp+0x10]
   11b44:	mov    DWORD PTR [ecx],eax
   11b46:	mov    DWORD PTR [ecx+0x4],eax
   11b49:	mov    DWORD PTR [ecx+0x8],eax
   11b4c:	add    eax,edx
   11b4e:	mov    DWORD PTR [ecx+0xc],eax
   11b51:	pop    ebp
   11b52:	ret    0xc
   11b55:	int3
   11b56:	int3
   11b57:	int3
   11b58:	int3
   11b59:	int3
   11b5a:	mov    edi,edi
   11b5c:	push   ebp
   11b5d:	mov    ebp,esp
   11b5f:	mov    eax,DWORD PTR [ebp+0xc]
   11b62:	mov    ecx,DWORD PTR [ebp+0x8]
   11b65:	inc    eax
   11b66:	cmp    eax,DWORD PTR [ecx+0xc]
   11b69:	jb     0x11b6d
   11b6b:	mov    eax,DWORD PTR [ecx]
   11b6d:	pop    ebp
   11b6e:	ret    0x8
   11b71:	int3
   11b72:	int3
   11b73:	int3
   11b74:	int3
   11b75:	int3
   11b76:	mov    edi,edi
   11b78:	push   ebp
   11b79:	mov    ebp,esp
   11b7b:	mov    eax,DWORD PTR [ebp+0x8]
   11b7e:	mov    eax,DWORD PTR [eax+0x8]
   11b81:	pop    ebp
   11b82:	ret    0x4
   11b85:	int3
   11b86:	int3
   11b87:	int3
   11b88:	int3
   11b89:	int3
   11b8a:	mov    edi,edi
   11b8c:	push   ebp
   11b8d:	mov    ebp,esp
   11b8f:	mov    eax,DWORD PTR [ebp+0x8]
   11b92:	mov    eax,DWORD PTR [eax+0x4]
   11b95:	pop    ebp
   11b96:	ret    0x4
   11b99:	int3
   11b9a:	int3
   11b9b:	int3
   11b9c:	int3
   11b9d:	int3
   11b9e:	mov    edi,edi
   11ba0:	push   ebp
   11ba1:	mov    ebp,esp
   11ba3:	mov    ecx,DWORD PTR [ebp+0x8]
   11ba6:	mov    eax,DWORD PTR [ecx+0x4]
   11ba9:	sub    eax,DWORD PTR [ecx+0x8]
   11bac:	neg    eax
   11bae:	sbb    eax,eax
   11bb0:	inc    eax
   11bb1:	pop    ebp
   11bb2:	ret    0x4
   11bb5:	int3
   11bb6:	int3
   11bb7:	int3
   11bb8:	int3
   11bb9:	int3
   11bba:	mov    edi,edi
   11bbc:	push   ebp
   11bbd:	mov    ebp,esp
   11bbf:	mov    edx,DWORD PTR [ebp+0x8]
   11bc2:	push   DWORD PTR [edx+0x4]
   11bc5:	push   edx
   11bc6:	call   0x11b5a
   11bcb:	sub    eax,DWORD PTR [edx+0x8]
   11bce:	neg    eax
   11bd0:	sbb    eax,eax
   11bd2:	inc    eax
   11bd3:	pop    ebp
   11bd4:	ret    0x4
   11bd7:	int3
   11bd8:	int3
   11bd9:	int3
   11bda:	int3
   11bdb:	int3
   11bdc:	mov    edi,edi
   11bde:	push   ebp
   11bdf:	mov    ebp,esp
   11be1:	mov    ecx,DWORD PTR [ebp+0x8]
   11be4:	mov    eax,DWORD PTR [ecx+0xc]
   11be7:	sub    eax,DWORD PTR [ecx]
   11be9:	pop    ebp
   11bea:	ret    0x4
   11bed:	int3
   11bee:	int3
   11bef:	int3
   11bf0:	int3
   11bf1:	int3
   11bf2:	mov    edi,edi
   11bf4:	push   ebp
   11bf5:	mov    ebp,esp
   11bf7:	mov    ecx,DWORD PTR [ebp+0x8]
   11bfa:	mov    edx,DWORD PTR [ecx+0x8]
   11bfd:	push   esi
   11bfe:	mov    esi,DWORD PTR [ecx+0x4]
   11c01:	cmp    edx,esi
   11c03:	ja     0x11c0b
   11c05:	mov    eax,esi
   11c07:	sub    eax,edx
   11c09:	jmp    0x11c14
   11c0b:	mov    eax,DWORD PTR [ecx+0xc]
   11c0e:	sub    eax,edx
   11c10:	sub    eax,DWORD PTR [ecx]
   11c12:	add    eax,esi
   11c14:	pop    esi
   11c15:	pop    ebp
   11c16:	ret    0x4
   11c19:	int3
   11c1a:	int3
   11c1b:	int3
   11c1c:	int3
   11c1d:	int3
   11c1e:	mov    edi,edi
   11c20:	push   ebp
   11c21:	mov    ebp,esp
   11c23:	mov    eax,DWORD PTR [ebp+0x8]
   11c26:	mov    ecx,DWORD PTR [eax]
   11c28:	mov    DWORD PTR [eax+0x8],ecx
   11c2b:	mov    DWORD PTR [eax+0x4],ecx
   11c2e:	pop    ebp
   11c2f:	ret    0x4
   11c32:	int3
   11c33:	int3
   11c34:	int3
   11c35:	int3
   11c36:	int3
   11c37:	int3
   11c38:	mov    edi,edi
   11c3a:	push   ebp
   11c3b:	mov    ebp,esp
   11c3d:	push   esi
   11c3e:	push   DWORD PTR [ebp+0x8]
   11c41:	push   DWORD PTR ds:0x1770c
   11c47:	call   DWORD PTR ds:0x17290
   11c4d:	push   DWORD PTR ds:0x17034
   11c53:	mov    ecx,DWORD PTR ds:0x1770c
   11c59:	mov    edx,eax
   11c5b:	call   DWORD PTR ds:0x173f0
   11c61:	mov    esi,DWORD PTR [eax+0x10]
   11c64:	mov    edx,DWORD PTR [eax+0x130]
   11c6a:	mov    ecx,esi
   11c6c:	and    ecx,edx
   11c6e:	test   cl,0x10
   11c71:	je     0x11c78
   11c73:	or     ecx,0x8
   11c76:	jmp    0x11c7b
   11c78:	and    ecx,0xfffffff7
   11c7b:	test   ecx,ecx
   11c7d:	je     0x11c82
   11c7f:	push   ecx
   11c80:	jmp    0x11c8b
   11c82:	test   edx,edx
   11c84:	jne    0x11c91
   11c86:	test   esi,esi
   11c88:	je     0x11c91
   11c8a:	push   edx
   11c8b:	push   eax
   11c8c:	call   0x14116
   11c91:	pop    esi
   11c92:	pop    ebp
   11c93:	ret    0x4
   11c96:	int3
   11c97:	int3
   11c98:	int3
   11c99:	int3
   11c9a:	int3
   11c9b:	int3
   11c9c:	mov    edi,edi
   11c9e:	push   ebp
   11c9f:	mov    ebp,esp
   11ca1:	sub    esp,0x2c
   11ca4:	push   ebx
   11ca5:	push   esi
   11ca6:	mov    esi,DWORD PTR [ebp+0x8]
   11ca9:	push   edi
   11caa:	xor    eax,eax
   11cac:	lea    edi,[ebp-0xc]
   11caf:	stos   DWORD PTR es:[edi],eax
   11cb0:	stos   DWORD PTR es:[edi],eax
   11cb1:	stos   DWORD PTR es:[edi],eax
   11cb2:	push   0x8
   11cb4:	pop    ecx
   11cb5:	xor    eax,eax
   11cb7:	lea    edi,[ebp-0x2c]
   11cba:	rep stos DWORD PTR es:[edi],eax
   11cbc:	mov    eax,DWORD PTR [esi]
   11cbe:	mov    DWORD PTR [ebp-0x18],eax
   11cc1:	lea    eax,[esi+0x1c]
   11cc4:	push   eax
   11cc5:	lea    eax,[ebp-0x2c]
   11cc8:	push   eax
   11cc9:	lea    eax,[ebp-0xc]
   11ccc:	push   eax
   11ccd:	push   DWORD PTR ds:0x1770c
   11cd3:	xor    ebx,ebx
   11cd5:	inc    ebx
   11cd6:	mov    DWORD PTR [ebp-0xc],0xc
   11cdd:	mov    DWORD PTR [ebp-0x8],0x13c66
   11ce4:	mov    BYTE PTR [ebp-0x4],bl
   11ce7:	mov    DWORD PTR [ebp-0x2c],0x20
   11cee:	mov    DWORD PTR [ebp-0x20],ebx
   11cf1:	mov    DWORD PTR [ebp-0x1c],ebx
   11cf4:	call   DWORD PTR ds:0x17284
   11cfa:	test   eax,eax
   11cfc:	jne    0x11d9c
   11d02:	lea    edi,[ebp-0xc]
   11d05:	stos   DWORD PTR es:[edi],eax
   11d06:	stos   DWORD PTR es:[edi],eax
   11d07:	stos   DWORD PTR es:[edi],eax
   11d08:	push   0x8
   11d0a:	pop    ecx
   11d0b:	xor    eax,eax
   11d0d:	lea    edi,[ebp-0x2c]
   11d10:	rep stos DWORD PTR es:[edi],eax
   11d12:	mov    eax,DWORD PTR [esi]
   11d14:	mov    DWORD PTR [ebp-0x18],eax
   11d17:	lea    eax,[esi+0x18]
   11d1a:	push   eax
   11d1b:	lea    eax,[ebp-0x2c]
   11d1e:	push   eax
   11d1f:	lea    eax,[ebp-0xc]
   11d22:	push   eax
   11d23:	push   DWORD PTR ds:0x1770c
   11d29:	mov    DWORD PTR [ebp-0xc],0xc
   11d30:	mov    DWORD PTR [ebp-0x8],0x13584
   11d37:	mov    BYTE PTR [ebp-0x4],bl
   11d3a:	mov    DWORD PTR [ebp-0x2c],0x20
   11d41:	mov    DWORD PTR [ebp-0x20],ebx
   11d44:	mov    DWORD PTR [ebp-0x1c],ebx
   11d47:	call   DWORD PTR ds:0x17284
   11d4d:	test   eax,eax
   11d4f:	jne    0x11d9c
   11d51:	lea    edi,[ebp-0xc]
   11d54:	stos   DWORD PTR es:[edi],eax
   11d55:	stos   DWORD PTR es:[edi],eax
   11d56:	stos   DWORD PTR es:[edi],eax
   11d57:	push   0x8
   11d59:	pop    ecx
   11d5a:	xor    eax,eax
   11d5c:	lea    edi,[ebp-0x2c]
   11d5f:	rep stos DWORD PTR es:[edi],eax
   11d61:	mov    eax,DWORD PTR [esi]
   11d63:	mov    DWORD PTR [ebp-0x18],eax
   11d66:	add    esi,0x20
   11d69:	push   esi
   11d6a:	lea    eax,[ebp-0x2c]
   11d6d:	push   eax
   11d6e:	lea    eax,[ebp-0xc]
   11d71:	push   eax
   11d72:	push   DWORD PTR ds:0x1770c
   11d78:	mov    DWORD PTR [ebp-0xc],0xc
   11d7f:	mov    DWORD PTR [ebp-0x8],0x11c38
   11d86:	mov    BYTE PTR [ebp-0x4],bl
   11d89:	mov    DWORD PTR [ebp-0x2c],0x20
   11d90:	mov    DWORD PTR [ebp-0x20],ebx
   11d93:	mov    DWORD PTR [ebp-0x1c],ebx
   11d96:	call   DWORD PTR ds:0x17284
   11d9c:	pop    edi
   11d9d:	pop    esi
   11d9e:	pop    ebx
   11d9f:	leave
   11da0:	ret    0x4
   11da3:	int3
   11da4:	int3
   11da5:	int3
   11da6:	int3
   11da7:	int3
   11da8:	mov    edi,edi
   11daa:	push   ebp
   11dab:	mov    ebp,esp
   11dad:	sub    esp,0x34
   11db0:	push   edi
   11db1:	xor    eax,eax
   11db3:	lea    edi,[ebp-0x14]
   11db6:	stos   DWORD PTR es:[edi],eax
   11db7:	stos   DWORD PTR es:[edi],eax
   11db8:	stos   DWORD PTR es:[edi],eax
   11db9:	stos   DWORD PTR es:[edi],eax
   11dba:	stos   DWORD PTR es:[edi],eax
   11dbb:	and    DWORD PTR [ebp-0x4],0x0
   11dbf:	push   0x8
   11dc1:	pop    ecx
   11dc2:	xor    eax,eax
   11dc4:	lea    edi,[ebp-0x34]
   11dc7:	rep stos DWORD PTR es:[edi],eax
   11dc9:	mov    eax,DWORD PTR [ebp+0x8]
   11dcc:	mov    ecx,DWORD PTR [eax]
   11dce:	add    eax,0x4
   11dd1:	push   eax
   11dd2:	lea    eax,[ebp-0x34]
   11dd5:	push   eax
   11dd6:	lea    eax,[ebp-0x14]
   11dd9:	xor    edx,edx
   11ddb:	inc    edx
   11ddc:	push   eax
   11ddd:	push   DWORD PTR ds:0x1770c
   11de3:	mov    DWORD PTR [ebp-0x14],0x14
   11dea:	mov    DWORD PTR [ebp-0x10],0x119f0
   11df1:	mov    BYTE PTR [ebp-0x8],dl
   11df4:	mov    DWORD PTR [ebp-0xc],0x64
   11dfb:	mov    DWORD PTR [ebp-0x34],0x20
   11e02:	mov    DWORD PTR [ebp-0x28],edx
   11e05:	mov    DWORD PTR [ebp-0x24],edx
   11e08:	mov    DWORD PTR [ebp-0x20],ecx
   11e0b:	call   DWORD PTR ds:0x175c0
   11e11:	pop    edi
   11e12:	leave
   11e13:	ret    0x4
   11e16:	int3
   11e17:	int3
   11e18:	int3
   11e19:	int3
   11e1a:	int3
   11e1b:	int3
   11e1c:	mov    edi,edi
   11e1e:	push   ebp
   11e1f:	mov    ebp,esp
   11e21:	mov    ecx,DWORD PTR [ebp+0x8]
   11e24:	mov    al,BYTE PTR [ecx+0x34]
   11e27:	cmp    al,0xff
   11e29:	jne    0x11e2f
   11e2b:	xor    eax,eax
   11e2d:	jmp    0x11e41
   11e2f:	movzx  ax,al
   11e33:	movzx  eax,ax
   11e36:	push   eax
   11e37:	push   0x0
   11e39:	push   0x22
   11e3b:	push   ecx
   11e3c:	call   0x11a8e
   11e41:	pop    ebp
   11e42:	ret    0x4
   11e45:	int3
   11e46:	int3
   11e47:	int3
   11e48:	int3
   11e49:	int3
   11e4a:	mov    edi,edi
   11e4c:	push   ebp
   11e4d:	mov    ebp,esp
   11e4f:	sub    esp,0x14
   11e52:	push   esi
   11e53:	mov    esi,DWORD PTR [ebp+0x8]
   11e56:	xor    eax,eax
   11e58:	cmp    BYTE PTR [esi+0x34],0xff
   11e5c:	je     0x11ea4
   11e5e:	push   edi
   11e5f:	lea    edi,[ebp-0x14]
   11e62:	stos   DWORD PTR es:[edi],eax
   11e63:	stos   DWORD PTR es:[edi],eax
   11e64:	stos   DWORD PTR es:[edi],eax
   11e65:	stos   DWORD PTR es:[edi],eax
   11e66:	stos   DWORD PTR es:[edi],eax
   11e67:	lea    eax,[ebp-0x14]
   11e6a:	push   eax
   11e6b:	push   DWORD PTR [esi+0x40]
   11e6e:	mov    DWORD PTR [ebp-0x14],0x14
   11e75:	push   DWORD PTR ds:0x1770c
   11e7b:	call   DWORD PTR ds:0x1761c
   11e81:	movzx  ax,BYTE PTR [ebp-0xc]
   11e86:	movzx  cx,BYTE PTR [esi+0x34]
   11e8b:	shl    ax,0x8
   11e8f:	or     ax,0x1
   11e93:	movzx  ecx,cx
   11e96:	movzx  eax,ax
   11e99:	push   ecx
   11e9a:	push   eax
   11e9b:	push   0x22
   11e9d:	push   esi
   11e9e:	call   0x11a8e
   11ea3:	pop    edi
   11ea4:	pop    esi
   11ea5:	leave
   11ea6:	ret    0x4
   11ea9:	int3
   11eaa:	int3
   11eab:	int3
   11eac:	int3
   11ead:	int3
   11eae:	mov    edi,edi
   11eb0:	push   ebp
   11eb1:	mov    ebp,esp
   11eb3:	mov    ecx,DWORD PTR [ebp+0x8]
   11eb6:	mov    al,BYTE PTR [ecx+0x34]
   11eb9:	cmp    al,0xff
   11ebb:	jne    0x11ec1
   11ebd:	xor    eax,eax
   11ebf:	jmp    0x11ed3
   11ec1:	movzx  ax,al
   11ec5:	movzx  eax,ax
   11ec8:	push   eax
   11ec9:	push   0x1
   11ecb:	push   0x22
   11ecd:	push   ecx
   11ece:	call   0x11a8e
   11ed3:	pop    ebp
   11ed4:	ret    0x4
   11ed7:	int3
   11ed8:	int3
   11ed9:	int3
   11eda:	int3
   11edb:	int3
   11edc:	mov    edi,edi
   11ede:	push   ebp
   11edf:	mov    ebp,esp
   11ee1:	sub    esp,0x138
   11ee7:	mov    eax,ds:0x17044
   11eec:	xor    eax,ebp
   11eee:	mov    DWORD PTR [ebp-0x4],eax
   11ef1:	push   ebx
   11ef2:	mov    ebx,DWORD PTR [ebp+0x8]
   11ef5:	mov    eax,DWORD PTR [ebx]
   11ef7:	push   esi
   11ef8:	lea    ecx,[ebp-0x100]
   11efe:	push   ecx
   11eff:	xor    esi,esi
   11f01:	push   esi
   11f02:	push   0x1f0000
   11f07:	push   0x1
   11f09:	push   eax
   11f0a:	mov    DWORD PTR [ebx+0x13c],0x5
   11f14:	mov    DWORD PTR [ebx+0x140],0x20000
   11f1e:	mov    BYTE PTR [ebx+0x14b],0x1
   11f25:	mov    DWORD PTR [ebx+0x144],0x1000
   11f2f:	mov    BYTE PTR [ebx+0x148],0x1
   11f36:	mov    BYTE PTR [ebx+0x14a],0x0
   11f3d:	mov    BYTE PTR [ebx+0x149],0x0
   11f44:	push   DWORD PTR ds:0x1770c
   11f4a:	mov    DWORD PTR [ebp-0x100],esi
   11f50:	call   DWORD PTR ds:0x17188
   11f56:	test   eax,eax
   11f58:	jne    0x12212
   11f5e:	push   edi
   11f5f:	push   0xd
   11f61:	pop    ecx
   11f62:	push   0x32
   11f64:	pop    eax
   11f65:	push   0x34
   11f67:	mov    WORD PTR [ebp-0x118],ax
   11f6e:	pop    eax
   11f6f:	push   0x9
   11f71:	mov    WORD PTR [ebp-0x116],ax
   11f78:	mov    esi,0x15636
   11f7d:	lea    edi,[ebp-0xf8]
   11f83:	rep movs DWORD PTR es:[edi],DWORD PTR ds:[esi]
   11f85:	pop    ecx
   11f86:	push   0x22
   11f88:	lea    eax,[ebp-0xf8]
   11f8e:	mov    DWORD PTR [ebp-0x114],eax
   11f94:	pop    eax
   11f95:	push   0x24
   11f97:	mov    WORD PTR [ebp-0x138],ax
   11f9e:	pop    eax
   11f9f:	push   0xa
   11fa1:	mov    WORD PTR [ebp-0x136],ax
   11fa8:	mov    esi,0x15612
   11fad:	lea    edi,[ebp-0x78]
   11fb0:	rep movs DWORD PTR es:[edi],DWORD PTR ds:[esi]
   11fb2:	pop    ecx
   11fb3:	push   0x26
   11fb5:	lea    eax,[ebp-0x78]
   11fb8:	mov    DWORD PTR [ebp-0x134],eax
   11fbe:	pop    eax
   11fbf:	push   0x28
   11fc1:	mov    WORD PTR [ebp-0x130],ax
   11fc8:	pop    eax
   11fc9:	push   0x9
   11fcb:	mov    WORD PTR [ebp-0x12e],ax
   11fd2:	mov    esi,0x155ea
   11fd7:	lea    edi,[ebp-0xc4]
   11fdd:	rep movs DWORD PTR es:[edi],DWORD PTR ds:[esi]
   11fdf:	pop    ecx
   11fe0:	push   0x22
   11fe2:	lea    eax,[ebp-0xc4]
   11fe8:	mov    DWORD PTR [ebp-0x12c],eax
   11fee:	pop    eax
   11fef:	push   0x24
   11ff1:	mov    WORD PTR [ebp-0x120],ax
   11ff8:	pop    eax
   11ff9:	push   0x5
   11ffb:	mov    WORD PTR [ebp-0x11e],ax
   12002:	mov    esi,0x155c6
   12007:	lea    edi,[ebp-0x9c]
   1200d:	rep movs DWORD PTR es:[edi],DWORD PTR ds:[esi]
   1200f:	pop    ecx
   12010:	push   0x14
   12012:	lea    eax,[ebp-0x9c]
   12018:	mov    DWORD PTR [ebp-0x11c],eax
   1201e:	pop    eax
   1201f:	push   0x16
   12021:	mov    WORD PTR [ebp-0x110],ax
   12028:	pop    eax
   12029:	push   0x7
   1202b:	mov    esi,0x155b0
   12030:	lea    edi,[ebp-0x1c]
   12033:	rep movs DWORD PTR es:[edi],DWORD PTR ds:[esi]
   12035:	pop    ecx
   12036:	mov    WORD PTR [ebp-0x10e],ax
   1203d:	push   0x1a
   1203f:	lea    eax,[ebp-0x1c]
   12042:	mov    DWORD PTR [ebp-0x10c],eax
   12048:	pop    eax
   12049:	push   0x1c
   1204b:	mov    WORD PTR [ebp-0x128],ax
   12052:	pop    eax
   12053:	movs   WORD PTR es:[edi],WORD PTR ds:[esi]
   12055:	mov    WORD PTR [ebp-0x126],ax
   1205c:	mov    esi,0x15594
   12061:	lea    edi,[ebp-0x54]
   12064:	lea    eax,[ebp-0x54]
   12067:	rep movs DWORD PTR es:[edi],DWORD PTR ds:[esi]
   12069:	mov    DWORD PTR [ebp-0x124],eax
   1206f:	push   0x6
   12071:	pop    ecx
   12072:	push   0x18
   12074:	pop    eax
   12075:	push   0x1a
   12077:	mov    WORD PTR [ebp-0x108],ax
   1207e:	pop    eax
   1207f:	mov    WORD PTR [ebp-0x106],ax
   12086:	mov    esi,0x1557a
   1208b:	lea    edi,[ebp-0x38]
   1208e:	lea    eax,[ebp-0x38]
   12091:	rep movs DWORD PTR es:[edi],DWORD PTR ds:[esi]
   12093:	mov    DWORD PTR [ebp-0x104],eax
   12099:	lea    eax,[ebp-0xfc]
   1209f:	push   eax
   120a0:	lea    eax,[ebp-0x118]
   120a6:	push   eax
   120a7:	push   DWORD PTR [ebp-0x100]
   120ad:	movs   WORD PTR es:[edi],WORD PTR ds:[esi]
   120af:	push   DWORD PTR ds:0x1770c
   120b5:	call   DWORD PTR ds:0x17488
   120bb:	pop    edi
   120bc:	test   eax,eax
   120be:	jne    0x120cc
   120c0:	mov    eax,DWORD PTR [ebp-0xfc]
   120c6:	mov    DWORD PTR [ebx+0x13c],eax
   120cc:	lea    eax,[ebp-0xfc]
   120d2:	push   eax
   120d3:	lea    eax,[ebp-0x138]
   120d9:	push   eax
   120da:	push   DWORD PTR [ebp-0x100]
   120e0:	push   DWORD PTR ds:0x1770c
   120e6:	call   DWORD PTR ds:0x17488
   120ec:	test   eax,eax
   120ee:	jne    0x120ff
   120f0:	cmp    DWORD PTR [ebp-0xfc],eax
   120f6:	setne  al
   120f9:	mov    BYTE PTR [ebx+0x148],al
   120ff:	lea    eax,[ebp-0xfc]
   12105:	push   eax
   12106:	lea    eax,[ebp-0x130]
   1210c:	push   eax
   1210d:	push   DWORD PTR [ebp-0x100]
   12113:	push   DWORD PTR ds:0x1770c
   12119:	call   DWORD PTR ds:0x17488
   1211f:	test   eax,eax
   12121:	jne    0x12132
   12123:	cmp    DWORD PTR [ebp-0xfc],eax
   12129:	setne  al
   1212c:	mov    BYTE PTR [ebx+0x149],al
   12132:	lea    eax,[ebp-0xfc]
   12138:	push   eax
   12139:	lea    eax,[ebp-0x120]
   1213f:	push   eax
   12140:	push   DWORD PTR [ebp-0x100]
   12146:	push   DWORD PTR ds:0x1770c
   1214c:	call   DWORD PTR ds:0x17488
   12152:	test   eax,eax
   12154:	jne    0x12165
   12156:	cmp    DWORD PTR [ebp-0xfc],eax
   1215c:	setne  al
   1215f:	mov    BYTE PTR [ebx+0x14a],al
   12165:	lea    eax,[ebp-0xfc]
   1216b:	push   eax
   1216c:	lea    eax,[ebp-0x110]
   12172:	push   eax
   12173:	push   DWORD PTR [ebp-0x100]
   12179:	push   DWORD PTR ds:0x1770c
   1217f:	call   DWORD PTR ds:0x17488
   12185:	test   eax,eax
   12187:	jne    0x12198
   12189:	mov    eax,DWORD PTR [ebp-0xfc]
   1218f:	shl    eax,0xa
   12192:	mov    DWORD PTR [ebx+0x140],eax
   12198:	lea    eax,[ebp-0xfc]
   1219e:	push   eax
   1219f:	lea    eax,[ebp-0x108]
   121a5:	push   eax
   121a6:	push   DWORD PTR [ebp-0x100]
   121ac:	push   DWORD PTR ds:0x1770c
   121b2:	call   DWORD PTR ds:0x17488
   121b8:	test   eax,eax
   121ba:	jne    0x121cb
   121bc:	cmp    DWORD PTR [ebp-0xfc],eax
   121c2:	setne  al
   121c5:	mov    BYTE PTR [ebx+0x14b],al
   121cb:	lea    eax,[ebp-0xfc]
   121d1:	push   eax
   121d2:	lea    eax,[ebp-0x128]
   121d8:	push   eax
   121d9:	push   DWORD PTR [ebp-0x100]
   121df:	push   DWORD PTR ds:0x1770c
   121e5:	call   DWORD PTR ds:0x17488
   121eb:	test   eax,eax
   121ed:	jne    0x121fe
   121ef:	mov    eax,DWORD PTR [ebp-0xfc]
   121f5:	shl    eax,0xa
   121f8:	mov    DWORD PTR [ebx+0x144],eax
   121fe:	push   DWORD PTR [ebp-0x100]
   12204:	push   DWORD PTR ds:0x1770c
   1220a:	call   DWORD PTR ds:0x17464
   12210:	xor    esi,esi
   12212:	cmp    BYTE PTR [ebx+0x148],0x0
   12219:	je     0x1223b
   1221b:	mov    DWORD PTR [ebx+0x14c],0x11e1c
   12225:	mov    DWORD PTR [ebx+0x150],0x11e4a
   1222f:	mov    DWORD PTR [ebx+0x154],0x140c4
   12239:	jmp    0x12276
   1223b:	cmp    BYTE PTR [ebx+0x149],0x0
   12242:	je     0x12264
   12244:	mov    DWORD PTR [ebx+0x14c],0x140c4
   1224e:	mov    DWORD PTR [ebx+0x150],0x11eae
   12258:	mov    DWORD PTR [ebx+0x154],0x11e1c
   12262:	jmp    0x12276
   12264:	mov    DWORD PTR [ebx+0x14c],esi
   1226a:	mov    DWORD PTR [ebx+0x150],esi
   12270:	mov    DWORD PTR [ebx+0x154],esi
   12276:	mov    ecx,DWORD PTR [ebp-0x4]
   12279:	pop    esi
   1227a:	xor    ecx,ebp
   1227c:	pop    ebx
   1227d:	call   0x144c2
   12282:	leave
   12283:	ret    0x4
   12286:	int3
   12287:	int3
   12288:	int3
   12289:	int3
   1228a:	int3
   1228b:	int3
   1228c:	mov    edi,edi
   1228e:	push   ebp
   1228f:	mov    ebp,esp
   12291:	sub    esp,0x5c
   12294:	mov    edx,DWORD PTR [ebp+0x8]
   12297:	mov    ecx,DWORD PTR ds:0x1770c
   1229d:	push   ebx
   1229e:	push   esi
   1229f:	push   edi
   122a0:	push   DWORD PTR ds:0x17034
   122a6:	call   DWORD PTR ds:0x173f0
   122ac:	mov    ebx,eax
   122ae:	xor    edi,edi
   122b0:	lea    esi,[ebx+0x2c]
   122b3:	mov    DWORD PTR [ebp+0x8],edi
   122b6:	cmp    DWORD PTR [esi],edi
   122b8:	jne    0x122d3
   122ba:	mov    eax,DWORD PTR [ebx]
   122bc:	push   esi
   122bd:	push   edi
   122be:	push   eax
   122bf:	push   DWORD PTR ds:0x1770c
   122c5:	call   DWORD PTR ds:0x175d0
   122cb:	cmp    eax,edi
   122cd:	jne    0x12453
   122d3:	lea    eax,[ebx+0x48]
   122d6:	push   eax
   122d7:	push   DWORD PTR [esi]
   122d9:	push   DWORD PTR ds:0x1770c
   122df:	call   DWORD PTR ds:0x175d8
   122e5:	mov    eax,DWORD PTR [esi]
   122e7:	lea    ecx,[ebp+0x8]
   122ea:	push   ecx
   122eb:	push   edi
   122ec:	push   eax
   122ed:	push   DWORD PTR ds:0x1770c
   122f3:	call   DWORD PTR ds:0x175dc
   122f9:	cmp    eax,0xc0000023
   122fe:	jne    0x12453
   12304:	cmp    WORD PTR [ebp+0x8],di
   12308:	je     0x12453
   1230e:	push   0x8
   12310:	pop    ecx
   12311:	xor    eax,eax
   12313:	lea    edi,[ebp-0x38]
   12316:	rep stos DWORD PTR es:[edi],eax
   12318:	inc    eax
   12319:	mov    DWORD PTR [ebp-0x2c],eax
   1231c:	mov    DWORD PTR [ebp-0x28],eax
   1231f:	mov    DWORD PTR [ebp-0x38],0x20
   12326:	mov    eax,DWORD PTR [ebx]
   12328:	mov    DWORD PTR [ebp-0x24],eax
   1232b:	movzx  eax,WORD PTR [ebp+0x8]
   1232f:	lea    edi,[ebx+0x38]
   12332:	push   edi
   12333:	lea    ecx,[ebp-0x4]
   12336:	push   ecx
   12337:	push   eax
   12338:	push   0x6d6f6355
   1233d:	push   0x0
   1233f:	lea    eax,[ebp-0x38]
   12342:	push   eax
   12343:	push   DWORD PTR ds:0x1770c
   12349:	call   DWORD PTR ds:0x173c8
   1234f:	test   eax,eax
   12351:	jne    0x12453
   12357:	mov    edi,DWORD PTR [edi]
   12359:	mov    eax,DWORD PTR [esi]
   1235b:	lea    ecx,[ebp+0x8]
   1235e:	push   ecx
   1235f:	push   edi
   12360:	push   eax
   12361:	push   DWORD PTR ds:0x1770c
   12367:	call   DWORD PTR ds:0x175dc
   1236d:	test   eax,eax
   1236f:	jne    0x12453
   12375:	push   DWORD PTR [esi]
   12377:	push   DWORD PTR ds:0x1770c
   1237d:	call   DWORD PTR ds:0x175ec
   12383:	sub    esp,0x14
   12386:	lea    edi,[ebp-0x18]
   12389:	push   0x5
   1238b:	mov    BYTE PTR [ebx+0x136],al
   12391:	mov    esi,edi
   12393:	pop    ecx
   12394:	cmp    al,0x1
   12396:	jne    0x123b9
   12398:	xor    eax,eax
   1239a:	stos   DWORD PTR es:[edi],eax
   1239b:	stos   DWORD PTR es:[edi],eax
   1239c:	stos   DWORD PTR es:[edi],eax
   1239d:	stos   DWORD PTR es:[edi],eax
   1239e:	stos   DWORD PTR es:[edi],eax
   1239f:	mov    edi,esp
   123a1:	mov    DWORD PTR [ebp-0x18],0x14
   123a8:	mov    DWORD PTR [ebp-0x14],0x2
   123af:	push   ebx
   123b0:	rep movs DWORD PTR es:[edi],DWORD PTR ds:[esi]
   123b2:	call   0x115a6
   123b7:	jmp    0x123d8
   123b9:	xor    eax,eax
   123bb:	stos   DWORD PTR es:[edi],eax
   123bc:	stos   DWORD PTR es:[edi],eax
   123bd:	stos   DWORD PTR es:[edi],eax
   123be:	stos   DWORD PTR es:[edi],eax
   123bf:	stos   DWORD PTR es:[edi],eax
   123c0:	mov    edi,esp
   123c2:	mov    DWORD PTR [ebp-0x18],0x14
   123c9:	mov    DWORD PTR [ebp-0x14],0x3
   123d0:	push   ebx
   123d1:	rep movs DWORD PTR es:[edi],DWORD PTR ds:[esi]
   123d3:	call   0x1165c
   123d8:	test   eax,eax
   123da:	jne    0x12453
   123dc:	cmp    DWORD PTR [ebx+0x40],eax
   123df:	je     0x1244e
   123e1:	cmp    DWORD PTR [ebx+0x44],eax
   123e4:	je     0x1244e
   123e6:	mov    eax,DWORD PTR [ebx+0x30]
   123e9:	test   eax,eax
   123eb:	je     0x123fd
   123ed:	push   eax
   123ee:	push   DWORD PTR ds:0x1770c
   123f4:	call   DWORD PTR ds:0x1765c
   123fa:	mov    BYTE PTR [ebx+0x34],al
   123fd:	push   ebx
   123fe:	call   0x11498
   12403:	test   eax,eax
   12405:	jne    0x12453
   12407:	cmp    BYTE PTR [ebx+0x14a],al
   1240d:	je     0x12453
   1240f:	mov    edx,DWORD PTR [ebx+0x144]
   12415:	push   0x9
   12417:	pop    ecx
   12418:	lea    edi,[ebp-0x5c]
   1241b:	rep stos DWORD PTR es:[edi],eax
   1241d:	lea    eax,[ebp-0x5c]
   12420:	mov    DWORD PTR [ebp-0x5c],0x24
   12427:	mov    DWORD PTR [ebp-0x44],0x136ea
   1242e:	mov    DWORD PTR [ebp-0x40],ebx
   12431:	mov    DWORD PTR [ebp-0x58],edx
   12434:	mov    DWORD PTR [ebp-0x3c],0x136e0
   1243b:	mov    ebx,DWORD PTR [ebx+0x44]
   1243e:	push   eax
   1243f:	push   ebx
   12440:	push   DWORD PTR ds:0x1770c
   12446:	call   DWORD PTR ds:0x17640
   1244c:	jmp    0x12453
   1244e:	mov    eax,0xc0000001
   12453:	pop    edi
   12454:	pop    esi
   12455:	pop    ebx
   12456:	leave
   12457:	ret    0xc
   1245a:	int3
   1245b:	int3
   1245c:	int3
   1245d:	int3
   1245e:	int3
   1245f:	int3
   12460:	mov    edi,edi
   12462:	push   ebp
   12463:	mov    ebp,esp
   12465:	mov    edx,DWORD PTR [ebp+0x8]
   12468:	mov    ecx,DWORD PTR ds:0x1770c
   1246e:	push   esi
   1246f:	push   DWORD PTR ds:0x17034
   12475:	call   DWORD PTR ds:0x173f0
   1247b:	mov    esi,eax
   1247d:	lea    eax,[esi+0x7c]
   12480:	xor    ecx,ecx
   12482:	mov    DWORD PTR [ebp+0x8],eax
   12485:	inc    ecx
   12486:	xchg   DWORD PTR [eax],ecx
   12488:	test   ecx,ecx
   1248a:	je     0x124a5
   1248c:	push   0x80000011
   12491:	push   DWORD PTR [ebp+0xc]
   12494:	push   DWORD PTR ds:0x1770c
   1249a:	call   DWORD PTR ds:0x174e4
   124a0:	jmp    0x1258d
   124a5:	mov    DWORD PTR [esi+0x100],0x30
   124af:	xor    eax,eax
   124b1:	push   ebx
   124b2:	push   edi
   124b3:	xor    ebx,ebx
   124b5:	mov    DWORD PTR [esi+0xc8],ebx
   124bb:	mov    DWORD PTR [esi+0x130],ebx
   124c1:	mov    DWORD PTR [esi+0x10],ebx
   124c4:	lea    edi,[esi+0xd8]
   124ca:	stos   DWORD PTR es:[edi],eax
   124cb:	stos   DWORD PTR es:[edi],eax
   124cc:	stos   DWORD PTR es:[edi],eax
   124cd:	stos   DWORD PTR es:[edi],eax
   124ce:	stos   DWORD PTR es:[edi],eax
   124cf:	xor    eax,eax
   124d1:	lea    edi,[esi+0xd0]
   124d7:	stos   DWORD PTR es:[edi],eax
   124d8:	stos   WORD PTR es:[edi],ax
   124da:	mov    DWORD PTR [esi+0xcc],0x800
   124e4:	xor    eax,eax
   124e6:	lea    edi,[esi+0xec]
   124ec:	stos   DWORD PTR es:[edi],eax
   124ed:	stos   DWORD PTR es:[edi],eax
   124ee:	stos   DWORD PTR es:[edi],eax
   124ef:	stos   DWORD PTR es:[edi],eax
   124f0:	xor    eax,eax
   124f2:	lea    edi,[esi+0xfc]
   124f8:	stos   WORD PTR es:[edi],ax
   124fa:	stos   BYTE PTR es:[edi],al
   124fb:	xor    eax,eax
   124fd:	lea    edi,[esi+0x11c]
   12503:	stos   DWORD PTR es:[edi],eax
   12504:	stos   DWORD PTR es:[edi],eax
   12505:	stos   DWORD PTR es:[edi],eax
   12506:	stos   DWORD PTR es:[edi],eax
   12507:	stos   DWORD PTR es:[edi],eax
   12508:	lea    eax,[esi+0xb0]
   1250e:	mov    BYTE PTR [esi+0x137],bl
   12514:	mov    BYTE PTR [esi+0x138],bl
   1251a:	mov    ecx,DWORD PTR [eax]
   1251c:	push   esi
   1251d:	mov    DWORD PTR [eax+0x8],ecx
   12520:	mov    DWORD PTR [eax+0x4],ecx
   12523:	call   0x114b6
   12528:	mov    edi,eax
   1252a:	cmp    edi,ebx
   1252c:	jne    0x12563
   1252e:	xor    eax,eax
   12530:	inc    eax
   12531:	lea    ecx,[esi+0x80]
   12537:	xchg   DWORD PTR [ecx],eax
   12539:	test   eax,eax
   1253b:	jne    0x12549
   1253d:	push   esi
   1253e:	call   0x117b6
   12543:	mov    edi,eax
   12545:	cmp    edi,ebx
   12547:	jne    0x12563
   12549:	push   0xffffffff
   1254b:	push   0xfff0bdc0
   12550:	push   DWORD PTR [esi+0x4]
   12553:	push   DWORD PTR ds:0x1770c
   12559:	call   DWORD PTR ds:0x175c4
   1255f:	cmp    edi,ebx
   12561:	je     0x1256c
   12563:	mov    ecx,DWORD PTR [ebp+0x8]
   12566:	xor    eax,eax
   12568:	xchg   DWORD PTR [ecx],eax
   1256a:	jmp    0x1257b
   1256c:	push   ebx
   1256d:	push   DWORD PTR [esi]
   1256f:	push   DWORD PTR ds:0x1770c
   12575:	call   DWORD PTR ds:0x171f8
   1257b:	push   edi
   1257c:	push   DWORD PTR [ebp+0xc]
   1257f:	push   DWORD PTR ds:0x1770c
   12585:	call   DWORD PTR ds:0x174e4
   1258b:	pop    edi
   1258c:	pop    ebx
   1258d:	pop    esi
   1258e:	pop    ebp
   1258f:	ret    0xc
   12592:	int3
   12593:	int3
   12594:	int3
   12595:	int3
   12596:	int3
   12597:	int3
   12598:	mov    edi,edi
   1259a:	push   ebp
   1259b:	mov    ebp,esp
   1259d:	push   esi
   1259e:	mov    esi,DWORD PTR [ebp+0x8]
   125a1:	push   esi
   125a2:	call   0x11bba
   125a7:	test   al,al
   125a9:	je     0x125af
   125ab:	xor    eax,eax
   125ad:	jmp    0x125c6
   125af:	mov    eax,DWORD PTR [esi+0x4]
   125b2:	mov    cl,BYTE PTR [ebp+0xc]
   125b5:	mov    BYTE PTR [eax],cl
   125b7:	push   DWORD PTR [esi+0x4]
   125ba:	push   esi
   125bb:	call   0x11b5a
   125c0:	mov    DWORD PTR [esi+0x4],eax
   125c3:	xor    eax,eax
   125c5:	inc    eax
   125c6:	pop    esi
   125c7:	pop    ebp
   125c8:	ret    0x8
   125cb:	int3
   125cc:	int3
   125cd:	int3
   125ce:	int3
   125cf:	int3
   125d0:	mov    edi,edi
   125d2:	push   ebp
   125d3:	mov    ebp,esp
   125d5:	mov    edx,DWORD PTR [ebp+0x8]
   125d8:	push   edx
   125d9:	call   0x11b9e
   125de:	test   al,al
   125e0:	je     0x125e6
   125e2:	xor    eax,eax
   125e4:	jmp    0x125ff
   125e6:	mov    eax,DWORD PTR [edx+0x8]
   125e9:	mov    al,BYTE PTR [eax]
   125eb:	mov    ecx,DWORD PTR [ebp+0xc]
   125ee:	mov    BYTE PTR [ecx],al
   125f0:	push   DWORD PTR [edx+0x8]
   125f3:	push   edx
   125f4:	call   0x11b5a
   125f9:	mov    DWORD PTR [edx+0x8],eax
   125fc:	xor    eax,eax
   125fe:	inc    eax
   125ff:	pop    ebp
   12600:	ret    0x8
   12603:	int3
   12604:	int3
   12605:	int3
   12606:	int3
   12607:	int3
   12608:	mov    edi,edi
   1260a:	push   ebp
   1260b:	mov    ebp,esp
   1260d:	sub    esp,0x60
   12610:	mov    ecx,DWORD PTR ds:0x1770c
   12616:	push   ebx
   12617:	push   esi
   12618:	mov    esi,DWORD PTR [ebp+0x8]
   1261b:	push   edi
   1261c:	mov    edx,esi
   1261e:	call   DWORD PTR ds:0x173f8
   12624:	push   0x158
   12629:	xor    ebx,ebx
   1262b:	mov    edi,eax
   1262d:	push   ebx
   1262e:	push   esi
   1262f:	mov    DWORD PTR [ebp-0x4],edi
   12632:	call   0x1450e
   12637:	add    esp,0xc
   1263a:	push   esi
   1263b:	mov    DWORD PTR [esi],edi
   1263d:	mov    BYTE PTR [esi+0x34],0xff
   12641:	call   0x11edc
   12646:	mov    eax,DWORD PTR [esi+0x140]
   1264c:	push   0x1
   1264e:	mov    DWORD PTR [esi+0xc0],eax
   12654:	push   ebx
   12655:	lea    eax,[esi+0x60]
   12658:	push   eax
   12659:	call   DWORD PTR ds:0x16024
   1265f:	push   esi
   12660:	call   0x11c9c
   12665:	mov    DWORD PTR [ebp+0x8],eax
   12668:	cmp    eax,ebx
   1266a:	jne    0x1280d
   12670:	push   esi
   12671:	call   0x11da8
   12676:	mov    DWORD PTR [ebp+0x8],eax
   12679:	cmp    eax,ebx
   1267b:	jne    0x1280d
   12681:	push   esi
   12682:	call   0x1119a
   12687:	mov    DWORD PTR [ebp+0x8],eax
   1268a:	cmp    eax,ebx
   1268c:	jne    0x1280d
   12692:	push   0x34
   12694:	pop    edi
   12695:	push   edi
   12696:	lea    eax,[ebp-0x60]
   12699:	push   ebx
   1269a:	push   eax
   1269b:	call   0x1450e
   126a0:	add    esp,0xc
   126a3:	lea    eax,[esi+0x8]
   126a6:	push   eax
   126a7:	push   0x0
   126a9:	lea    eax,[ebp-0x60]
   126ac:	push   eax
   126ad:	push   DWORD PTR [ebp-0x4]
   126b0:	mov    DWORD PTR [ebp-0x60],edi
   126b3:	push   DWORD PTR ds:0x1770c
   126b9:	mov    ebx,0x132c8
   126be:	mov    edi,0x1320e
   126c3:	mov    DWORD PTR [ebp-0x58],0x2
   126ca:	mov    DWORD PTR [ebp-0x5c],0x3
   126d1:	mov    DWORD PTR [ebp-0x3c],0x13232
   126d8:	mov    DWORD PTR [ebp-0x38],ebx
   126db:	mov    DWORD PTR [ebp-0x34],edi
   126de:	call   DWORD PTR ds:0x17328
   126e4:	mov    DWORD PTR [ebp+0x8],eax
   126e7:	test   eax,eax
   126e9:	jne    0x1280d
   126ef:	push   0x34
   126f1:	push   eax
   126f2:	lea    eax,[ebp-0x60]
   126f5:	push   eax
   126f6:	call   0x1450e
   126fb:	add    esp,0xc
   126fe:	lea    eax,[esi+0xc]
   12701:	push   eax
   12702:	push   0x0
   12704:	lea    eax,[ebp-0x60]
   12707:	push   eax
   12708:	push   DWORD PTR [ebp-0x4]
   1270b:	mov    DWORD PTR [ebp-0x60],0x34
   12712:	push   DWORD PTR ds:0x1770c
   12718:	mov    DWORD PTR [ebp-0x58],0x2
   1271f:	mov    DWORD PTR [ebp-0x5c],0x3
   12726:	mov    DWORD PTR [ebp-0x3c],0x13232
   1272d:	mov    DWORD PTR [ebp-0x38],ebx
   12730:	mov    DWORD PTR [ebp-0x34],edi
   12733:	call   DWORD PTR ds:0x17328
   12739:	mov    DWORD PTR [ebp+0x8],eax
   1273c:	test   eax,eax
   1273e:	jne    0x1280d
   12744:	push   0x34
   12746:	push   eax
   12747:	lea    eax,[ebp-0x60]
   1274a:	push   eax
   1274b:	call   0x1450e
   12750:	or     DWORD PTR [ebp-0x30],0xffffffff
   12754:	add    esp,0xc
   12757:	push   0x2
   12759:	pop    eax
   1275a:	mov    DWORD PTR [ebp-0x58],eax
   1275d:	mov    DWORD PTR [ebp-0x5c],eax
   12760:	lea    eax,[ebp-0xc]
   12763:	push   eax
   12764:	push   0x0
   12766:	lea    eax,[ebp-0x60]
   12769:	push   eax
   1276a:	push   DWORD PTR [ebp-0x4]
   1276d:	mov    DWORD PTR [ebp-0x60],0x34
   12774:	push   DWORD PTR ds:0x1770c
   1277a:	mov    BYTE PTR [ebp-0x53],0x1
   1277e:	mov    DWORD PTR [ebp-0x4c],0x13124
   12785:	mov    DWORD PTR [ebp-0x48],0x13190
   1278c:	mov    DWORD PTR [ebp-0x3c],0x13232
   12793:	mov    DWORD PTR [ebp-0x38],ebx
   12796:	mov    DWORD PTR [ebp-0x44],0x12b9c
   1279d:	mov    DWORD PTR [ebp-0x34],edi
   127a0:	call   DWORD PTR ds:0x17328
   127a6:	mov    DWORD PTR [ebp+0x8],eax
   127a9:	test   eax,eax
   127ab:	jne    0x1280d
   127ad:	push   0x8
   127af:	pop    ecx
   127b0:	lea    edi,[ebp-0x2c]
   127b3:	rep stos DWORD PTR es:[edi],eax
   127b5:	inc    eax
   127b6:	mov    DWORD PTR [ebp-0x20],eax
   127b9:	mov    DWORD PTR [ebp-0x1c],eax
   127bc:	mov    eax,DWORD PTR [esi]
   127be:	lea    ecx,[ebp-0x8]
   127c1:	push   ecx
   127c2:	mov    DWORD PTR [ebp-0x18],eax
   127c5:	mov    eax,DWORD PTR [esi+0xc0]
   127cb:	lea    ecx,[esi+0xc4]
   127d1:	push   ecx
   127d2:	push   eax
   127d3:	push   0x6d6f6355
   127d8:	push   0x0
   127da:	lea    eax,[ebp-0x2c]
   127dd:	push   eax
   127de:	push   DWORD PTR ds:0x1770c
   127e4:	mov    DWORD PTR [ebp-0x2c],0x20
   127eb:	call   DWORD PTR ds:0x173c8
   127f1:	mov    DWORD PTR [ebp+0x8],eax
   127f4:	test   eax,eax
   127f6:	jne    0x1280d
   127f8:	push   DWORD PTR [esi+0xc0]
   127fe:	add    esi,0xb0
   12804:	push   DWORD PTR [ebp-0x8]
   12807:	push   esi
   12808:	call   0x11b36
   1280d:	mov    eax,DWORD PTR [ebp+0x8]
   12810:	pop    edi
   12811:	pop    esi
   12812:	pop    ebx
   12813:	leave
   12814:	ret    0x4
   12817:	int3
   12818:	int3
   12819:	int3
   1281a:	int3
   1281b:	int3
   1281c:	mov    edi,edi
   1281e:	push   ebp
   1281f:	mov    ebp,esp
   12821:	sub    esp,0x1e0
   12827:	mov    eax,ds:0x17044
   1282c:	xor    eax,ebp
   1282e:	mov    DWORD PTR [ebp-0x4],eax
   12831:	mov    eax,DWORD PTR [ebp+0xc]
   12834:	and    DWORD PTR [ebp-0x10c],0x0
   1283b:	mov    DWORD PTR [ebp-0x108],eax
   12841:	xor    eax,eax
   12843:	mov    WORD PTR [ebp-0x114],ax
   1284a:	mov    eax,0x100
   1284f:	push   ebx
   12850:	mov    WORD PTR [ebp-0x112],ax
   12857:	lea    eax,[ebp-0x104]
   1285d:	xor    ebx,ebx
   1285f:	inc    ebx
   12860:	mov    DWORD PTR [ebp-0x110],eax
   12866:	mov    eax,0x170c0
   1286b:	mov    ecx,ebx
   1286d:	lock xadd DWORD PTR [eax],ecx
   12871:	inc    ecx
   12872:	push   ecx
   12873:	push   0x15676
   12878:	lea    eax,[ebp-0x114]
   1287e:	push   0x1566a
   12883:	push   eax
   12884:	call   0x11148
   12889:	add    esp,0x10
   1288c:	test   eax,eax
   1288e:	jne    0x12b87
   12894:	lea    eax,[ebp-0x114]
   1289a:	push   eax
   1289b:	push   DWORD PTR [ebp-0x108]
   128a1:	push   DWORD PTR ds:0x1770c
   128a7:	call   DWORD PTR ds:0x171d4
   128ad:	test   eax,eax
   128af:	jne    0x12b87
   128b5:	push   esi
   128b6:	push   edi
   128b7:	push   0x2b
   128b9:	push   DWORD PTR [ebp-0x108]
   128bf:	push   DWORD PTR ds:0x1770c
   128c5:	call   DWORD PTR ds:0x171d0
   128cb:	push   0x44
   128cd:	pop    esi
   128ce:	push   esi
   128cf:	lea    eax,[ebp-0x1e0]
   128d5:	push   0x0
   128d7:	push   eax
   128d8:	call   0x1450e
   128dd:	add    esp,0xc
   128e0:	lea    eax,[ebp-0x1e0]
   128e6:	push   eax
   128e7:	push   DWORD PTR [ebp-0x108]
   128ed:	mov    DWORD PTR [ebp-0x1e0],esi
   128f3:	push   DWORD PTR ds:0x1770c
   128f9:	mov    DWORD PTR [ebp-0x1dc],0x114f2
   12903:	mov    DWORD PTR [ebp-0x1d4],0x1154c
   1290d:	mov    DWORD PTR [ebp-0x1cc],0x1228c
   12917:	mov    DWORD PTR [ebp-0x1c8],0x11758
   12921:	mov    DWORD PTR [ebp-0x1c0],0x11792
   1292b:	mov    DWORD PTR [ebp-0x1b0],0x11792
   12935:	call   DWORD PTR ds:0x171a4
   1293b:	push   0x8
   1293d:	pop    ecx
   1293e:	xor    eax,eax
   12940:	lea    edi,[ebp-0x134]
   12946:	rep stos DWORD PTR es:[edi],eax
   12948:	mov    eax,ds:0x1700c
   1294d:	mov    DWORD PTR [ebp-0x118],eax
   12953:	lea    eax,[ebp-0x134]
   12959:	push   eax
   1295a:	push   DWORD PTR [ebp-0x108]
   12960:	mov    DWORD PTR [ebp-0x134],0x20
   1296a:	push   DWORD PTR ds:0x1770c
   12970:	mov    DWORD PTR [ebp-0x128],ebx
   12976:	mov    DWORD PTR [ebp-0x124],ebx
   1297c:	call   DWORD PTR ds:0x171e8
   12982:	push   0x4
   12984:	pop    edx
   12985:	push   0x2
   12987:	pop    esi
   12988:	push   0x8
   1298a:	pop    ecx
   1298b:	xor    eax,eax
   1298d:	lea    edi,[ebp-0x134]
   12993:	rep stos DWORD PTR es:[edi],eax
   12995:	lea    eax,[ebp-0x134]
   1299b:	push   eax
   1299c:	lea    eax,[ebp-0x17c]
   129a2:	push   eax
   129a3:	push   DWORD PTR [ebp-0x108]
   129a9:	mov    DWORD PTR [ebp-0x17c],0x18
   129b3:	push   DWORD PTR ds:0x1770c
   129b9:	mov    DWORD PTR [ebp-0x178],0x12460
   129c3:	mov    DWORD PTR [ebp-0x174],0x118f6
   129cd:	mov    DWORD PTR [ebp-0x170],0x119b0
   129d7:	mov    DWORD PTR [ebp-0x168],edx
   129dd:	mov    DWORD PTR [ebp-0x16c],esi
   129e3:	mov    DWORD PTR [ebp-0x134],0x20
   129ed:	mov    DWORD PTR [ebp-0x128],ebx
   129f3:	mov    DWORD PTR [ebp-0x124],edx
   129f9:	call   DWORD PTR ds:0x171e4
   129ff:	push   ebx
   12a00:	push   DWORD PTR [ebp-0x108]
   12a06:	push   DWORD PTR ds:0x1770c
   12a0c:	call   DWORD PTR ds:0x171c0
   12a12:	push   esi
   12a13:	push   DWORD PTR [ebp-0x108]
   12a19:	push   DWORD PTR ds:0x1770c
   12a1f:	call   DWORD PTR ds:0x171bc
   12a25:	push   0x8
   12a27:	pop    ecx
   12a28:	xor    eax,eax
   12a2a:	lea    edi,[ebp-0x19c]
   12a30:	rep stos DWORD PTR es:[edi],eax
   12a32:	mov    DWORD PTR [ebp-0x19c],0x20
   12a3c:	mov    DWORD PTR [ebp-0x190],ebx
   12a42:	mov    eax,ds:0x17034
   12a47:	mov    DWORD PTR [ebp-0x180],eax
   12a4d:	lea    eax,[ebp-0x10c]
   12a53:	push   eax
   12a54:	lea    eax,[ebp-0x19c]
   12a5a:	push   eax
   12a5b:	lea    eax,[ebp-0x108]
   12a61:	push   eax
   12a62:	push   DWORD PTR ds:0x1770c
   12a68:	mov    DWORD PTR [ebp-0x198],0x11a38
   12a72:	mov    DWORD PTR [ebp-0x18c],esi
   12a78:	call   DWORD PTR ds:0x171f4
   12a7e:	test   eax,eax
   12a80:	jl     0x12b85
   12a86:	push   0x30
   12a88:	pop    edi
   12a89:	push   edi
   12a8a:	lea    eax,[ebp-0x164]
   12a90:	push   0x0
   12a92:	push   eax
   12a93:	call   0x1450e
   12a98:	or     DWORD PTR [ebp-0x13c],0xffffffff
   12a9f:	or     DWORD PTR [ebp-0x138],0xffffffff
   12aa6:	add    esp,0xc
   12aa9:	lea    eax,[ebp-0x164]
   12aaf:	push   eax
   12ab0:	push   DWORD PTR [ebp-0x10c]
   12ab6:	mov    DWORD PTR [ebp-0x164],edi
   12abc:	push   DWORD PTR ds:0x1770c
   12ac2:	mov    DWORD PTR [ebp-0x160],esi
   12ac8:	mov    DWORD PTR [ebp-0x15c],esi
   12ace:	mov    DWORD PTR [ebp-0x154],esi
   12ad4:	mov    DWORD PTR [ebp-0x150],esi
   12ada:	mov    DWORD PTR [ebp-0x14c],esi
   12ae0:	mov    DWORD PTR [ebp-0x144],esi
   12ae6:	mov    DWORD PTR [ebp-0x140],esi
   12aec:	mov    DWORD PTR [ebp-0x158],ebx
   12af2:	mov    DWORD PTR [ebp-0x148],ebx
   12af8:	call   DWORD PTR ds:0x17214
   12afe:	push   DWORD PTR ds:0x17034
   12b04:	mov    edx,DWORD PTR [ebp-0x10c]
   12b0a:	mov    ecx,DWORD PTR ds:0x1770c
   12b10:	call   DWORD PTR ds:0x173f0
   12b16:	mov    esi,eax
   12b18:	push   esi
   12b19:	call   0x12608
   12b1e:	test   eax,eax
   12b20:	jl     0x12b85
   12b22:	push   esi
   12b23:	call   0x112cc
   12b28:	test   eax,eax
   12b2a:	jne    0x12b85
   12b2c:	push   0x8
   12b2e:	pop    ecx
   12b2f:	lea    edi,[ebp-0x134]
   12b35:	rep stos DWORD PTR es:[edi],eax
   12b37:	mov    DWORD PTR [ebp-0x134],0x20
   12b41:	mov    DWORD PTR [ebp-0x128],ebx
   12b47:	mov    DWORD PTR [ebp-0x124],ebx
   12b4d:	mov    eax,DWORD PTR [esi]
   12b4f:	mov    DWORD PTR [ebp-0x120],eax
   12b55:	lea    eax,[esi+0xa8]
   12b5b:	push   eax
   12b5c:	lea    eax,[ebp-0x134]
   12b62:	push   eax
   12b63:	push   DWORD PTR ds:0x1770c
   12b69:	call   DWORD PTR ds:0x175b4
   12b6f:	mov    edi,eax
   12b71:	test   edi,edi
   12b73:	jl     0x12b85
   12b75:	call   DWORD PTR ds:0x16020
   12b7b:	add    eax,0x14
   12b7e:	inc    DWORD PTR [eax]
   12b80:	mov    BYTE PTR [esi+0x73],bl
   12b83:	mov    eax,edi
   12b85:	pop    edi
   12b86:	pop    esi
   12b87:	mov    ecx,DWORD PTR [ebp-0x4]
   12b8a:	xor    ecx,ebp
   12b8c:	pop    ebx
   12b8d:	call   0x144c2
   12b92:	leave
   12b93:	ret    0x8
   12b96:	int3
   12b97:	int3
   12b98:	int3
   12b99:	int3
   12b9a:	int3
   12b9b:	int3
   12b9c:	mov    edi,edi
   12b9e:	push   ebp
   12b9f:	mov    ebp,esp
   12ba1:	push   ecx
   12ba2:	push   ecx
   12ba3:	push   ebx
   12ba4:	push   esi
   12ba5:	push   edi
   12ba6:	push   DWORD PTR [ebp+0x8]
   12ba9:	push   DWORD PTR ds:0x1770c
   12baf:	call   DWORD PTR ds:0x1733c
   12bb5:	push   DWORD PTR ds:0x17034
   12bbb:	mov    ecx,DWORD PTR ds:0x1770c
   12bc1:	mov    edx,eax
   12bc3:	call   DWORD PTR ds:0x173f0
   12bc9:	mov    ecx,DWORD PTR [ebp+0x18]
   12bcc:	xor    edi,edi
   12bce:	mov    ebx,eax
   12bd0:	mov    eax,0x1b004c
   12bd5:	mov    DWORD PTR [ebp-0x8],edi
   12bd8:	mov    DWORD PTR [ebp+0x8],edi
   12bdb:	mov    DWORD PTR [ebp-0x4],edi
   12bde:	cmp    ecx,eax
   12be0:	ja     0x12e50
   12be6:	je     0x12e1f
   12bec:	add    eax,0xffffffdc
   12bef:	cmp    ecx,eax
   12bf1:	ja     0x12d57
   12bf7:	je     0x12d4c
   12bfd:	sub    ecx,0x1b0004
   12c03:	je     0x12d1d
   12c09:	push   0x4
   12c0b:	pop    esi
   12c0c:	sub    ecx,esi
   12c0e:	je     0x12cee
   12c14:	sub    ecx,esi
   12c16:	je     0x12cbf
   12c1c:	sub    ecx,0x10
   12c1f:	je     0x12c69
   12c21:	sub    ecx,esi
   12c23:	je     0x12c38
   12c25:	sub    ecx,esi
   12c27:	jne    0x12fd1
   12c2d:	push   ebx
   12c2e:	call   0x14058
   12c33:	jmp    0x130a7
   12c38:	lea    eax,[ebp-0x4]
   12c3b:	push   eax
   12c3c:	lea    eax,[ebp+0x8]
   12c3f:	push   eax
   12c40:	push   0x14
   12c42:	pop    esi
   12c43:	push   esi
   12c44:	push   DWORD PTR [ebp+0xc]
   12c47:	push   DWORD PTR ds:0x1770c
   12c4d:	call   DWORD PTR ds:0x17500
   12c53:	cmp    eax,edi
   12c55:	jne    0x130a7
   12c5b:	push   DWORD PTR [ebp+0x8]
   12c5e:	push   ebx
   12c5f:	call   0x13fd2
   12c64:	jmp    0x130a0
   12c69:	lea    eax,[ebp-0x4]
   12c6c:	push   eax
   12c6d:	lea    eax,[ebp+0x8]
   12c70:	push   eax
   12c71:	push   0x14
   12c73:	push   DWORD PTR [ebp+0xc]
   12c76:	push   DWORD PTR ds:0x1770c
   12c7c:	call   DWORD PTR ds:0x174fc
   12c82:	cmp    eax,edi
   12c84:	jne    0x130a7
   12c8a:	push   DWORD PTR [ebp+0x8]
   12c8d:	push   ebx
   12c8e:	call   0x140ce
   12c93:	cmp    eax,edi
   12c95:	jne    0x130a7
   12c9b:	mov    ecx,DWORD PTR [ebp+0x8]
   12c9e:	cmp    DWORD PTR [ecx],0xffffffff
   12ca1:	jne    0x12cb2
   12ca3:	cmp    DWORD PTR [ecx+0x4],edi
   12ca6:	jne    0x12cb2
   12ca8:	cmp    DWORD PTR [ecx+0x8],edi
   12cab:	jne    0x12cb2
   12cad:	xor    ecx,ecx
   12caf:	inc    ecx
   12cb0:	jmp    0x12cb4
   12cb2:	xor    ecx,ecx
   12cb4:	mov    BYTE PTR [ebx+0x134],cl
   12cba:	jmp    0x130a7
   12cbf:	lea    eax,[ebp-0x4]
   12cc2:	push   eax
   12cc3:	lea    eax,[ebp+0x8]
   12cc6:	push   eax
   12cc7:	push   0x3
   12cc9:	push   DWORD PTR [ebp+0xc]
   12ccc:	push   DWORD PTR ds:0x1770c
   12cd2:	call   DWORD PTR ds:0x174fc
   12cd8:	cmp    eax,edi
   12cda:	jne    0x130a7
   12ce0:	push   DWORD PTR [ebp+0x8]
   12ce3:	push   ebx
   12ce4:	call   0x140a0
   12ce9:	jmp    0x130a7
   12cee:	lea    eax,[ebp-0x4]
   12cf1:	push   eax
   12cf2:	lea    eax,[ebp+0x8]
   12cf5:	push   eax
   12cf6:	push   0x8
   12cf8:	push   DWORD PTR [ebp+0xc]
   12cfb:	push   DWORD PTR ds:0x1770c
   12d01:	call   DWORD PTR ds:0x174fc
   12d07:	cmp    eax,edi
   12d09:	jne    0x130a7
   12d0f:	push   DWORD PTR [ebp+0x8]
   12d12:	push   ebx
   12d13:	call   0x1410c
   12d18:	jmp    0x130a7
   12d1d:	lea    eax,[ebp-0x4]
   12d20:	push   eax
   12d21:	lea    eax,[ebp+0x8]
   12d24:	push   eax
   12d25:	push   0x4
   12d27:	push   DWORD PTR [ebp+0xc]
   12d2a:	push   DWORD PTR ds:0x1770c
   12d30:	call   DWORD PTR ds:0x174fc
   12d36:	cmp    eax,edi
   12d38:	jne    0x130a7
   12d3e:	push   DWORD PTR [ebp+0x8]
   12d41:	push   ebx
   12d42:	call   0x14016
   12d47:	jmp    0x130a7
   12d4c:	push   ebx
   12d4d:	call   0x14324
   12d52:	jmp    0x130a7
   12d57:	sub    ecx,0x1b0030
   12d5d:	je     0x12e14
   12d63:	push   0x4
   12d65:	pop    esi
   12d66:	sub    ecx,esi
   12d68:	je     0x12e09
   12d6e:	sub    ecx,0xc
   12d71:	je     0x12ddb
   12d73:	sub    ecx,esi
   12d75:	je     0x12dad
   12d77:	sub    ecx,esi
   12d79:	jne    0x12fd1
   12d7f:	lea    eax,[ebp-0x4]
   12d82:	push   eax
   12d83:	lea    eax,[ebp+0x8]
   12d86:	push   eax
   12d87:	push   esi
   12d88:	push   DWORD PTR [ebp+0xc]
   12d8b:	push   DWORD PTR ds:0x1770c
   12d91:	call   DWORD PTR ds:0x17500
   12d97:	cmp    eax,edi
   12d99:	jne    0x130a7
   12d9f:	push   DWORD PTR [ebp+0xc]
   12da2:	push   ebx
   12da3:	call   0x143c6
   12da8:	jmp    0x130c1
   12dad:	lea    eax,[ebp-0x4]
   12db0:	push   eax
   12db1:	lea    eax,[ebp+0x8]
   12db4:	push   eax
   12db5:	push   esi
   12db6:	push   DWORD PTR [ebp+0xc]
   12db9:	push   DWORD PTR ds:0x1770c
   12dbf:	call   DWORD PTR ds:0x174fc
   12dc5:	cmp    eax,edi
   12dc7:	jne    0x130a7
   12dcd:	push   DWORD PTR [ebp+0x8]
   12dd0:	push   ebx
   12dd1:	call   0x14368
   12dd6:	jmp    0x130a7
   12ddb:	lea    eax,[ebp-0x4]
   12dde:	push   eax
   12ddf:	lea    eax,[ebp+0x8]
   12de2:	push   eax
   12de3:	push   esi
   12de4:	push   DWORD PTR [ebp+0xc]
   12de7:	push   DWORD PTR ds:0x1770c
   12ded:	call   DWORD PTR ds:0x17500
   12df3:	cmp    eax,edi
   12df5:	jne    0x130a7
   12dfb:	push   DWORD PTR [ebp+0x8]
   12dfe:	push   ebx
   12dff:	call   0x13ff8
   12e04:	jmp    0x130a0
   12e09:	push   ebx
   12e0a:	call   0x140c4
   12e0f:	jmp    0x130a7
   12e14:	push   ebx
   12e15:	call   0x140c4
   12e1a:	jmp    0x130a7
   12e1f:	lea    eax,[ebp-0x4]
   12e22:	push   eax
   12e23:	lea    eax,[ebp+0x8]
   12e26:	push   eax
   12e27:	push   0x4
   12e29:	push   DWORD PTR [ebp+0xc]
   12e2c:	push   DWORD PTR ds:0x1770c
   12e32:	call   DWORD PTR ds:0x174fc
   12e38:	cmp    eax,edi
   12e3a:	jne    0x130a7
   12e40:	mov    eax,DWORD PTR [ebp+0x8]
   12e43:	push   DWORD PTR [eax]
   12e45:	push   ebx
   12e46:	call   0x141ee
   12e4b:	jmp    0x130a7
   12e50:	mov    eax,0x1b0064
   12e55:	cmp    ecx,eax
   12e57:	ja     0x12fac
   12e5d:	je     0x12f7d
   12e63:	sub    ecx,0x1b0050
   12e69:	je     0x12f4c
   12e6f:	push   0x4
   12e71:	pop    esi
   12e72:	sub    ecx,esi
   12e74:	je     0x12f1b
   12e7a:	sub    ecx,esi
   12e7c:	je     0x12eea
   12e7e:	sub    ecx,esi
   12e80:	je     0x12ebb
   12e82:	sub    ecx,esi
   12e84:	jne    0x12fd1
   12e8a:	lea    eax,[ebp-0x4]
   12e8d:	push   eax
   12e8e:	lea    eax,[ebp+0x8]
   12e91:	push   eax
   12e92:	push   0x10
   12e94:	pop    esi
   12e95:	push   esi
   12e96:	push   DWORD PTR [ebp+0xc]
   12e99:	push   DWORD PTR ds:0x1770c
   12e9f:	call   DWORD PTR ds:0x17500
   12ea5:	cmp    eax,edi
   12ea7:	jne    0x130a7
   12ead:	push   DWORD PTR [ebp+0x8]
   12eb0:	push   ebx
   12eb1:	call   0x13edc
   12eb6:	jmp    0x130a0
   12ebb:	lea    eax,[ebp-0x4]
   12ebe:	push   eax
   12ebf:	lea    eax,[ebp+0x8]
   12ec2:	push   eax
   12ec3:	push   0x6
   12ec5:	push   DWORD PTR [ebp+0xc]
   12ec8:	push   DWORD PTR ds:0x1770c
   12ece:	call   DWORD PTR ds:0x174fc
   12ed4:	cmp    eax,edi
   12ed6:	jne    0x130a7
   12edc:	push   DWORD PTR [ebp+0x8]
   12edf:	push   ebx
   12ee0:	call   0x14034
   12ee5:	jmp    0x130a7
   12eea:	lea    eax,[ebp-0x4]
   12eed:	push   eax
   12eee:	lea    eax,[ebp+0x8]
   12ef1:	push   eax
   12ef2:	push   0x6
   12ef4:	pop    esi
   12ef5:	push   esi
   12ef6:	push   DWORD PTR [ebp+0xc]
   12ef9:	push   DWORD PTR ds:0x1770c
   12eff:	call   DWORD PTR ds:0x17500
   12f05:	cmp    eax,edi
   12f07:	jne    0x130a7
   12f0d:	push   DWORD PTR [ebp+0x8]
   12f10:	push   ebx
   12f11:	call   0x13e92
   12f16:	jmp    0x130a0
   12f1b:	lea    eax,[ebp-0x4]
   12f1e:	push   eax
   12f1f:	lea    eax,[ebp+0x8]
   12f22:	push   eax
   12f23:	push   0x3
   12f25:	pop    esi
   12f26:	push   esi
   12f27:	push   DWORD PTR [ebp+0xc]
   12f2a:	push   DWORD PTR ds:0x1770c
   12f30:	call   DWORD PTR ds:0x17500
   12f36:	cmp    eax,edi
   12f38:	jne    0x130a7
   12f3e:	push   DWORD PTR [ebp+0x8]
   12f41:	push   ebx
   12f42:	call   0x13f00
   12f47:	jmp    0x130a0
   12f4c:	lea    eax,[ebp-0x4]
   12f4f:	push   eax
   12f50:	lea    eax,[ebp+0x8]
   12f53:	push   eax
   12f54:	push   0x4
   12f56:	pop    esi
   12f57:	push   esi
   12f58:	push   DWORD PTR [ebp+0xc]
   12f5b:	push   DWORD PTR ds:0x1770c
   12f61:	call   DWORD PTR ds:0x17500
   12f67:	cmp    eax,edi
   12f69:	jne    0x130a7
   12f6f:	push   DWORD PTR [ebp+0x8]
   12f72:	push   ebx
   12f73:	call   0x13e74
   12f78:	jmp    0x130a0
   12f7d:	lea    eax,[ebp-0x4]
   12f80:	push   eax
   12f81:	lea    eax,[ebp+0x8]
   12f84:	push   eax
   12f85:	push   0x10
   12f87:	push   DWORD PTR [ebp+0xc]
   12f8a:	push   DWORD PTR ds:0x1770c
   12f90:	call   DWORD PTR ds:0x174fc
   12f96:	cmp    eax,edi
   12f98:	jne    0x130a7
   12f9e:	push   DWORD PTR [ebp+0x8]
   12fa1:	push   ebx
   12fa2:	call   0x1407c
   12fa7:	jmp    0x130a7
   12fac:	sub    ecx,0x1b0068
   12fb2:	je     0x13078
   12fb8:	push   0x4
   12fba:	pop    esi
   12fbb:	sub    ecx,esi
   12fbd:	je     0x1304e
   12fc3:	sub    ecx,0x8
   12fc6:	je     0x13024
   12fc8:	sub    ecx,0x18
   12fcb:	je     0x12fe6
   12fcd:	sub    ecx,esi
   12fcf:	je     0x12fdb
   12fd1:	mov    eax,0xc00000bb
   12fd6:	jmp    0x130ae
   12fdb:	push   ebx
   12fdc:	call   0x13e54
   12fe1:	jmp    0x130a7
   12fe6:	lea    eax,[ebp-0x4]
   12fe9:	push   eax
   12fea:	lea    eax,[ebp+0x8]
   12fed:	push   eax
   12fee:	push   0x18
   12ff0:	push   DWORD PTR [ebp+0xc]
   12ff3:	push   DWORD PTR ds:0x1770c
   12ff9:	call   DWORD PTR ds:0x17500
   12fff:	cmp    eax,edi
   13001:	jne    0x130a7
   13007:	push   DWORD PTR [ebp+0x8]
   1300a:	push   ebx
   1300b:	call   0x13fac
   13010:	cmp    eax,edi
   13012:	jne    0x130a7
   13018:	mov    DWORD PTR [ebp-0x8],0x18
   1301f:	jmp    0x130a7
   13024:	lea    eax,[ebp-0x4]
   13027:	push   eax
   13028:	lea    eax,[ebp+0x8]
   1302b:	push   eax
   1302c:	push   0x40
   1302e:	pop    esi
   1302f:	push   esi
   13030:	push   DWORD PTR [ebp+0xc]
   13033:	push   DWORD PTR ds:0x1770c
   13039:	call   DWORD PTR ds:0x17500
   1303f:	cmp    eax,edi
   13041:	jne    0x130a7
   13043:	push   DWORD PTR [ebp+0x8]
   13046:	push   ebx
   13047:	call   0x13f42
   1304c:	jmp    0x130a0
   1304e:	lea    eax,[ebp-0x4]
   13051:	push   eax
   13052:	lea    eax,[ebp+0x8]
   13055:	push   eax
   13056:	push   0x14
   13058:	pop    esi
   13059:	push   esi
   1305a:	push   DWORD PTR [ebp+0xc]
   1305d:	push   DWORD PTR ds:0x1770c
   13063:	call   DWORD PTR ds:0x17500
   13069:	cmp    eax,edi
   1306b:	jne    0x130a7
   1306d:	push   DWORD PTR [ebp+0x8]
   13070:	push   ebx
   13071:	call   0x13eb6
   13076:	jmp    0x130a0
   13078:	lea    eax,[ebp-0x4]
   1307b:	push   eax
   1307c:	lea    eax,[ebp+0x8]
   1307f:	push   eax
   13080:	push   0x4
   13082:	pop    esi
   13083:	push   esi
   13084:	push   DWORD PTR [ebp+0xc]
   13087:	push   DWORD PTR ds:0x1770c
   1308d:	call   DWORD PTR ds:0x17500
   13093:	cmp    eax,edi
   13095:	jne    0x130a7
   13097:	push   DWORD PTR [ebp+0x8]
   1309a:	push   ebx
   1309b:	call   0x13f24
   130a0:	cmp    eax,edi
   130a2:	jne    0x130a7
   130a4:	mov    DWORD PTR [ebp-0x8],esi
   130a7:	cmp    eax,0x103
   130ac:	je     0x130c1
   130ae:	push   DWORD PTR [ebp-0x8]
   130b1:	push   eax
   130b2:	push   DWORD PTR [ebp+0xc]
   130b5:	push   DWORD PTR ds:0x1770c
   130bb:	call   DWORD PTR ds:0x174ec
   130c1:	pop    edi
   130c2:	pop    esi
   130c3:	pop    ebx
   130c4:	leave
   130c5:	ret    0x14
   130c8:	int3
   130c9:	int3
   130ca:	int3
   130cb:	int3
   130cc:	int3
   130cd:	int3
   130ce:	mov    edi,edi
   130d0:	push   ebp
   130d1:	mov    ebp,esp
   130d3:	push   DWORD PTR ds:0x1700c
   130d9:	mov    edx,DWORD PTR [ebp+0x8]
   130dc:	mov    ecx,DWORD PTR ds:0x1770c
   130e2:	call   DWORD PTR ds:0x173f0
   130e8:	mov    eax,DWORD PTR [eax]
   130ea:	push   DWORD PTR ds:0x17034
   130f0:	mov    ecx,DWORD PTR ds:0x1770c
   130f6:	mov    edx,eax
   130f8:	call   DWORD PTR ds:0x173f0
   130fe:	mov    ecx,DWORD PTR [eax+0x14]
   13101:	test   ecx,ecx
   13103:	je     0x1311b
   13105:	and    DWORD PTR [eax+0x14],0x0
   13109:	push   0xc0000120
   1310e:	push   ecx
   1310f:	push   DWORD PTR ds:0x1770c
   13115:	call   DWORD PTR ds:0x174e4
   1311b:	pop    ebp
   1311c:	ret    0x4
   1311f:	int3
   13120:	int3
   13121:	int3
   13122:	int3
   13123:	int3
   13124:	mov    edi,edi
   13126:	push   ebp
   13127:	mov    ebp,esp
   13129:	push   esi
   1312a:	push   DWORD PTR [ebp+0x8]
   1312d:	push   DWORD PTR ds:0x1770c
   13133:	call   DWORD PTR ds:0x1733c
   13139:	push   DWORD PTR ds:0x17034
   1313f:	mov    ecx,DWORD PTR ds:0x1770c
   13145:	mov    edx,eax
   13147:	call   DWORD PTR ds:0x173f0
   1314d:	mov    esi,eax
   1314f:	push   DWORD PTR [esi+0x8]
   13152:	push   DWORD PTR [ebp+0xc]
   13155:	push   DWORD PTR ds:0x1770c
   1315b:	call   DWORD PTR ds:0x1752c
   13161:	test   eax,eax
   13163:	je     0x13177
   13165:	push   eax
   13166:	push   DWORD PTR [ebp+0xc]
   13169:	push   DWORD PTR ds:0x1770c
   1316f:	call   DWORD PTR ds:0x174e4
   13175:	jmp    0x13186
   13177:	push   DWORD PTR [esi+0x18]
   1317a:	push   DWORD PTR ds:0x1770c
   13180:	call   DWORD PTR ds:0x17288
   13186:	pop    esi
   13187:	pop    ebp
   13188:	ret    0xc
   1318b:	int3
   1318c:	int3
   1318d:	int3
   1318e:	int3
   1318f:	int3
   13190:	mov    edi,edi
   13192:	push   ebp
   13193:	mov    ebp,esp
   13195:	push   esi
   13196:	push   edi
   13197:	push   DWORD PTR [ebp+0x8]
   1319a:	push   DWORD PTR ds:0x1770c
   131a0:	call   DWORD PTR ds:0x1733c
   131a6:	push   DWORD PTR ds:0x17034
   131ac:	mov    ecx,DWORD PTR ds:0x1770c
   131b2:	mov    edx,eax
   131b4:	call   DWORD PTR ds:0x173f0
   131ba:	mov    edi,DWORD PTR [ebp+0x10]
   131bd:	mov    esi,eax
   131bf:	push   DWORD PTR [esi+0xc]
   131c2:	add    DWORD PTR [esi+0xe4],edi
   131c8:	push   DWORD PTR [ebp+0xc]
   131cb:	push   DWORD PTR ds:0x1770c
   131d1:	call   DWORD PTR ds:0x1752c
   131d7:	test   eax,eax
   131d9:	je     0x131f3
   131db:	push   eax
   131dc:	push   DWORD PTR [ebp+0xc]
   131df:	push   DWORD PTR ds:0x1770c
   131e5:	call   DWORD PTR ds:0x174e4
   131eb:	sub    DWORD PTR [esi+0xe4],edi
   131f1:	jmp    0x13202
   131f3:	push   DWORD PTR [esi+0x1c]
   131f6:	push   DWORD PTR ds:0x1770c
   131fc:	call   DWORD PTR ds:0x17288
   13202:	pop    edi
   13203:	pop    esi
   13204:	pop    ebp
   13205:	ret    0xc
   13208:	int3
   13209:	int3
   1320a:	int3
   1320b:	int3
   1320c:	int3
   1320d:	int3
   1320e:	mov    edi,edi
   13210:	push   ebp
   13211:	mov    ebp,esp
   13213:	push   0x0
   13215:	push   0xc0000120
   1321a:	push   DWORD PTR [ebp+0xc]
   1321d:	push   DWORD PTR ds:0x1770c
   13223:	call   DWORD PTR ds:0x174ec
   13229:	pop    ebp
   1322a:	ret    0x8
   1322d:	int3
   1322e:	int3
   1322f:	int3
   13230:	int3
   13231:	int3
   13232:	mov    edi,edi
   13234:	push   ebp
   13235:	mov    ebp,esp
   13237:	mov    ecx,DWORD PTR ds:0x1770c
   1323d:	push   ebx
   1323e:	push   esi
   1323f:	push   edi
   13240:	mov    edi,DWORD PTR [ebp+0xc]
   13243:	push   DWORD PTR ds:0x1700c
   13249:	mov    edx,edi
   1324b:	call   DWORD PTR ds:0x173f0
   13251:	push   DWORD PTR [ebp+0x8]
   13254:	mov    esi,eax
   13256:	push   DWORD PTR ds:0x1770c
   1325c:	call   DWORD PTR ds:0x1733c
   13262:	push   DWORD PTR ds:0x17034
   13268:	mov    ecx,DWORD PTR ds:0x1770c
   1326e:	mov    edx,eax
   13270:	call   DWORD PTR ds:0x173f0
   13276:	mov    ebx,DWORD PTR [ebp+0x10]
   13279:	test   ebx,0x10000000
   1327f:	je     0x13293
   13281:	cmp    DWORD PTR [esi+0x4],0x0
   13285:	je     0x1328d
   13287:	push   edi
   13288:	call   0x11088
   1328d:	and    ebx,0xefffffff
   13293:	test   bl,0x2
   13296:	je     0x132a7
   13298:	push   edi
   13299:	push   DWORD PTR ds:0x1770c
   1329f:	call   DWORD PTR ds:0x174d0
   132a5:	jmp    0x132bb
   132a7:	test   bl,0x1
   132aa:	je     0x132bb
   132ac:	push   0x0
   132ae:	push   edi
   132af:	push   DWORD PTR ds:0x1770c
   132b5:	call   DWORD PTR ds:0x17538
   132bb:	pop    edi
   132bc:	pop    esi
   132bd:	pop    ebx
   132be:	pop    ebp
   132bf:	ret    0xc
   132c2:	int3
   132c3:	int3
   132c4:	int3
   132c5:	int3
   132c6:	int3
   132c7:	int3
   132c8:	mov    edi,edi
   132ca:	push   ebp
   132cb:	mov    ebp,esp
   132cd:	push   DWORD PTR ds:0x1700c
   132d3:	mov    edx,DWORD PTR [ebp+0xc]
   132d6:	mov    ecx,DWORD PTR ds:0x1770c
   132dc:	call   DWORD PTR ds:0x173f0
   132e2:	mov    eax,DWORD PTR [eax+0x4]
   132e5:	test   eax,eax
   132e7:	je     0x132f2
   132e9:	push   eax
   132ea:	push   DWORD PTR [ebp+0xc]
   132ed:	call   0x1102a
   132f2:	pop    ebp
   132f3:	ret    0x8
   132f6:	int3
   132f7:	int3
   132f8:	int3
   132f9:	int3
   132fa:	int3
   132fb:	int3
   132fc:	mov    edi,edi
   132fe:	push   ebp
   132ff:	mov    ebp,esp
   13301:	mov    ecx,DWORD PTR [ebp+0x8]
   13304:	mov    eax,DWORD PTR [ecx+0x128]
   1330a:	imul   eax,DWORD PTR [ebp+0xc]
   1330e:	add    eax,DWORD PTR [ecx+0x12c]
   13314:	xor    edx,edx
   13316:	pop    ebp
   13317:	ret    0x8
   1331a:	int3
   1331b:	int3
   1331c:	int3
   1331d:	int3
   1331e:	int3
   1331f:	int3
   13320:	mov    edi,edi
   13322:	push   ebp
   13323:	mov    ebp,esp
   13325:	push   ebx
   13326:	push   esi
   13327:	mov    esi,DWORD PTR [ebp+0x8]
   1332a:	push   edi
   1332b:	mov    edi,DWORD PTR [esi+0x90]
   13331:	sub    edi,DWORD PTR [esi+0x94]
   13337:	je     0x13373
   13339:	lea    ebx,[esi+0xb0]
   1333f:	push   ebx
   13340:	call   0x11b9e
   13345:	test   al,al
   13347:	jne    0x13373
   13349:	lea    eax,[ebp+0xb]
   1334c:	push   eax
   1334d:	push   ebx
   1334e:	call   0x125d0
   13353:	mov    dl,BYTE PTR [ebp+0xb]
   13356:	lea    eax,[esi+0x8c]
   1335c:	mov    ecx,DWORD PTR [eax]
   1335e:	mov    BYTE PTR [ecx],dl
   13360:	inc    DWORD PTR [eax]
   13362:	inc    DWORD PTR [esi+0x94]
   13368:	dec    edi
   13369:	dec    DWORD PTR [esi+0xe0]
   1336f:	test   edi,edi
   13371:	ja     0x1333f
   13373:	lea    edi,[esi+0xb0]
   13379:	push   edi
   1337a:	call   0x11bf2
   1337f:	push   edi
   13380:	mov    ebx,eax
   13382:	call   0x11bdc
   13387:	mov    ecx,eax
   13389:	mov    eax,ebx
   1338b:	imul   eax,eax,0x64
   1338e:	xor    edx,edx
   13390:	div    ecx
   13392:	cmp    eax,0x32
   13395:	jae    0x133ac
   13397:	xor    eax,eax
   13399:	lea    ecx,[esi+0xc8]
   1339f:	xchg   DWORD PTR [ecx],eax
   133a1:	cmp    eax,0x1
   133a4:	jne    0x133ac
   133a6:	push   esi
   133a7:	call   0x117b6
   133ac:	mov    eax,DWORD PTR [esi+0x94]
   133b2:	cmp    eax,DWORD PTR [esi+0x90]
   133b8:	pop    edi
   133b9:	sbb    al,al
   133bb:	pop    esi
   133bc:	inc    al
   133be:	pop    ebx
   133bf:	pop    ebp
   133c0:	ret    0x4
   133c3:	int3
   133c4:	int3
   133c5:	int3
   133c6:	int3
   133c7:	int3
   133c8:	mov    edi,edi
   133ca:	push   ebp
   133cb:	mov    ebp,esp
   133cd:	mov    eax,DWORD PTR [ebp+0x8]
   133d0:	sub    esp,0x14
   133d3:	push   esi
   133d4:	push   edi
   133d5:	push   0x5
   133d7:	pop    ecx
   133d8:	lea    esi,[eax+0x11c]
   133de:	lea    edi,[ebp-0x14]
   133e1:	rep movs DWORD PTR es:[edi],DWORD PTR ds:[esi]
   133e3:	cmp    DWORD PTR [ebp-0x14],0xffffffff
   133e7:	pop    edi
   133e8:	pop    esi
   133e9:	jne    0x13411
   133eb:	cmp    DWORD PTR [ebp-0x10],0x0
   133ef:	mov    ecx,DWORD PTR [ebp-0xc]
   133f2:	jne    0x133fc
   133f4:	test   ecx,ecx
   133f6:	jne    0x133fc
   133f8:	mov    al,0x1
   133fa:	jmp    0x13413
   133fc:	cmp    DWORD PTR [ebp-0x10],0xffffffff
   13400:	jne    0x13411
   13402:	dec    ecx
   13403:	cmp    ecx,0xfffffffd
   13406:	ja     0x13411
   13408:	cmp    DWORD PTR [eax+0x94],0x0
   1340f:	ja     0x133f8
   13411:	xor    al,al
   13413:	leave
   13414:	ret    0x4
   13417:	int3
   13418:	int3
   13419:	int3
   1341a:	int3
   1341b:	int3
   1341c:	mov    edi,edi
   1341e:	push   ebp
   1341f:	mov    ebp,esp
   13421:	sub    esp,0x14
   13424:	push   ebx
   13425:	mov    ebx,DWORD PTR [ebp+0x8]
   13428:	mov    eax,DWORD PTR [ebx+0x94]
   1342e:	push   esi
   1342f:	push   edi
   13430:	push   0x5
   13432:	lea    esi,[ebx+0x11c]
   13438:	pop    ecx
   13439:	lea    edi,[ebp-0x14]
   1343c:	rep movs DWORD PTR es:[edi],DWORD PTR ds:[esi]
   1343e:	cmp    DWORD PTR [ebp-0x10],0xffffffff
   13442:	mov    ecx,DWORD PTR [ebp-0x14]
   13445:	mov    edi,DWORD PTR [ebp-0xc]
   13448:	mov    DWORD PTR [ebp+0x8],ecx
   1344b:	je     0x1345a
   1344d:	mov    edi,DWORD PTR [ebx+0x90]
   13453:	imul   edi,DWORD PTR [ebp-0x10]
   13457:	add    edi,DWORD PTR [ebp-0xc]
   1345a:	cmp    ecx,0xffffffff
   1345d:	jne    0x13470
   1345f:	xor    ecx,ecx
   13461:	cmp    DWORD PTR [ebp-0xc],ecx
   13464:	jne    0x13470
   13466:	cmp    DWORD PTR [ebp-0x10],ecx
   13469:	jne    0x13470
   1346b:	mov    DWORD PTR [ebp+0x8],ecx
   1346e:	xor    edi,edi
   13470:	test   eax,eax
   13472:	jne    0x13477
   13474:	and    DWORD PTR [ebp+0x8],eax
   13477:	cmp    DWORD PTR [ebp+0x8],0x0
   1347b:	jne    0x13490
   1347d:	or     DWORD PTR [ebx+0x98],0xffffffff
   13484:	mov    DWORD PTR [ebx+0x9c],0x7fffffff
   1348e:	jmp    0x134ac
   13490:	lea    esi,[ebx+0x98]
   13496:	push   esi
   13497:	call   DWORD PTR ds:0x16028
   1349d:	mov    eax,DWORD PTR [ebp+0x8]
   134a0:	mov    ecx,0x2710
   134a5:	mul    ecx
   134a7:	add    DWORD PTR [esi],eax
   134a9:	adc    DWORD PTR [esi+0x4],edx
   134ac:	test   edi,edi
   134ae:	jne    0x134c3
   134b0:	or     DWORD PTR [ebx+0xa0],0xffffffff
   134b7:	mov    DWORD PTR [ebx+0xa4],0x7fffffff
   134c1:	jmp    0x134de
   134c3:	lea    esi,[ebx+0xa0]
   134c9:	push   esi
   134ca:	call   DWORD PTR ds:0x16028
   134d0:	mov    eax,edi
   134d2:	mov    ecx,0x2710
   134d7:	mul    ecx
   134d9:	add    DWORD PTR [esi],eax
   134db:	adc    DWORD PTR [esi+0x4],edx
   134de:	pop    edi
   134df:	pop    esi
   134e0:	pop    ebx
   134e1:	leave
   134e2:	ret    0x4
   134e5:	int3
   134e6:	int3
   134e7:	int3
   134e8:	int3
   134e9:	int3
   134ea:	mov    edi,edi
   134ec:	push   ebp
   134ed:	mov    ebp,esp
   134ef:	mov    edx,DWORD PTR [ebp+0x8]
   134f2:	mov    ecx,DWORD PTR ds:0x1770c
   134f8:	push   esi
   134f9:	push   DWORD PTR ds:0x1700c
   134ff:	call   DWORD PTR ds:0x173f0
   13505:	mov    eax,DWORD PTR [eax]
   13507:	push   DWORD PTR ds:0x17034
   1350d:	mov    ecx,DWORD PTR ds:0x1770c
   13513:	mov    edx,eax
   13515:	call   DWORD PTR ds:0x173f0
   1351b:	mov    esi,eax
   1351d:	or     DWORD PTR [esi+0x98],0xffffffff
   13524:	or     DWORD PTR [esi+0xa0],0xffffffff
   1352b:	xor    eax,eax
   1352d:	push   0xc0000120
   13532:	push   DWORD PTR [ebp+0x8]
   13535:	mov    DWORD PTR [esi+0x88],eax
   1353b:	mov    DWORD PTR [esi+0x8c],eax
   13541:	mov    DWORD PTR [esi+0x94],eax
   13547:	mov    DWORD PTR [esi+0x90],eax
   1354d:	mov    eax,0x7fffffff
   13552:	mov    DWORD PTR [esi+0x9c],eax
   13558:	mov    DWORD PTR [esi+0xa4],eax
   1355e:	push   DWORD PTR ds:0x1770c
   13564:	call   DWORD PTR ds:0x174e4
   1356a:	push   DWORD PTR [esi+0x18]
   1356d:	push   DWORD PTR ds:0x1770c
   13573:	call   DWORD PTR ds:0x17288
   13579:	pop    esi
   1357a:	pop    ebp
   1357b:	ret    0x4
   1357e:	int3
   1357f:	int3
   13580:	int3
   13581:	int3
   13582:	int3
   13583:	int3
   13584:	mov    edi,edi
   13586:	push   ebp
   13587:	mov    ebp,esp
   13589:	push   esi
   1358a:	push   edi
   1358b:	push   DWORD PTR [ebp+0x8]
   1358e:	push   DWORD PTR ds:0x1770c
   13594:	call   DWORD PTR ds:0x17290
   1359a:	push   DWORD PTR ds:0x17034
   135a0:	mov    ecx,DWORD PTR ds:0x1770c
   135a6:	mov    edx,eax
   135a8:	call   DWORD PTR ds:0x173f0
   135ae:	mov    esi,eax
   135b0:	xor    edi,edi
   135b2:	cmp    DWORD PTR [esi+0x88],edi
   135b8:	je     0x1363e
   135be:	push   esi
   135bf:	call   0x13320
   135c4:	test   al,al
   135c6:	jne    0x135d6
   135c8:	push   esi
   135c9:	call   0x133c8
   135ce:	test   al,al
   135d0:	je     0x136ce
   135d6:	mov    eax,DWORD PTR [esi+0x88]
   135dc:	mov    DWORD PTR [ebp+0x8],eax
   135df:	mov    DWORD PTR [esi+0x88],edi
   135e5:	push   DWORD PTR [ebp+0x8]
   135e8:	push   DWORD PTR ds:0x1770c
   135ee:	call   DWORD PTR ds:0x174c8
   135f4:	cmp    eax,edi
   135f6:	jl     0x13610
   135f8:	push   DWORD PTR [esi+0x94]
   135fe:	push   edi
   135ff:	push   DWORD PTR [ebp+0x8]
   13602:	push   DWORD PTR ds:0x1770c
   13608:	call   DWORD PTR ds:0x174ec
   1360e:	jmp    0x13627
   13610:	cmp    eax,0xc0000120
   13615:	je     0x13627
   13617:	push   eax
   13618:	push   DWORD PTR [ebp+0x8]
   1361b:	push   DWORD PTR ds:0x1770c
   13621:	call   DWORD PTR ds:0x174e4
   13627:	mov    DWORD PTR [esi+0x90],edi
   1362d:	mov    DWORD PTR [esi+0x94],edi
   13633:	mov    DWORD PTR [esi+0x8c],edi
   13639:	jmp    0x135b2
   1363e:	mov    eax,DWORD PTR [esi+0x8]
   13641:	lea    ecx,[ebp+0x8]
   13644:	push   ecx
   13645:	push   eax
   13646:	push   DWORD PTR ds:0x1770c
   1364c:	call   DWORD PTR ds:0x17340
   13652:	test   eax,eax
   13654:	jne    0x136d4
   13656:	lea    eax,[esi+0x90]
   1365c:	push   eax
   1365d:	lea    eax,[esi+0x8c]
   13663:	push   eax
   13664:	push   0x1
   13666:	push   DWORD PTR [ebp+0x8]
   13669:	push   DWORD PTR ds:0x1770c
   1366f:	call   DWORD PTR ds:0x17500
   13675:	cmp    eax,edi
   13677:	je     0x1368e
   13679:	push   eax
   1367a:	push   DWORD PTR [ebp+0x8]
   1367d:	push   DWORD PTR ds:0x1770c
   13683:	call   DWORD PTR ds:0x174e4
   13689:	jmp    0x135b2
   1368e:	push   DWORD PTR ds:0x1700c
   13694:	mov    edx,DWORD PTR [ebp+0x8]
   13697:	mov    ecx,DWORD PTR ds:0x1770c
   1369d:	call   DWORD PTR ds:0x173f0
   136a3:	mov    DWORD PTR [eax],edi
   136a5:	mov    DWORD PTR [eax+0x4],edi
   136a8:	mov    DWORD PTR [eax+0x8],edi
   136ab:	mov    ecx,DWORD PTR [esi]
   136ad:	push   0x134ea
   136b2:	mov    DWORD PTR [eax],ecx
   136b4:	push   DWORD PTR [ebp+0x8]
   136b7:	call   0x1102a
   136bc:	cmp    eax,edi
   136be:	jne    0x13679
   136c0:	mov    eax,DWORD PTR [ebp+0x8]
   136c3:	mov    DWORD PTR [esi+0x88],eax
   136c9:	jmp    0x135b2
   136ce:	push   esi
   136cf:	call   0x1341c
   136d4:	pop    edi
   136d5:	pop    esi
   136d6:	pop    ebp
   136d7:	ret    0x4
   136da:	int3
   136db:	int3
   136dc:	int3
   136dd:	int3
   136de:	int3
   136df:	int3
   136e0:	mov    al,0x1
   136e2:	ret    0xc
   136e5:	int3
   136e6:	int3
   136e7:	int3
   136e8:	int3
   136e9:	int3
   136ea:	mov    edi,edi
   136ec:	push   ebp
   136ed:	mov    ebp,esp
   136ef:	push   ecx
   136f0:	push   ebx
   136f1:	push   esi
   136f2:	mov    esi,DWORD PTR [ebp+0x14]
   136f5:	push   edi
   136f6:	push   DWORD PTR [esi]
   136f8:	xor    ebx,ebx
   136fa:	push   DWORD PTR ds:0x1770c
   13700:	mov    DWORD PTR [ebp-0x4],ebx
   13703:	call   DWORD PTR ds:0x175a0
   13709:	push   ebx
   1370a:	push   DWORD PTR [ebp+0xc]
   1370d:	push   DWORD PTR ds:0x1770c
   13713:	call   DWORD PTR ds:0x173d0
   13719:	mov    edi,eax
   1371b:	mov    DWORD PTR [ebp+0x14],ebx
   1371e:	cmp    DWORD PTR [ebp+0x10],ebx
   13721:	jbe    0x137b4
   13727:	mov    bl,BYTE PTR [edi]
   13729:	mov    BYTE PTR [ebp+0xc],bl
   1372c:	push   DWORD PTR [ebp+0xc]
   1372f:	lea    eax,[esi+0xb0]
   13735:	push   eax
   13736:	call   0x12598
   1373b:	test   eax,eax
   1373d:	je     0x137a8
   1373f:	inc    DWORD PTR [esi+0x104]
   13745:	mov    al,BYTE PTR [esi+0xd3]
   1374b:	inc    DWORD PTR [esi+0xe0]
   13751:	cmp    bl,al
   13753:	jne    0x1375d
   13755:	test   al,al
   13757:	je     0x1375d
   13759:	or     DWORD PTR [ebp-0x4],0x2
   1375d:	mov    ecx,DWORD PTR ds:0x17040
   13763:	movsx  eax,BYTE PTR [ecx]
   13766:	movzx  edx,bl
   13769:	cmp    edx,eax
   1376b:	jne    0x1379a
   1376d:	mov    edx,DWORD PTR [ebp+0x10]
   13770:	sub    edx,DWORD PTR [ebp+0x14]
   13773:	mov    eax,ds:0x1703c
   13778:	cmp    edx,eax
   1377a:	jb     0x1379a
   1377c:	push   eax
   1377d:	push   ecx
   1377e:	push   edi
   1377f:	call   DWORD PTR ds:0x1604c
   13785:	add    esp,0xc
   13788:	test   eax,eax
   1378a:	jne    0x1379a
   1378c:	mov    BYTE PTR [esi+0x137],0x1
   13793:	mov    BYTE PTR [esi+0x138],0x1
   1379a:	inc    DWORD PTR [ebp+0x14]
   1379d:	mov    eax,DWORD PTR [ebp+0x14]
   137a0:	inc    edi
   137a1:	cmp    eax,DWORD PTR [ebp+0x10]
   137a4:	jb     0x13727
   137a6:	jmp    0x137b4
   137a8:	mov    eax,DWORD PTR [ebp+0x10]
   137ab:	sub    eax,DWORD PTR [ebp+0x14]
   137ae:	add    DWORD PTR [esi+0x114],eax
   137b4:	lea    edi,[esi+0xb0]
   137ba:	push   edi
   137bb:	call   0x11bf2
   137c0:	push   edi
   137c1:	mov    ebx,eax
   137c3:	call   0x11bdc
   137c8:	mov    ecx,eax
   137ca:	mov    eax,ebx
   137cc:	imul   eax,eax,0x64
   137cf:	xor    edx,edx
   137d1:	div    ecx
   137d3:	cmp    eax,0x50
   137d6:	jb     0x137df
   137d8:	or     DWORD PTR [ebp-0x4],0x400
   137df:	cmp    DWORD PTR [ebp+0x10],0x0
   137e3:	jbe    0x137e9
   137e5:	or     DWORD PTR [ebp-0x4],0x1
   137e9:	push   DWORD PTR [ebp-0x4]
   137ec:	push   esi
   137ed:	call   0x141a0
   137f2:	push   DWORD PTR [esi]
   137f4:	push   DWORD PTR ds:0x1770c
   137fa:	call   DWORD PTR ds:0x175a4
   13800:	push   DWORD PTR [esi+0x18]
   13803:	push   DWORD PTR ds:0x1770c
   13809:	call   DWORD PTR ds:0x17288
   1380f:	pop    edi
   13810:	pop    esi
   13811:	pop    ebx
   13812:	leave
   13813:	ret    0x10
   13816:	int3
   13817:	int3
   13818:	int3
   13819:	int3
   1381a:	int3
   1381b:	int3
   1381c:	mov    edi,edi
   1381e:	push   ebp
   1381f:	mov    ebp,esp
   13821:	push   ebx
   13822:	push   esi
   13823:	mov    esi,DWORD PTR [ebp+0x14]
   13826:	mov    ebx,DWORD PTR [esi+0xac]
   1382c:	push   edi
   1382d:	mov    edi,DWORD PTR [ebp+0x10]
   13830:	cmp    DWORD PTR [edi+0x8],0x0
   13834:	mov    eax,DWORD PTR [edi+0xc]
   13837:	jne    0x13841
   13839:	add    DWORD PTR [esi+0x108],eax
   1383f:	jmp    0x13847
   13841:	add    DWORD PTR [esi+0x110],eax
   13847:	mov    eax,DWORD PTR [esi+0x78]
   1384a:	cmp    DWORD PTR [ebp+0x8],eax
   1384d:	jne    0x138a0
   1384f:	push   eax
   13850:	push   DWORD PTR ds:0x1770c
   13856:	call   DWORD PTR ds:0x17408
   1385c:	and    DWORD PTR [esi+0x78],0x0
   13860:	test   ebx,ebx
   13862:	je     0x13897
   13864:	push   DWORD PTR ds:0x1700c
   1386a:	mov    ecx,DWORD PTR ds:0x1770c
   13870:	mov    edx,ebx
   13872:	call   DWORD PTR ds:0x173f0
   13878:	test   eax,eax
   1387a:	je     0x13884
   1387c:	push   DWORD PTR [eax+0xc]
   1387f:	push   DWORD PTR [eax+0x10]
   13882:	jmp    0x1388a
   13884:	push   DWORD PTR [edi+0xc]
   13887:	push   DWORD PTR [edi+0x8]
   1388a:	push   ebx
   1388b:	push   DWORD PTR ds:0x1770c
   13891:	call   DWORD PTR ds:0x174ec
   13897:	and    DWORD PTR [esi+0xac],0x0
   1389e:	jmp    0x138f2
   138a0:	cmp    BYTE PTR [esi+0x74],0x0
   138a4:	je     0x138d6
   138a6:	test   ebx,ebx
   138a8:	je     0x138ce
   138aa:	push   DWORD PTR ds:0x1700c
   138b0:	mov    ecx,DWORD PTR ds:0x1770c
   138b6:	mov    edx,ebx
   138b8:	call   DWORD PTR ds:0x173f0
   138be:	test   eax,eax
   138c0:	je     0x138ce
   138c2:	mov    ecx,DWORD PTR [edi+0x8]
   138c5:	mov    DWORD PTR [eax+0x10],ecx
   138c8:	mov    ecx,DWORD PTR [edi+0xc]
   138cb:	mov    DWORD PTR [eax+0xc],ecx
   138ce:	push   esi
   138cf:	call   0x13b10
   138d4:	jmp    0x1390b
   138d6:	and    DWORD PTR [esi+0xac],0x0
   138dd:	push   DWORD PTR [edi+0xc]
   138e0:	push   DWORD PTR [edi+0x8]
   138e3:	push   DWORD PTR [ebp+0x8]
   138e6:	push   DWORD PTR ds:0x1770c
   138ec:	call   DWORD PTR ds:0x174ec
   138f2:	lea    ecx,[esi+0x84]
   138f8:	xor    eax,eax
   138fa:	xchg   DWORD PTR [ecx],eax
   138fc:	push   DWORD PTR [esi+0x1c]
   138ff:	push   DWORD PTR ds:0x1770c
   13905:	call   DWORD PTR ds:0x17288
   1390b:	pop    edi
   1390c:	pop    esi
   1390d:	pop    ebx
   1390e:	pop    ebp
   1390f:	ret    0x10
   13912:	int3
   13913:	int3
   13914:	int3
   13915:	int3
   13916:	int3
   13917:	int3
   13918:	ret    0x4
   1391b:	int3
   1391c:	int3
   1391d:	int3
   1391e:	int3
   1391f:	int3
   13920:	mov    edi,edi
   13922:	push   ebp
   13923:	mov    ebp,esp
   13925:	push   ecx
   13926:	push   ecx
   13927:	push   esi
   13928:	mov    esi,DWORD PTR [ebp+0x8]
   1392b:	cmp    DWORD PTR [esi+0x88],0x0
   13932:	je     0x139dd
   13938:	lea    eax,[ebp-0x8]
   1393b:	push   eax
   1393c:	call   DWORD PTR ds:0x16028
   13942:	mov    eax,DWORD PTR [esi+0x9c]
   13948:	cmp    eax,DWORD PTR [ebp-0x4]
   1394b:	jl     0x13972
   1394d:	jg     0x1395a
   1394f:	mov    eax,DWORD PTR [esi+0x98]
   13955:	cmp    eax,DWORD PTR [ebp-0x8]
   13958:	jb     0x13972
   1395a:	mov    eax,DWORD PTR [esi+0xa4]
   13960:	cmp    eax,DWORD PTR [ebp-0x4]
   13963:	jg     0x139dd
   13965:	jl     0x13972
   13967:	mov    eax,DWORD PTR [esi+0xa0]
   1396d:	cmp    eax,DWORD PTR [ebp-0x8]
   13970:	jae    0x139dd
   13972:	push   ebx
   13973:	push   edi
   13974:	mov    edi,DWORD PTR [esi+0x88]
   1397a:	xor    ecx,ecx
   1397c:	lea    eax,[esi+0x94]
   13982:	mov    ebx,DWORD PTR [eax]
   13984:	push   edi
   13985:	mov    DWORD PTR [esi+0x88],ecx
   1398b:	mov    DWORD PTR [esi+0x8c],ecx
   13991:	mov    DWORD PTR [esi+0x90],ecx
   13997:	mov    DWORD PTR [eax],ecx
   13999:	push   DWORD PTR ds:0x1770c
   1399f:	call   DWORD PTR ds:0x174c8
   139a5:	test   eax,eax
   139a7:	je     0x139b9
   139a9:	push   eax
   139aa:	push   edi
   139ab:	push   DWORD PTR ds:0x1770c
   139b1:	call   DWORD PTR ds:0x174e4
   139b7:	jmp    0x139cc
   139b9:	push   ebx
   139ba:	push   0x102
   139bf:	push   edi
   139c0:	push   DWORD PTR ds:0x1770c
   139c6:	call   DWORD PTR ds:0x174ec
   139cc:	push   DWORD PTR [esi+0x18]
   139cf:	push   DWORD PTR ds:0x1770c
   139d5:	call   DWORD PTR ds:0x17288
   139db:	pop    edi
   139dc:	pop    ebx
   139dd:	pop    esi
   139de:	leave
   139df:	ret    0x4
   139e2:	int3
   139e3:	int3
   139e4:	int3
   139e5:	int3
   139e6:	int3
   139e7:	int3
   139e8:	mov    edi,edi
   139ea:	push   ebp
   139eb:	mov    ebp,esp
   139ed:	mov    edx,DWORD PTR [ebp+0x8]
   139f0:	mov    ecx,DWORD PTR ds:0x1770c
   139f6:	sub    esp,0x10
   139f9:	push   ebx
   139fa:	push   esi
   139fb:	push   edi
   139fc:	push   DWORD PTR ds:0x17020
   13a02:	call   DWORD PTR ds:0x173f0
   13a08:	push   DWORD PTR ds:0x17034
   13a0e:	mov    ecx,DWORD PTR ds:0x1770c
   13a14:	mov    ebx,eax
   13a16:	mov    edx,DWORD PTR [ebx]
   13a18:	call   DWORD PTR ds:0x173f0
   13a1e:	mov    esi,eax
   13a20:	mov    eax,DWORD PTR [ebp+0x10]
   13a23:	cmp    DWORD PTR [eax+0x8],0x0
   13a27:	jne    0x13aeb
   13a2d:	push   esi
   13a2e:	push   DWORD PTR [eax+0xc]
   13a31:	push   DWORD PTR [ebx+0x4]
   13a34:	push   DWORD PTR [esi+0x44]
   13a37:	call   0x136ea
   13a3c:	lea    edi,[esi+0xb0]
   13a42:	push   edi
   13a43:	call   0x11bf2
   13a48:	push   edi
   13a49:	mov    DWORD PTR [ebp+0x10],eax
   13a4c:	call   0x11bdc
   13a51:	mov    ecx,eax
   13a53:	mov    eax,DWORD PTR [ebp+0x10]
   13a56:	imul   eax,eax,0x64
   13a59:	xor    edx,edx
   13a5b:	div    ecx
   13a5d:	cmp    eax,0x32
   13a60:	jae    0x13aeb
   13a66:	xor    eax,eax
   13a68:	lea    edi,[ebp-0x10]
   13a6b:	stos   DWORD PTR es:[edi],eax
   13a6c:	stos   DWORD PTR es:[edi],eax
   13a6d:	stos   DWORD PTR es:[edi],eax
   13a6e:	stos   DWORD PTR es:[edi],eax
   13a6f:	and    DWORD PTR [ebp-0xc],0x0
   13a73:	and    DWORD PTR [ebp-0x8],0x0
   13a77:	lea    eax,[ebp-0x10]
   13a7a:	push   eax
   13a7b:	push   DWORD PTR [ebp+0x8]
   13a7e:	mov    DWORD PTR [ebp-0x10],0x10
   13a85:	push   DWORD PTR ds:0x1770c
   13a8b:	call   DWORD PTR ds:0x174ac
   13a91:	test   eax,eax
   13a93:	jne    0x13aeb
   13a95:	mov    eax,DWORD PTR [ebx+0x4]
   13a98:	mov    ecx,DWORD PTR [esi+0x5c]
   13a9b:	mov    edx,DWORD PTR [esi+0x44]
   13a9e:	push   0x0
   13aa0:	push   eax
   13aa1:	push   ecx
   13aa2:	push   edx
   13aa3:	push   DWORD PTR ds:0x1770c
   13aa9:	call   DWORD PTR ds:0x1763c
   13aaf:	test   eax,eax
   13ab1:	jne    0x13aeb
   13ab3:	push   ebx
   13ab4:	push   0x139e8
   13ab9:	push   DWORD PTR [esi+0x5c]
   13abc:	push   DWORD PTR ds:0x1770c
   13ac2:	call   DWORD PTR ds:0x174d8
   13ac8:	cmp    DWORD PTR [esi+0x80],0x0
   13acf:	jle    0x13aeb
   13ad1:	mov    eax,DWORD PTR [esi+0x44]
   13ad4:	mov    ecx,DWORD PTR [esi+0x5c]
   13ad7:	push   0x0
   13ad9:	push   eax
   13ada:	push   ecx
   13adb:	push   DWORD PTR ds:0x1770c
   13ae1:	call   DWORD PTR ds:0x174bc
   13ae7:	test   al,al
   13ae9:	jne    0x13b04
   13aeb:	push   0x0
   13aed:	push   0x0
   13aef:	lea    eax,[esi+0x60]
   13af2:	push   eax
   13af3:	call   DWORD PTR ds:0x16014
   13af9:	xor    eax,eax
   13afb:	inc    eax
   13afc:	add    esi,0xc8
   13b02:	xchg   DWORD PTR [esi],eax
   13b04:	pop    edi
   13b05:	pop    esi
   13b06:	pop    ebx
   13b07:	leave
   13b08:	ret    0x10
   13b0b:	int3
   13b0c:	int3
   13b0d:	int3
   13b0e:	int3
   13b0f:	int3
   13b10:	mov    edi,edi
   13b12:	push   ebp
   13b13:	mov    ebp,esp
   13b15:	sub    esp,0x2c
   13b18:	push   ebx
   13b19:	push   esi
   13b1a:	mov    esi,DWORD PTR [ebp+0x8]
   13b1d:	xor    ebx,ebx
   13b1f:	mov    DWORD PTR [ebp-0x8],ebx
   13b22:	cmp    esi,ebx
   13b24:	je     0x13c5b
   13b2a:	lea    eax,[ebp-0x4]
   13b2d:	push   eax
   13b2e:	push   ebx
   13b2f:	push   ebx
   13b30:	mov    BYTE PTR [esi+0x74],bl
   13b33:	push   DWORD PTR ds:0x1770c
   13b39:	call   DWORD PTR ds:0x174a4
   13b3f:	test   eax,eax
   13b41:	jl     0x13c5b
   13b47:	mov    eax,DWORD PTR [esi+0x40]
   13b4a:	mov    edx,DWORD PTR [ebp-0x4]
   13b4d:	push   edi
   13b4e:	push   0x8
   13b50:	pop    ecx
   13b51:	mov    DWORD PTR [ebp-0xc],eax
   13b54:	xor    eax,eax
   13b56:	lea    edi,[ebp-0x2c]
   13b59:	rep stos DWORD PTR es:[edi],eax
   13b5b:	inc    eax
   13b5c:	push   ebx
   13b5d:	mov    DWORD PTR [ebp-0x20],eax
   13b60:	mov    DWORD PTR [ebp-0x1c],eax
   13b63:	lea    eax,[ebp-0x8]
   13b66:	push   eax
   13b67:	push   0x48
   13b69:	push   ebx
   13b6a:	push   ebx
   13b6b:	lea    eax,[ebp-0x2c]
   13b6e:	push   eax
   13b6f:	mov    DWORD PTR [esi+0x78],edx
   13b72:	push   DWORD PTR ds:0x1770c
   13b78:	mov    DWORD PTR [ebp-0x2c],0x20
   13b7f:	mov    DWORD PTR [ebp-0x18],edx
   13b82:	call   DWORD PTR ds:0x173c8
   13b88:	mov    edi,eax
   13b8a:	cmp    edi,ebx
   13b8c:	jl     0x13c48
   13b92:	push   ebx
   13b93:	push   DWORD PTR [ebp-0x8]
   13b96:	push   DWORD PTR ds:0x1770c
   13b9c:	call   DWORD PTR ds:0x173d0
   13ba2:	mov    esi,eax
   13ba4:	cmp    esi,ebx
   13ba6:	je     0x13c41
   13bac:	push   0x48
   13bae:	push   ebx
   13baf:	push   esi
   13bb0:	call   0x1450e
   13bb5:	add    esp,0xc
   13bb8:	push   0x48
   13bba:	pop    eax
   13bbb:	push   0x9
   13bbd:	mov    WORD PTR [esi],ax
   13bc0:	pop    eax
   13bc1:	push   DWORD PTR [ebp-0xc]
   13bc4:	mov    WORD PTR [esi+0x2],ax
   13bc8:	push   DWORD PTR ds:0x1770c
   13bce:	call   DWORD PTR ds:0x17680
   13bd4:	push   ebx
   13bd5:	mov    DWORD PTR [esi+0x10],eax
   13bd8:	mov    DWORD PTR [esi+0x1c],ebx
   13bdb:	mov    DWORD PTR [esi+0x20],ebx
   13bde:	mov    DWORD PTR [esi+0x18],ebx
   13be1:	mov    DWORD PTR [esi+0x14],ebx
   13be4:	mov    DWORD PTR [esi+0x24],ebx
   13be7:	push   DWORD PTR [ebp-0x8]
   13bea:	push   DWORD PTR [ebp-0x4]
   13bed:	push   DWORD PTR [ebp-0xc]
   13bf0:	push   DWORD PTR ds:0x1770c
   13bf6:	call   DWORD PTR ds:0x17658
   13bfc:	mov    edi,eax
   13bfe:	cmp    edi,ebx
   13c00:	jl     0x13c45
   13c02:	push   DWORD PTR [ebp+0x8]
   13c05:	push   0x1381c
   13c0a:	push   DWORD PTR [ebp-0x4]
   13c0d:	push   DWORD PTR ds:0x1770c
   13c13:	call   DWORD PTR ds:0x174d8
   13c19:	push   ebx
   13c1a:	push   DWORD PTR [ebp-0xc]
   13c1d:	push   DWORD PTR [ebp-0x4]
   13c20:	push   DWORD PTR ds:0x1770c
   13c26:	call   DWORD PTR ds:0x174bc
   13c2c:	test   al,al
   13c2e:	jne    0x13c41
   13c30:	push   DWORD PTR [ebp-0x4]
   13c33:	push   DWORD PTR ds:0x1770c
   13c39:	call   DWORD PTR ds:0x174c0
   13c3f:	mov    edi,eax
   13c41:	cmp    edi,ebx
   13c43:	jge    0x13c5a
   13c45:	mov    esi,DWORD PTR [ebp+0x8]
   13c48:	push   DWORD PTR [esi+0x78]
   13c4b:	push   DWORD PTR ds:0x1770c
   13c51:	call   DWORD PTR ds:0x17408
   13c57:	mov    DWORD PTR [esi+0x78],ebx
   13c5a:	pop    edi
   13c5b:	pop    esi
   13c5c:	pop    ebx
   13c5d:	leave
   13c5e:	ret    0x4
   13c61:	int3
   13c62:	int3
   13c63:	int3
   13c64:	int3
   13c65:	int3
   13c66:	mov    edi,edi
   13c68:	push   ebp
   13c69:	mov    ebp,esp
   13c6b:	sub    esp,0x2c
   13c6e:	push   esi
   13c6f:	push   edi
   13c70:	push   DWORD PTR [ebp+0x8]
   13c73:	push   DWORD PTR ds:0x1770c
   13c79:	call   DWORD PTR ds:0x17290
   13c7f:	push   DWORD PTR ds:0x17034
   13c85:	mov    ecx,DWORD PTR ds:0x1770c
   13c8b:	mov    edx,eax
   13c8d:	call   DWORD PTR ds:0x173f0
   13c93:	mov    esi,eax
   13c95:	xor    eax,eax
   13c97:	lea    edi,[ebp-0x2c]
   13c9a:	stos   DWORD PTR es:[edi],eax
   13c9b:	stos   DWORD PTR es:[edi],eax
   13c9c:	stos   DWORD PTR es:[edi],eax
   13c9d:	stos   DWORD PTR es:[edi],eax
   13c9e:	stos   DWORD PTR es:[edi],eax
   13c9f:	lea    eax,[ebp-0x2c]
   13ca2:	push   eax
   13ca3:	mov    DWORD PTR [ebp-0x2c],0x14
   13caa:	push   DWORD PTR [esi+0x40]
   13cad:	push   DWORD PTR ds:0x1770c
   13cb3:	call   DWORD PTR ds:0x1761c
   13cb9:	xor    ecx,ecx
   13cbb:	lea    eax,[esi+0x84]
   13cc1:	inc    ecx
   13cc2:	xchg   DWORD PTR [eax],ecx
   13cc4:	test   ecx,ecx
   13cc6:	jne    0x13e49
   13ccc:	mov    eax,DWORD PTR [esi+0xc]
   13ccf:	push   ebx
   13cd0:	lea    ecx,[ebp+0x8]
   13cd3:	push   ecx
   13cd4:	push   eax
   13cd5:	push   DWORD PTR ds:0x1770c
   13cdb:	call   DWORD PTR ds:0x17340
   13ce1:	test   eax,eax
   13ce3:	jne    0x13e36
   13ce9:	xor    ebx,ebx
   13ceb:	lea    eax,[ebp-0x8]
   13cee:	push   eax
   13cef:	push   DWORD PTR [ebp+0x8]
   13cf2:	push   DWORD PTR ds:0x1770c
   13cf8:	call   DWORD PTR ds:0x174f4
   13cfe:	cmp    eax,ebx
   13d00:	jne    0x13e0a
   13d06:	lea    eax,[ebp-0x4]
   13d09:	push   eax
   13d0a:	push   DWORD PTR [ebp-0x8]
   13d0d:	push   DWORD PTR ds:0x1770c
   13d13:	call   DWORD PTR ds:0x173d0
   13d19:	mov    ecx,DWORD PTR [ebp-0x4]
   13d1c:	sub    DWORD PTR [esi+0xe4],ecx
   13d22:	cmp    eax,ebx
   13d24:	jne    0x13d30
   13d26:	push   0xc000000d
   13d2b:	jmp    0x13e0b
   13d30:	mov    eax,DWORD PTR [ebp-0x4]
   13d33:	cmp    eax,ebx
   13d35:	jne    0x13d3d
   13d37:	push   ebx
   13d38:	jmp    0x13e0b
   13d3d:	cmp    BYTE PTR [esi+0x14b],bl
   13d43:	je     0x13d5c
   13d45:	cmp    DWORD PTR [ebp-0x28],ebx
   13d48:	je     0x13d59
   13d4a:	xor    edx,edx
   13d4c:	div    DWORD PTR [ebp-0x28]
   13d4f:	test   edx,edx
   13d51:	jne    0x13d59
   13d53:	mov    BYTE PTR [esi+0x74],0x1
   13d57:	jmp    0x13d5c
   13d59:	mov    BYTE PTR [esi+0x74],bl
   13d5c:	mov    eax,DWORD PTR [esi+0x40]
   13d5f:	push   ebx
   13d60:	push   DWORD PTR [ebp-0x8]
   13d63:	push   DWORD PTR [ebp+0x8]
   13d66:	push   eax
   13d67:	push   DWORD PTR ds:0x1770c
   13d6d:	call   DWORD PTR ds:0x17634
   13d73:	cmp    eax,ebx
   13d75:	je     0x13d7f
   13d77:	mov    BYTE PTR [esi+0x74],bl
   13d7a:	jmp    0x13e0a
   13d7f:	mov    eax,DWORD PTR [ebp+0x8]
   13d82:	push   esi
   13d83:	push   0x1381c
   13d88:	mov    DWORD PTR [esi+0xac],eax
   13d8e:	push   DWORD PTR [ebp+0x8]
   13d91:	push   DWORD PTR ds:0x1770c
   13d97:	call   DWORD PTR ds:0x174d8
   13d9d:	push   DWORD PTR [ebp-0x4]
   13da0:	push   esi
   13da1:	call   0x132fc
   13da6:	mov    ecx,eax
   13da8:	or     eax,edx
   13daa:	je     0x13dda
   13dac:	xor    eax,eax
   13dae:	lea    edi,[ebp-0x18]
   13db1:	stos   DWORD PTR es:[edi],eax
   13db2:	stos   DWORD PTR es:[edi],eax
   13db3:	push   0xffffffff
   13db5:	stos   DWORD PTR es:[edi],eax
   13db6:	push   0xffffd8f0
   13dbb:	push   edx
   13dbc:	stos   DWORD PTR es:[edi],eax
   13dbd:	push   ecx
   13dbe:	mov    DWORD PTR [ebp-0x18],0x10
   13dc5:	mov    DWORD PTR [ebp-0x14],0x1
   13dcc:	call   0x14502
   13dd1:	mov    DWORD PTR [ebp-0x10],eax
   13dd4:	mov    DWORD PTR [ebp-0xc],edx
   13dd7:	lea    eax,[ebp-0x18]
   13dda:	mov    ecx,DWORD PTR [esi+0x40]
   13ddd:	push   eax
   13dde:	push   ecx
   13ddf:	push   DWORD PTR [ebp+0x8]
   13de2:	push   DWORD PTR ds:0x1770c
   13de8:	call   DWORD PTR ds:0x174bc
   13dee:	test   al,al
   13df0:	jne    0x13e48
   13df2:	mov    BYTE PTR [esi+0x74],bl
   13df5:	mov    DWORD PTR [esi+0xac],ebx
   13dfb:	push   DWORD PTR [ebp+0x8]
   13dfe:	push   DWORD PTR ds:0x1770c
   13e04:	call   DWORD PTR ds:0x174c0
   13e0a:	push   eax
   13e0b:	push   DWORD PTR [ebp+0x8]
   13e0e:	push   DWORD PTR ds:0x1770c
   13e14:	call   DWORD PTR ds:0x174e4
   13e1a:	mov    eax,DWORD PTR [esi+0xc]
   13e1d:	lea    ecx,[ebp+0x8]
   13e20:	push   ecx
   13e21:	push   eax
   13e22:	push   DWORD PTR ds:0x1770c
   13e28:	call   DWORD PTR ds:0x17340
   13e2e:	test   eax,eax
   13e30:	je     0x13ceb
   13e36:	xor    ecx,ecx
   13e38:	lea    eax,[esi+0x84]
   13e3e:	xchg   DWORD PTR [eax],ecx
   13e40:	push   0x4
   13e42:	push   esi
   13e43:	call   0x141a0
   13e48:	pop    ebx
   13e49:	pop    edi
   13e4a:	pop    esi
   13e4b:	leave
   13e4c:	ret    0x4
   13e4f:	int3
   13e50:	int3
   13e51:	int3
   13e52:	int3
   13e53:	int3
   13e54:	mov    edi,edi
   13e56:	push   ebp
   13e57:	mov    ebp,esp
   13e59:	push   edi
   13e5a:	mov    edi,DWORD PTR [ebp+0x8]
   13e5d:	push   0x6
   13e5f:	xor    eax,eax
   13e61:	pop    ecx
   13e62:	add    edi,0x104
   13e68:	rep stos DWORD PTR es:[edi],eax
   13e6a:	pop    edi
   13e6b:	pop    ebp
   13e6c:	ret    0x4
   13e6f:	int3
   13e70:	int3
   13e71:	int3
   13e72:	int3
   13e73:	int3
   13e74:	mov    edi,edi
   13e76:	push   ebp
   13e77:	mov    ebp,esp
   13e79:	mov    eax,DWORD PTR [ebp+0x8]
   13e7c:	mov    eax,DWORD PTR [eax+0xcc]
   13e82:	mov    ecx,DWORD PTR [ebp+0xc]
   13e85:	mov    DWORD PTR [ecx],eax
   13e87:	xor    eax,eax
   13e89:	pop    ebp
   13e8a:	ret    0x8
   13e8d:	int3
   13e8e:	int3
   13e8f:	int3
   13e90:	int3
   13e91:	int3
   13e92:	mov    edi,edi
   13e94:	push   ebp
   13e95:	mov    ebp,esp
   13e97:	push   esi
   13e98:	mov    esi,DWORD PTR [ebp+0x8]
   13e9b:	push   edi
   13e9c:	mov    edi,DWORD PTR [ebp+0xc]
   13e9f:	add    esi,0xd0
   13ea5:	movs   DWORD PTR es:[edi],DWORD PTR ds:[esi]
   13ea6:	movs   WORD PTR es:[edi],WORD PTR ds:[esi]
   13ea8:	pop    edi
   13ea9:	xor    eax,eax
   13eab:	pop    esi
   13eac:	pop    ebp
   13ead:	ret    0x8
   13eb0:	int3
   13eb1:	int3
   13eb2:	int3
   13eb3:	int3
   13eb4:	int3
   13eb5:	int3
   13eb6:	mov    edi,edi
   13eb8:	push   ebp
   13eb9:	mov    ebp,esp
   13ebb:	push   esi
   13ebc:	mov    esi,DWORD PTR [ebp+0x8]
   13ebf:	push   edi
   13ec0:	mov    edi,DWORD PTR [ebp+0xc]
   13ec3:	push   0x5
   13ec5:	add    esi,0xd8
   13ecb:	pop    ecx
   13ecc:	rep movs DWORD PTR es:[edi],DWORD PTR ds:[esi]
   13ece:	pop    edi
   13ecf:	xor    eax,eax
   13ed1:	pop    esi
   13ed2:	pop    ebp
   13ed3:	ret    0x8
   13ed6:	int3
   13ed7:	int3
   13ed8:	int3
   13ed9:	int3
   13eda:	int3
   13edb:	int3
   13edc:	mov    edi,edi
   13ede:	push   ebp
   13edf:	mov    ebp,esp
   13ee1:	push   esi
   13ee2:	mov    esi,DWORD PTR [ebp+0x8]
   13ee5:	push   edi
   13ee6:	mov    edi,DWORD PTR [ebp+0xc]
   13ee9:	add    esi,0xec
   13eef:	movs   DWORD PTR es:[edi],DWORD PTR ds:[esi]
   13ef0:	movs   DWORD PTR es:[edi],DWORD PTR ds:[esi]
   13ef1:	movs   DWORD PTR es:[edi],DWORD PTR ds:[esi]
   13ef2:	movs   DWORD PTR es:[edi],DWORD PTR ds:[esi]
   13ef3:	pop    edi
   13ef4:	xor    eax,eax
   13ef6:	pop    esi
   13ef7:	pop    ebp
   13ef8:	ret    0x8
   13efb:	int3
   13efc:	int3
   13efd:	int3
   13efe:	int3
   13eff:	int3
   13f00:	mov    edi,edi
   13f02:	push   ebp
   13f03:	mov    ebp,esp
   13f05:	push   esi
   13f06:	mov    esi,DWORD PTR [ebp+0x8]
   13f09:	push   edi
   13f0a:	mov    edi,DWORD PTR [ebp+0xc]
   13f0d:	add    esi,0xfc
   13f13:	movs   WORD PTR es:[edi],WORD PTR ds:[esi]
   13f15:	movs   BYTE PTR es:[edi],BYTE PTR ds:[esi]
   13f16:	pop    edi
   13f17:	xor    eax,eax
   13f19:	pop    esi
   13f1a:	pop    ebp
   13f1b:	ret    0x8
   13f1e:	int3
   13f1f:	int3
   13f20:	int3
   13f21:	int3
   13f22:	int3
   13f23:	int3
   13f24:	mov    edi,edi
   13f26:	push   ebp
   13f27:	mov    ebp,esp
   13f29:	mov    eax,DWORD PTR [ebp+0x8]
   13f2c:	mov    eax,DWORD PTR [eax+0x100]
   13f32:	mov    ecx,DWORD PTR [ebp+0xc]
   13f35:	mov    DWORD PTR [ecx],eax
   13f37:	xor    eax,eax
   13f39:	pop    ebp
   13f3a:	ret    0x8
   13f3d:	int3
   13f3e:	int3
   13f3f:	int3
   13f40:	int3
   13f41:	int3
   13f42:	mov    edi,edi
   13f44:	push   ebp
   13f45:	mov    ebp,esp
   13f47:	push   ebx
   13f48:	push   esi
   13f49:	mov    esi,DWORD PTR [ebp+0xc]
   13f4c:	push   0x40
   13f4e:	push   0x0
   13f50:	push   esi
   13f51:	call   0x1450e
   13f56:	and    DWORD PTR [esi+0xc],0x0
   13f5a:	add    esp,0xc
   13f5d:	push   0x40
   13f5f:	pop    eax
   13f60:	mov    WORD PTR [esi],ax
   13f63:	push   0x2
   13f65:	pop    edx
   13f66:	mov    eax,edx
   13f68:	mov    WORD PTR [esi+0x2],ax
   13f6c:	mov    eax,DWORD PTR [ebp+0x8]
   13f6f:	xor    ecx,ecx
   13f71:	inc    ecx
   13f72:	add    eax,0xc0
   13f77:	mov    DWORD PTR [esi+0x4],ecx
   13f7a:	mov    ebx,DWORD PTR [eax]
   13f7c:	mov    DWORD PTR [esi+0x10],ebx
   13f7f:	mov    DWORD PTR [esi+0x14],0x10000000
   13f86:	mov    DWORD PTR [esi+0x18],ecx
   13f89:	mov    DWORD PTR [esi+0x1c],0x40
   13f90:	mov    DWORD PTR [esi+0x20],edx
   13f93:	mov    DWORD PTR [esi+0x24],0x1007fffb
   13f9a:	mov    eax,DWORD PTR [eax]
   13f9c:	mov    DWORD PTR [esi+0x30],eax
   13f9f:	pop    esi
   13fa0:	xor    eax,eax
   13fa2:	pop    ebx
   13fa3:	pop    ebp
   13fa4:	ret    0x8
   13fa7:	int3
   13fa8:	int3
   13fa9:	int3
   13faa:	int3
   13fab:	int3
   13fac:	mov    edi,edi
   13fae:	push   ebp
   13faf:	mov    ebp,esp
   13fb1:	push   esi
   13fb2:	mov    esi,DWORD PTR [ebp+0x8]
   13fb5:	push   edi
   13fb6:	mov    edi,DWORD PTR [ebp+0xc]
   13fb9:	push   0x6
   13fbb:	add    esi,0x104
   13fc1:	pop    ecx
   13fc2:	rep movs DWORD PTR es:[edi],DWORD PTR ds:[esi]
   13fc4:	pop    edi
   13fc5:	xor    eax,eax
   13fc7:	pop    esi
   13fc8:	pop    ebp
   13fc9:	ret    0x8
   13fcc:	int3
   13fcd:	int3
   13fce:	int3
   13fcf:	int3
   13fd0:	int3
   13fd1:	int3
   13fd2:	mov    edi,edi
   13fd4:	push   ebp
   13fd5:	mov    ebp,esp
   13fd7:	push   esi
   13fd8:	mov    esi,DWORD PTR [ebp+0x8]
   13fdb:	push   edi
   13fdc:	mov    edi,DWORD PTR [ebp+0xc]
   13fdf:	push   0x5
   13fe1:	add    esi,0x11c
   13fe7:	pop    ecx
   13fe8:	rep movs DWORD PTR es:[edi],DWORD PTR ds:[esi]
   13fea:	pop    edi
   13feb:	xor    eax,eax
   13fed:	pop    esi
   13fee:	pop    ebp
   13fef:	ret    0x8
   13ff2:	int3
   13ff3:	int3
   13ff4:	int3
   13ff5:	int3
   13ff6:	int3
   13ff7:	int3
   13ff8:	mov    edi,edi
   13ffa:	push   ebp
   13ffb:	mov    ebp,esp
   13ffd:	mov    eax,DWORD PTR [ebp+0x8]
   14000:	mov    eax,DWORD PTR [eax+0x130]
   14006:	mov    ecx,DWORD PTR [ebp+0xc]
   14009:	mov    DWORD PTR [ecx],eax
   1400b:	xor    eax,eax
   1400d:	pop    ebp
   1400e:	ret    0x8
   14011:	int3
   14012:	int3
   14013:	int3
   14014:	int3
   14015:	int3
   14016:	mov    edi,edi
   14018:	push   ebp
   14019:	mov    ebp,esp
   1401b:	mov    eax,DWORD PTR [ebp+0xc]
   1401e:	mov    eax,DWORD PTR [eax]
   14020:	mov    ecx,DWORD PTR [ebp+0x8]
   14023:	mov    DWORD PTR [ecx+0xcc],eax
   14029:	xor    eax,eax
   1402b:	pop    ebp
   1402c:	ret    0x8
   1402f:	int3
   14030:	int3
   14031:	int3
   14032:	int3
   14033:	int3
   14034:	mov    edi,edi
   14036:	push   ebp
   14037:	mov    ebp,esp
   14039:	push   esi
   1403a:	mov    esi,DWORD PTR [ebp+0xc]
   1403d:	push   edi
   1403e:	mov    edi,DWORD PTR [ebp+0x8]
   14041:	add    edi,0xd0
   14047:	movs   DWORD PTR es:[edi],DWORD PTR ds:[esi]
   14048:	movs   WORD PTR es:[edi],WORD PTR ds:[esi]
   1404a:	pop    edi
   1404b:	xor    eax,eax
   1404d:	pop    esi
   1404e:	pop    ebp
   1404f:	ret    0x8
   14052:	int3
   14053:	int3
   14054:	int3
   14055:	int3
   14056:	int3
   14057:	int3
   14058:	mov    edi,edi
   1405a:	push   ebp
   1405b:	mov    ebp,esp
   1405d:	mov    eax,DWORD PTR [ebp+0x8]
   14060:	cmp    BYTE PTR [eax+0x137],0x0
   14067:	je     0x14070
   14069:	or     DWORD PTR [eax+0x100],0x20
   14070:	xor    eax,eax
   14072:	pop    ebp
   14073:	ret    0x4
   14076:	int3
   14077:	int3
   14078:	int3
   14079:	int3
   1407a:	int3
   1407b:	int3
   1407c:	mov    edi,edi
   1407e:	push   ebp
   1407f:	mov    ebp,esp
   14081:	push   esi
   14082:	mov    esi,DWORD PTR [ebp+0xc]
   14085:	push   edi
   14086:	mov    edi,DWORD PTR [ebp+0x8]
   14089:	add    edi,0xec
   1408f:	movs   DWORD PTR es:[edi],DWORD PTR ds:[esi]
   14090:	movs   DWORD PTR es:[edi],DWORD PTR ds:[esi]
   14091:	movs   DWORD PTR es:[edi],DWORD PTR ds:[esi]
   14092:	movs   DWORD PTR es:[edi],DWORD PTR ds:[esi]
   14093:	pop    edi
   14094:	xor    eax,eax
   14096:	pop    esi
   14097:	pop    ebp
   14098:	ret    0x8
   1409b:	int3
   1409c:	int3
   1409d:	int3
   1409e:	int3
   1409f:	int3
   140a0:	mov    edi,edi
   140a2:	push   ebp
   140a3:	mov    ebp,esp
   140a5:	push   esi
   140a6:	mov    esi,DWORD PTR [ebp+0xc]
   140a9:	push   edi
   140aa:	mov    edi,DWORD PTR [ebp+0x8]
   140ad:	add    edi,0xfc
   140b3:	movs   WORD PTR es:[edi],WORD PTR ds:[esi]
   140b5:	movs   BYTE PTR es:[edi],BYTE PTR ds:[esi]
   140b6:	pop    edi
   140b7:	xor    eax,eax
   140b9:	pop    esi
   140ba:	pop    ebp
   140bb:	ret    0x8
   140be:	int3
   140bf:	int3
   140c0:	int3
   140c1:	int3
   140c2:	int3
   140c3:	int3
   140c4:	xor    eax,eax
   140c6:	ret    0x4
   140c9:	int3
   140ca:	int3
   140cb:	int3
   140cc:	int3
   140cd:	int3
   140ce:	mov    edi,edi
   140d0:	push   ebp
   140d1:	mov    ebp,esp
   140d3:	push   esi
   140d4:	mov    esi,DWORD PTR [ebp+0xc]
   140d7:	cmp    DWORD PTR [esi],0xffffffff
   140da:	jne    0x140ef
   140dc:	cmp    DWORD PTR [esi+0x4],0xffffffff
   140e0:	jne    0x140ef
   140e2:	cmp    DWORD PTR [esi+0x8],0xffffffff
   140e6:	jne    0x140ef
   140e8:	mov    eax,0xc000000d
   140ed:	jmp    0x14101
   140ef:	push   edi
   140f0:	mov    edi,DWORD PTR [ebp+0x8]
   140f3:	push   0x5
   140f5:	add    edi,0x11c
   140fb:	pop    ecx
   140fc:	rep movs DWORD PTR es:[edi],DWORD PTR ds:[esi]
   140fe:	xor    eax,eax
   14100:	pop    edi
   14101:	pop    esi
   14102:	pop    ebp
   14103:	ret    0x8
   14106:	int3
   14107:	int3
   14108:	int3
   14109:	int3
   1410a:	int3
   1410b:	int3
   1410c:	xor    eax,eax
   1410e:	ret    0x8
   14111:	int3
   14112:	int3
   14113:	int3
   14114:	int3
   14115:	int3
   14116:	mov    edi,edi
   14118:	push   ebp
   14119:	mov    ebp,esp
   1411b:	push   ecx
   1411c:	push   ecx
   1411d:	push   ebx
   1411e:	push   esi
   1411f:	mov    esi,DWORD PTR [ebp+0x8]
   14122:	xor    ebx,ebx
   14124:	push   edi
   14125:	mov    edi,DWORD PTR [esi+0x14]
   14128:	mov    DWORD PTR [ebp-0x4],ebx
   1412b:	mov    DWORD PTR [ebp-0x8],ebx
   1412e:	cmp    edi,ebx
   14130:	je     0x14193
   14132:	push   edi
   14133:	mov    DWORD PTR [esi+0x14],ebx
   14136:	call   0x11088
   1413b:	cmp    eax,0xc0000120
   14140:	je     0x14193
   14142:	lea    eax,[ebp-0x8]
   14145:	push   eax
   14146:	lea    eax,[ebp-0x4]
   14149:	push   eax
   1414a:	push   0x4
   1414c:	push   edi
   1414d:	push   DWORD PTR ds:0x1770c
   14153:	call   DWORD PTR ds:0x17500
   14159:	cmp    eax,ebx
   1415b:	je     0x1416d
   1415d:	push   eax
   1415e:	push   edi
   1415f:	push   DWORD PTR ds:0x1770c
   14165:	call   DWORD PTR ds:0x174e4
   1416b:	jmp    0x14193
   1416d:	mov    eax,DWORD PTR [ebp+0xc]
   14170:	mov    ecx,DWORD PTR [ebp-0x4]
   14173:	mov    DWORD PTR [ecx],eax
   14175:	cmp    eax,ebx
   14177:	jne    0x1417e
   14179:	mov    DWORD PTR [esi+0x10],ebx
   1417c:	jmp    0x14183
   1417e:	not    eax
   14180:	and    DWORD PTR [esi+0x10],eax
   14183:	push   0x4
   14185:	push   ebx
   14186:	push   edi
   14187:	push   DWORD PTR ds:0x1770c
   1418d:	call   DWORD PTR ds:0x174ec
   14193:	pop    edi
   14194:	pop    esi
   14195:	pop    ebx
   14196:	leave
   14197:	ret    0x8
   1419a:	int3
   1419b:	int3
   1419c:	int3
   1419d:	int3
   1419e:	int3
   1419f:	int3
   141a0:	mov    edi,edi
   141a2:	push   ebp
   141a3:	mov    ebp,esp
   141a5:	mov    eax,DWORD PTR [ebp+0x8]
   141a8:	mov    ecx,DWORD PTR [ebp+0xc]
   141ab:	or     DWORD PTR [eax+0x10],ecx
   141ae:	mov    edx,DWORD PTR [eax+0x10]
   141b1:	push   esi
   141b2:	mov    esi,DWORD PTR [eax+0x130]
   141b8:	mov    ecx,esi
   141ba:	and    ecx,edx
   141bc:	test   cl,0x10
   141bf:	je     0x141c6
   141c1:	or     ecx,0x8
   141c4:	jmp    0x141c9
   141c6:	and    ecx,0xfffffff7
   141c9:	test   ecx,ecx
   141cb:	jne    0x141d5
   141cd:	test   edx,edx
   141cf:	je     0x141e4
   141d1:	test   esi,esi
   141d3:	jne    0x141e4
   141d5:	push   DWORD PTR [eax+0x20]
   141d8:	push   DWORD PTR ds:0x1770c
   141de:	call   DWORD PTR ds:0x17288
   141e4:	pop    esi
   141e5:	pop    ebp
   141e6:	ret    0x8
   141e9:	int3
   141ea:	int3
   141eb:	int3
   141ec:	int3
   141ed:	int3
   141ee:	mov    edi,edi
   141f0:	push   ebp
   141f1:	mov    ebp,esp
   141f3:	push   ebx
   141f4:	xor    ebx,ebx
   141f6:	cmp    DWORD PTR [ebp+0xc],ebx
   141f9:	je     0x142d7
   141ff:	test   DWORD PTR [ebp+0xc],0xfffffff0
   14206:	jne    0x142d7
   1420c:	test   BYTE PTR [ebp+0xc],0x2
   14210:	push   esi
   14211:	mov    esi,DWORD PTR [ebp+0x8]
   14214:	push   edi
   14215:	mov    edi,0xc0000120
   1421a:	je     0x14283
   1421c:	jmp    0x1422e
   1421e:	push   edi
   1421f:	push   DWORD PTR [ebp+0x8]
   14222:	push   DWORD PTR ds:0x1770c
   14228:	call   DWORD PTR ds:0x174e4
   1422e:	mov    eax,DWORD PTR [esi+0x8]
   14231:	lea    ecx,[ebp+0x8]
   14234:	push   ecx
   14235:	push   eax
   14236:	push   DWORD PTR ds:0x1770c
   1423c:	call   DWORD PTR ds:0x17340
   14242:	test   eax,eax
   14244:	je     0x1421e
   14246:	lea    eax,[esi+0x88]
   1424c:	mov    ecx,DWORD PTR [eax]
   1424e:	mov    DWORD PTR [ebp+0x8],ecx
   14251:	mov    DWORD PTR [eax],ebx
   14253:	cmp    ecx,ebx
   14255:	je     0x14283
   14257:	push   ecx
   14258:	call   0x11088
   1425d:	mov    DWORD PTR [esi+0x8c],ebx
   14263:	mov    DWORD PTR [esi+0x90],ebx
   14269:	mov    DWORD PTR [esi+0x94],ebx
   1426f:	cmp    eax,edi
   14271:	je     0x14283
   14273:	push   edi
   14274:	push   DWORD PTR [ebp+0x8]
   14277:	push   DWORD PTR ds:0x1770c
   1427d:	call   DWORD PTR ds:0x174e4
   14283:	test   BYTE PTR [ebp+0xc],0x8
   14287:	je     0x1429b
   14289:	lea    eax,[esi+0xb0]
   1428f:	push   eax
   14290:	call   0x11c1e
   14295:	mov    DWORD PTR [esi+0xe0],ebx
   1429b:	test   BYTE PTR [ebp+0xc],0x1
   1429f:	je     0x142d1
   142a1:	jmp    0x142b3
   142a3:	push   edi
   142a4:	push   DWORD PTR [ebp+0x8]
   142a7:	push   DWORD PTR ds:0x1770c
   142ad:	call   DWORD PTR ds:0x174e4
   142b3:	mov    eax,DWORD PTR [esi+0xc]
   142b6:	lea    ecx,[ebp+0x8]
   142b9:	push   ecx
   142ba:	push   eax
   142bb:	push   DWORD PTR ds:0x1770c
   142c1:	call   DWORD PTR ds:0x17340
   142c7:	test   eax,eax
   142c9:	je     0x142a3
   142cb:	mov    DWORD PTR [esi+0xe4],ebx
   142d1:	pop    edi
   142d2:	xor    eax,eax
   142d4:	pop    esi
   142d5:	jmp    0x142dc
   142d7:	mov    eax,0xc000000d
   142dc:	pop    ebx
   142dd:	pop    ebp
   142de:	ret    0x8
   142e1:	int3
   142e2:	int3
   142e3:	int3
   142e4:	int3
   142e5:	int3
   142e6:	mov    edi,edi
   142e8:	push   ebp
   142e9:	mov    ebp,esp
   142eb:	mov    eax,DWORD PTR [ebp+0x8]
   142ee:	lea    ecx,[eax+0x138]
   142f4:	xor    dl,dl
   142f6:	cmp    BYTE PTR [ecx],dl
   142f8:	je     0x1431a
   142fa:	mov    BYTE PTR [ecx],dl
   142fc:	cmp    BYTE PTR [eax+0x137],dl
   14302:	je     0x14310
   14304:	or     DWORD PTR [eax+0x100],0x80
   1430e:	jmp    0x1431a
   14310:	and    DWORD PTR [eax+0x100],0xffffff7f
   1431a:	pop    ebp
   1431b:	ret    0x4
   1431e:	int3
   1431f:	int3
   14320:	int3
   14321:	int3
   14322:	int3
   14323:	int3
   14324:	mov    edi,edi
   14326:	push   ebp
   14327:	mov    ebp,esp
   14329:	push   esi
   1432a:	mov    esi,DWORD PTR [ebp+0x8]
   1432d:	and    DWORD PTR [esi+0x100],0xffffff5f
   14337:	push   esi
   14338:	mov    BYTE PTR [esi+0x137],0x0
   1433f:	mov    BYTE PTR [esi+0x138],0x1
   14346:	call   0x142e6
   1434b:	test   BYTE PTR [esi+0x130],0x20
   14352:	je     0x1435c
   14354:	push   0x20
   14356:	push   esi
   14357:	call   0x141a0
   1435c:	xor    eax,eax
   1435e:	pop    esi
   1435f:	pop    ebp
   14360:	ret    0x4
   14363:	int3
   14364:	int3
   14365:	int3
   14366:	int3
   14367:	int3
   14368:	mov    edi,edi
   1436a:	push   ebp
   1436b:	mov    ebp,esp
   1436d:	push   ebx
   1436e:	mov    ebx,DWORD PTR [ebp+0xc]
   14371:	test   DWORD PTR [ebx],0xfffff800
   14377:	je     0x14380
   14379:	mov    eax,0xc000000d
   1437e:	jmp    0x143bb
   14380:	push   esi
   14381:	push   edi
   14382:	mov    edi,DWORD PTR [ebp+0x8]
   14385:	lea    esi,[edi+0xa8]
   1438b:	push   DWORD PTR [esi]
   1438d:	push   DWORD PTR ds:0x1770c
   14393:	call   DWORD PTR ds:0x175b8
   14399:	push   0x0
   1439b:	push   edi
   1439c:	call   0x14116
   143a1:	mov    eax,DWORD PTR [ebx]
   143a3:	push   DWORD PTR [esi]
   143a5:	mov    DWORD PTR [edi+0x130],eax
   143ab:	push   DWORD PTR ds:0x1770c
   143b1:	call   DWORD PTR ds:0x175bc
   143b7:	pop    edi
   143b8:	xor    eax,eax
   143ba:	pop    esi
   143bb:	pop    ebx
   143bc:	pop    ebp
   143bd:	ret    0x8
   143c0:	int3
   143c1:	int3
   143c2:	int3
   143c3:	int3
   143c4:	int3
   143c5:	int3
   143c6:	mov    edi,edi
   143c8:	push   ebp
   143c9:	mov    ebp,esp
   143cb:	push   ecx
   143cc:	push   ebx
   143cd:	push   esi
   143ce:	mov    esi,DWORD PTR [ebp+0x8]
   143d1:	xor    ebx,ebx
   143d3:	push   ebx
   143d4:	push   esi
   143d5:	mov    DWORD PTR [ebp-0x4],ebx
   143d8:	call   0x14116
   143dd:	cmp    DWORD PTR [esi+0x130],ebx
   143e3:	jne    0x14401
   143e5:	mov    esi,0xc0000120
   143ea:	push   esi
   143eb:	push   DWORD PTR [ebp+0xc]
   143ee:	push   DWORD PTR ds:0x1770c
   143f4:	call   DWORD PTR ds:0x174e4
   143fa:	mov    eax,esi
   143fc:	jmp    0x144af
   14401:	mov    ecx,DWORD PTR ds:0x1770c
   14407:	push   edi
   14408:	mov    edi,DWORD PTR [ebp+0xc]
   1440b:	push   DWORD PTR ds:0x1700c
   14411:	mov    edx,edi
   14413:	call   DWORD PTR ds:0x173f0
   14419:	mov    DWORD PTR [eax],ebx
   1441b:	mov    DWORD PTR [eax+0x4],ebx
   1441e:	mov    DWORD PTR [eax+0x8],ebx
   14421:	mov    ecx,DWORD PTR [esi]
   14423:	push   0x130ce
   14428:	mov    DWORD PTR [eax],ecx
   1442a:	push   edi
   1442b:	mov    DWORD PTR [esi+0x14],edi
   1442e:	call   0x1102a
   14433:	mov    ebx,eax
   14435:	test   ebx,ebx
   14437:	je     0x1444f
   14439:	push   ebx
   1443a:	push   edi
   1443b:	push   DWORD PTR ds:0x1770c
   14441:	call   DWORD PTR ds:0x174e4
   14447:	and    DWORD PTR [esi+0x14],0x0
   1444b:	mov    eax,ebx
   1444d:	jmp    0x144ae
   1444f:	lea    ebx,[esi+0xb0]
   14455:	push   ebx
   14456:	call   0x11b9e
   1445b:	test   al,al
   1445d:	jne    0x144a0
   1445f:	push   ebx
   14460:	mov    DWORD PTR [ebp-0x4],0x1
   14467:	call   0x11b76
   1446c:	push   ebx
   1446d:	mov    edi,eax
   1446f:	call   0x11b8a
   14474:	mov    DWORD PTR [ebp+0xc],eax
   14477:	cmp    edi,eax
   14479:	je     0x144a0
   1447b:	mov    al,BYTE PTR [esi+0xd3]
   14481:	cmp    BYTE PTR [edi],al
   14483:	jne    0x14489
   14485:	test   al,al
   14487:	jne    0x14499
   14489:	push   edi
   1448a:	push   ebx
   1448b:	call   0x11b5a
   14490:	mov    edi,eax
   14492:	cmp    edi,DWORD PTR [ebp+0xc]
   14495:	jne    0x1447b
   14497:	jmp    0x144a0
   14499:	mov    DWORD PTR [ebp-0x4],0x3
   144a0:	push   DWORD PTR [ebp-0x4]
   144a3:	push   esi
   144a4:	call   0x141a0
   144a9:	mov    eax,0x103
   144ae:	pop    edi
   144af:	pop    esi
   144b0:	pop    ebx
   144b1:	leave
   144b2:	ret    0x8
   144b5:	int3
   144b6:	int3
   144b7:	int3
   144b8:	int3
   144b9:	int3
   144ba:	ret    0x8
   144bd:	int3
   144be:	int3
   144bf:	int3
   144c0:	int3
   144c1:	int3
   144c2:	cmp    ecx,DWORD PTR ds:0x17044
   144c8:	jne    0x144cd
   144ca:	ret    0x0
   144cd:	jmp    0x144d7
   144d2:	int3
   144d3:	int3
   144d4:	int3
   144d5:	int3
   144d6:	int3
   144d7:	mov    edi,edi
   144d9:	push   ebp
   144da:	mov    ebp,esp
   144dc:	push   ecx
   144dd:	mov    DWORD PTR [ebp-0x4],ecx
   144e0:	push   0x0
   144e2:	push   DWORD PTR ds:0x17048
   144e8:	push   DWORD PTR ds:0x17044
   144ee:	push   DWORD PTR [ebp-0x4]
   144f1:	push   0xf7
   144f6:	call   DWORD PTR ds:0x16034
   144fc:	int3
   144fd:	int3
   144fe:	int3
   144ff:	int3
   14500:	int3
   14501:	int3
   14502:	jmp    DWORD PTR ds:0x16050
   14508:	int3
   14509:	int3
   1450a:	int3
   1450b:	int3
   1450c:	int3
   1450d:	int3
   1450e:	jmp    DWORD PTR ds:0x16048
   14514:	int3
   14515:	int3
   14516:	int3
   14517:	int3
   14518:	int3
   14519:	mov    edi,edi
   1451b:	push   esi
   1451c:	mov    esi,0x1704c
   14521:	push   esi
   14522:	call   0x146bf
   14527:	push   DWORD PTR ds:0x1770c
   1452d:	push   esi
   1452e:	push   0x176fc
   14533:	call   0x15500
   14538:	pop    esi
   14539:	ret
   1453a:	int3
   1453b:	int3
   1453c:	int3
   1453d:	int3
   1453e:	int3
   1453f:	mov    edi,edi
   14541:	push   ebp
   14542:	mov    ebp,esp
   14544:	mov    eax,ds:0x17704
   14549:	test   eax,eax
   1454b:	je     0x14559
   1454d:	cmp    eax,0x1453f
   14552:	je     0x14559
   14554:	push   DWORD PTR [ebp+0x8]
   14557:	call   eax
   14559:	call   0x14519
   1455e:	pop    ebp
   1455f:	ret    0x4
   14562:	int3
   14563:	int3
   14564:	int3
   14565:	int3
   14566:	int3
   14567:	call   0x14519
   1456c:	ret    0x8
   1456f:	int3
   14570:	int3
   14571:	int3
   14572:	int3
   14573:	int3
   14574:	mov    edi,edi
   14576:	push   ebp
   14577:	mov    ebp,esp
   14579:	push   edi
   1457a:	mov    edi,DWORD PTR [ebp+0x8]
   1457d:	test   edi,edi
   1457f:	jne    0x1458f
   14581:	push   DWORD PTR [ebp+0xc]
   14584:	push   edi
   14585:	call   0x110de
   1458a:	jmp    0x14640
   1458f:	push   ebx
   14590:	push   esi
   14591:	push   DWORD PTR [ebp+0xc]
   14594:	xor    eax,eax
   14596:	mov    ds:0x176fc,ax
   1459c:	mov    eax,0x208
   145a1:	mov    esi,0x176fc
   145a6:	push   esi
   145a7:	mov    DWORD PTR ds:0x17710,edi
   145ad:	mov    ds:0x176fe,ax
   145b3:	mov    DWORD PTR ds:0x17700,0x17718
   145bd:	call   DWORD PTR ds:0x16038
   145c3:	push   0x1770c
   145c8:	mov    ebx,0x1704c
   145cd:	push   ebx
   145ce:	push   esi
   145cf:	push   edi
   145d0:	call   0x1550c
   145d5:	test   eax,eax
   145d7:	jl     0x1463e
   145d9:	push   ebx
   145da:	call   0x1465f
   145df:	mov    esi,eax
   145e1:	test   esi,esi
   145e3:	jl     0x145f9
   145e5:	call   0x14710
   145ea:	push   DWORD PTR [ebp+0xc]
   145ed:	push   edi
   145ee:	call   0x110de
   145f3:	mov    esi,eax
   145f5:	test   esi,esi
   145f7:	jge    0x14602
   145f9:	call   0x14519
   145fe:	mov    eax,esi
   14600:	jmp    0x1463e
   14602:	mov    eax,ds:0x1770c
   14607:	cmp    BYTE PTR [eax+0x2c],0x0
   1460b:	je     0x14622
   1460d:	mov    eax,DWORD PTR [edi+0x34]
   14610:	test   eax,eax
   14612:	je     0x14619
   14614:	mov    ds:0x17704,eax
   14619:	mov    DWORD PTR [edi+0x34],0x1453f
   14620:	jmp    0x1463c
   14622:	test   BYTE PTR [eax+0x4],0x2
   14626:	je     0x1463c
   14628:	mov    eax,ds:0x173ec
   1462d:	mov    ds:0x17708,eax
   14632:	mov    DWORD PTR ds:0x173ec,0x14567
   1463c:	xor    eax,eax
   1463e:	pop    esi
   1463f:	pop    ebx
   14640:	pop    edi
   14641:	pop    ebp
   14642:	ret    0x8
   14645:	int3
   14646:	int3
   14647:	int3
   14648:	int3
   14649:	int3
   1464a:	mov    edi,edi
   1464c:	push   ebp
   1464d:	mov    ebp,esp
   1464f:	call   0x18005
   14654:	pop    ebp
   14655:	jmp    0x14574
   1465a:	int3
   1465b:	int3
   1465c:	int3
   1465d:	int3
   1465e:	int3
   1465f:	mov    edi,edi
   14661:	push   ebp
   14662:	mov    ebp,esp
   14664:	push   esi
   14665:	mov    esi,0x17098
   1466a:	push   edi
   1466b:	mov    ecx,esi
   1466d:	mov    edi,0x17098
   14672:	xor    eax,eax
   14674:	cmp    ecx,edi
   14676:	jae    0x146b4
   14678:	cmp    DWORD PTR [esi],0x2c
   1467b:	jne    0x146af
   1467d:	mov    eax,DWORD PTR [esi+0x20]
   14680:	push   esi
   14681:	push   DWORD PTR ds:0x1770c
   14687:	mov    DWORD PTR ds:0x1709c,esi
   1468d:	push   DWORD PTR [ebp+0x8]
   14690:	test   eax,eax
   14692:	je     0x1469d
   14694:	push   0x15518
   14699:	call   eax
   1469b:	jmp    0x146a2
   1469d:	call   0x15518
   146a2:	test   eax,eax
   146a4:	jl     0x146b4
   146a6:	add    esi,0x2c
   146a9:	cmp    esi,edi
   146ab:	jb     0x14678
   146ad:	jmp    0x146b4
   146af:	mov    eax,0xc0000004
   146b4:	pop    edi
   146b5:	pop    esi
   146b6:	pop    ebp
   146b7:	ret    0x4
   146ba:	int3
   146bb:	int3
   146bc:	int3
   146bd:	int3
   146be:	int3
   146bf:	mov    edi,edi
   146c1:	push   ebp
   146c2:	mov    ebp,esp
   146c4:	mov    eax,ds:0x1709c
   146c9:	mov    ecx,0x17098
   146ce:	push   esi
   146cf:	mov    esi,ecx
   146d1:	cmp    eax,0x17090
   146d6:	je     0x14706
   146d8:	cmp    eax,ecx
   146da:	jb     0x14706
   146dc:	mov    eax,DWORD PTR [esi+0x24]
   146df:	push   esi
   146e0:	push   DWORD PTR ds:0x1770c
   146e6:	push   DWORD PTR [ebp+0x8]
   146e9:	test   eax,eax
   146eb:	je     0x146f6
   146ed:	push   0x15524
   146f2:	call   eax
   146f4:	jmp    0x146fb
   146f6:	call   0x15524
   146fb:	add    esi,0x2c
   146fe:	cmp    esi,DWORD PTR ds:0x1709c
   14704:	jbe    0x146dc
   14706:	pop    esi
   14707:	pop    ebp
   14708:	ret    0x4
   1470b:	int3
   1470c:	int3
   1470d:	int3
   1470e:	int3
   1470f:	int3
   14710:	mov    ecx,0x170a8
   14715:	mov    edx,ecx
   14717:	mov    eax,0x170a8
   1471c:	cmp    edx,eax
   1471e:	jae    0x14747
   14720:	push   esi
   14721:	push   edi
   14722:	sub    eax,ecx
   14724:	push   0x14
   14726:	dec    eax
   14727:	xor    edx,edx
   14729:	pop    ecx
   1472a:	div    ecx
   1472c:	mov    edi,0x170b8
   14731:	mov    esi,eax
   14733:	inc    esi
   14734:	mov    eax,DWORD PTR [edi]
   14736:	test   eax,eax
   14738:	je     0x1473f
   1473a:	call   eax
   1473c:	mov    DWORD PTR [edi-0x4],eax
   1473f:	add    edi,0x14
   14742:	dec    esi
   14743:	jne    0x14734
   14745:	pop    edi
   14746:	pop    esi
   14747:	ret
   14748:	int3
   14749:	int3
   1474a:	int3
   1474b:	int3
   1474c:	int3
   1474d:	int3
   1474e:	mov    edi,edi
   14750:	push   ebp
   14751:	mov    ebp,esp
   14753:	mov    ecx,DWORD PTR [ebp+0x8]
   14756:	xor    eax,eax
   14758:	test   ecx,ecx
   1475a:	jne    0x14765
   1475c:	test   DWORD PTR [ebp+0x10],0x100
   14763:	jne    0x147a1
   14765:	push   ebx
   14766:	movzx  ebx,WORD PTR [ecx]
   14769:	test   bl,0x1
   1476c:	jne    0x1479b
   1476e:	movzx  edx,WORD PTR [ecx+0x2]
   14772:	test   dl,0x1
   14775:	jne    0x1479b
   14777:	cmp    bx,dx
   1477a:	ja     0x1479b
   1477c:	push   esi
   1477d:	mov    esi,DWORD PTR [ebp+0xc]
   14780:	push   edi
   14781:	movzx  edi,dx
   14784:	add    esi,esi
   14786:	cmp    edi,esi
   14788:	pop    edi
   14789:	pop    esi
   1478a:	ja     0x1479b
   1478c:	cmp    DWORD PTR [ecx+0x4],eax
   1478f:	jne    0x147a0
   14791:	test   bx,bx
   14794:	jne    0x1479b
   14796:	test   dx,dx
   14799:	je     0x147a0
   1479b:	mov    eax,0xc000000d
   147a0:	pop    ebx
   147a1:	pop    ebp
   147a2:	ret    0xc
   147a5:	int3
   147a6:	int3
   147a7:	int3
   147a8:	int3
   147a9:	int3
   147aa:	mov    edi,edi
   147ac:	push   ebp
   147ad:	mov    ebp,esp
   147af:	mov    eax,DWORD PTR [ebp+0x14]
   147b2:	push   ebx
   147b3:	mov    ebx,DWORD PTR [ebp+0x10]
   147b6:	push   esi
   147b7:	xor    ecx,ecx
   147b9:	push   edi
   147ba:	mov    edi,DWORD PTR [ebp+0xc]
   147bd:	mov    DWORD PTR [edi],ecx
   147bf:	mov    DWORD PTR [ebx],ecx
   147c1:	cmp    eax,ecx
   147c3:	je     0x147c7
   147c5:	mov    DWORD PTR [eax],ecx
   147c7:	push   DWORD PTR [ebp+0x1c]
   147ca:	mov    esi,DWORD PTR [ebp+0x8]
   147cd:	push   DWORD PTR [ebp+0x18]
   147d0:	push   esi
   147d1:	call   0x1474e
   147d6:	test   eax,eax
   147d8:	jl     0x147f9
   147da:	test   esi,esi
   147dc:	je     0x147f9
   147de:	mov    ecx,DWORD PTR [esi+0x4]
   147e1:	mov    DWORD PTR [edi],ecx
   147e3:	movzx  ecx,WORD PTR [esi+0x2]
   147e7:	shr    ecx,1
   147e9:	mov    DWORD PTR [ebx],ecx
   147eb:	mov    ecx,DWORD PTR [ebp+0x14]
   147ee:	test   ecx,ecx
   147f0:	je     0x147f9
   147f2:	movzx  edx,WORD PTR [esi]
   147f5:	shr    edx,1
   147f7:	mov    DWORD PTR [ecx],edx
   147f9:	pop    edi
   147fa:	pop    esi
   147fb:	pop    ebx
   147fc:	pop    ebp
   147fd:	ret    0x18
   14800:	int3
   14801:	int3
   14802:	int3
   14803:	int3
   14804:	int3
   14805:	int3
   14806:	mov    edi,edi
   14808:	push   ebp
   14809:	mov    ebp,esp
   1480b:	push   esi
   1480c:	mov    esi,DWORD PTR [ebp+0xc]
   1480f:	push   edi
   14810:	push   DWORD PTR [ebp+0x18]
   14813:	xor    edi,edi
   14815:	push   DWORD PTR [ebp+0x14]
   14818:	push   esi
   14819:	push   DWORD PTR [ebp+0x8]
   1481c:	call   0x1490d
   14821:	add    esp,0x10
   14824:	test   eax,eax
   14826:	jl     0x14833
   14828:	cmp    eax,esi
   1482a:	ja     0x14833
   1482c:	mov    ecx,DWORD PTR [ebp+0x10]
   1482f:	mov    DWORD PTR [ecx],eax
   14831:	jmp    0x1483d
   14833:	mov    eax,DWORD PTR [ebp+0x10]
   14836:	mov    DWORD PTR [eax],esi
   14838:	mov    edi,0x80000005
   1483d:	mov    eax,edi
   1483f:	pop    edi
   14840:	pop    esi
   14841:	pop    ebp
   14842:	ret    0x14
   14845:	int3
   14846:	int3
   14847:	int3
   14848:	int3
   14849:	int3
   1484a:	mov    edi,edi
   1484c:	push   ebp
   1484d:	mov    ebp,esp
   1484f:	sub    esp,0x20
   14852:	push   ebx
   14853:	xor    ebx,ebx
   14855:	cmp    DWORD PTR [ebp+0x10],ebx
   14858:	jne    0x1486f
   1485a:	push   ebx
   1485b:	push   ebx
   1485c:	push   ebx
   1485d:	push   ebx
   1485e:	push   ebx
   1485f:	call   0x14945
   14864:	add    esp,0x14
   14867:	or     eax,0xffffffff
   1486a:	jmp    0x14905
   1486f:	mov    eax,DWORD PTR [ebp+0xc]
   14872:	push   esi
   14873:	mov    esi,DWORD PTR [ebp+0x8]
   14876:	cmp    eax,ebx
   14878:	je     0x14890
   1487a:	cmp    esi,ebx
   1487c:	jne    0x14890
   1487e:	push   ebx
   1487f:	push   ebx
   14880:	push   ebx
   14881:	push   ebx
   14882:	push   ebx
   14883:	call   0x14945
   14888:	add    esp,0x14
   1488b:	or     eax,0xffffffff
   1488e:	jmp    0x14904
   14890:	mov    DWORD PTR [ebp-0x14],0x42
   14897:	mov    DWORD PTR [ebp-0x18],esi
   1489a:	mov    DWORD PTR [ebp-0x20],esi
   1489d:	cmp    eax,0x3fffffff
   148a2:	jbe    0x148ad
   148a4:	mov    DWORD PTR [ebp-0x1c],0x7fffffff
   148ab:	jmp    0x148b2
   148ad:	add    eax,eax
   148af:	mov    DWORD PTR [ebp-0x1c],eax
   148b2:	push   edi
   148b3:	push   DWORD PTR [ebp+0x18]
   148b6:	lea    eax,[ebp-0x20]
   148b9:	push   DWORD PTR [ebp+0x14]
   148bc:	push   DWORD PTR [ebp+0x10]
   148bf:	push   eax
   148c0:	call   0x14a0d
   148c5:	add    esp,0x10
   148c8:	mov    edi,eax
   148ca:	cmp    esi,ebx
   148cc:	je     0x14903
   148ce:	dec    DWORD PTR [ebp-0x1c]
   148d1:	js     0x148dd
   148d3:	mov    eax,DWORD PTR [ebp-0x20]
   148d6:	mov    BYTE PTR [eax],bl
   148d8:	inc    DWORD PTR [ebp-0x20]
   148db:	jmp    0x148e9
   148dd:	lea    eax,[ebp-0x20]
   148e0:	push   eax
   148e1:	push   ebx
   148e2:	call   0x1492f
   148e7:	pop    ecx
   148e8:	pop    ecx
   148e9:	dec    DWORD PTR [ebp-0x1c]
   148ec:	js     0x148f5
   148ee:	mov    eax,DWORD PTR [ebp-0x20]
   148f1:	mov    BYTE PTR [eax],bl
   148f3:	jmp    0x14901
   148f5:	lea    eax,[ebp-0x20]
   148f8:	push   eax
   148f9:	push   ebx
   148fa:	call   0x1492f
   148ff:	pop    ecx
   14900:	pop    ecx
   14901:	mov    eax,edi
   14903:	pop    edi
   14904:	pop    esi
   14905:	pop    ebx
   14906:	leave
   14907:	ret
   14908:	int3
   14909:	int3
   1490a:	int3
   1490b:	int3
   1490c:	int3
   1490d:	mov    edi,edi
   1490f:	push   ebp
   14910:	mov    ebp,esp
   14912:	push   DWORD PTR [ebp+0x14]
   14915:	push   0x0
   14917:	push   DWORD PTR [ebp+0x10]
   1491a:	push   DWORD PTR [ebp+0xc]
   1491d:	push   DWORD PTR [ebp+0x8]
   14920:	call   0x1484a
   14925:	add    esp,0x14
   14928:	pop    ebp
   14929:	ret
   1492a:	int3
   1492b:	int3
   1492c:	int3
   1492d:	int3
   1492e:	int3
   1492f:	mov    edi,edi
   14931:	push   ebp
   14932:	mov    ebp,esp
   14934:	mov    eax,DWORD PTR [ebp+0xc]
   14937:	or     DWORD PTR [eax+0xc],0x20
   1493b:	or     eax,0xffffffff
   1493e:	pop    ebp
   1493f:	ret
   14940:	int3
   14941:	int3
   14942:	int3
   14943:	int3
   14944:	int3
   14945:	ret
   14946:	int3
   14947:	int3
   14948:	int3
   14949:	int3
   1494a:	int3
   1494b:	mov    edi,edi
   1494d:	push   ebp
   1494e:	mov    ebp,esp
   14950:	test   BYTE PTR [esi+0xc],0x40
   14954:	je     0x1495c
   14956:	cmp    DWORD PTR [esi+0x8],0x0
   1495a:	je     0x1497c
   1495c:	push   esi
   1495d:	push   DWORD PTR [ebp+0x8]
   14960:	call   0x1544a
   14965:	pop    ecx
   14966:	pop    ecx
   14967:	mov    ecx,0xffff
   1496c:	cmp    ax,cx
   1496f:	jne    0x1497c
   14971:	test   BYTE PTR [esi+0xc],0x20
   14975:	je     0x1497c
   14977:	or     DWORD PTR [edi],0xffffffff
   1497a:	pop    ebp
   1497b:	ret
   1497c:	inc    DWORD PTR [edi]
   1497e:	pop    ebp
   1497f:	ret
   14980:	int3
   14981:	int3
   14982:	int3
   14983:	int3
   14984:	int3
   14985:	mov    edi,edi
   14987:	push   ebp
   14988:	mov    ebp,esp
   1498a:	cmp    DWORD PTR [ebp+0xc],0x0
   1498e:	push   edi
   1498f:	mov    edi,eax
   14991:	jle    0x149af
   14993:	push   esi
   14994:	push   DWORD PTR [ebp+0x8]
   14997:	mov    esi,DWORD PTR [ebp+0x10]
   1499a:	dec    DWORD PTR [ebp+0xc]
   1499d:	call   0x1494b
   149a2:	cmp    DWORD PTR [edi],0xffffffff
   149a5:	pop    ecx
   149a6:	je     0x149ae
   149a8:	cmp    DWORD PTR [ebp+0xc],0x0
   149ac:	jg     0x14994
   149ae:	pop    esi
   149af:	pop    edi
   149b0:	pop    ebp
   149b1:	ret
   149b2:	int3
   149b3:	int3
   149b4:	int3
   149b5:	int3
   149b6:	int3
   149b7:	mov    edi,edi
   149b9:	push   ebp
   149ba:	mov    ebp,esp
   149bc:	push   ebx
   149bd:	push   esi
   149be:	mov    esi,ecx
   149c0:	test   BYTE PTR [esi+0xc],0x40
   149c4:	push   edi
   149c5:	mov    edi,eax
   149c7:	mov    ebx,edx
   149c9:	je     0x149fd
   149cb:	cmp    DWORD PTR [esi+0x8],0x0
   149cf:	jne    0x149fd
   149d1:	mov    eax,DWORD PTR [ebp+0x8]
   149d4:	add    DWORD PTR [edi],eax
   149d6:	jmp    0x14a03
   149d8:	movzx  eax,WORD PTR [ebx]
   149db:	dec    DWORD PTR [ebp+0x8]
   149de:	push   eax
   149df:	call   0x1494b
   149e4:	inc    ebx
   149e5:	inc    ebx
   149e6:	cmp    DWORD PTR [edi],0xffffffff
   149e9:	pop    ecx
   149ea:	jne    0x149fd
   149ec:	cmp    DWORD PTR ds:0x17928,0x2a
   149f3:	jne    0x14a03
   149f5:	push   0x3f
   149f7:	call   0x1494b
   149fc:	pop    ecx
   149fd:	cmp    DWORD PTR [ebp+0x8],0x0
   14a01:	jg     0x149d8
   14a03:	pop    edi
   14a04:	pop    esi
   14a05:	pop    ebx
   14a06:	pop    ebp
   14a07:	ret
   14a08:	int3
   14a09:	int3
   14a0a:	int3
   14a0b:	int3
   14a0c:	int3
   14a0d:	mov    edi,edi
   14a0f:	push   ebp
   14a10:	mov    ebp,esp
   14a12:	sub    esp,0x454
   14a18:	mov    eax,ds:0x17044
   14a1d:	xor    eax,ebp
   14a1f:	mov    DWORD PTR [ebp-0x4],eax
   14a22:	mov    eax,DWORD PTR [ebp+0x8]
   14a25:	mov    ecx,DWORD PTR [ebp+0x14]
   14a28:	push   edi
   14a29:	xor    edi,edi
   14a2b:	mov    DWORD PTR [ebp-0x42c],eax
   14a31:	mov    DWORD PTR [ebp-0x41c],ecx
   14a37:	mov    DWORD PTR [ebp-0x440],edi
   14a3d:	mov    DWORD PTR [ebp-0x408],edi
   14a43:	mov    DWORD PTR [ebp-0x430],edi
   14a49:	mov    DWORD PTR [ebp-0x40c],edi
   14a4f:	mov    DWORD PTR [ebp-0x424],edi
   14a55:	mov    DWORD PTR [ebp-0x43c],edi
   14a5b:	mov    DWORD PTR [ebp-0x428],edi
   14a61:	cmp    eax,edi
   14a63:	jne    0x14a7a
   14a65:	push   edi
   14a66:	push   edi
   14a67:	push   edi
   14a68:	push   edi
   14a69:	push   edi
   14a6a:	call   0x14945
   14a6f:	add    esp,0x14
   14a72:	or     eax,0xffffffff
   14a75:	jmp    0x15358
   14a7a:	mov    edx,DWORD PTR [ebp+0xc]
   14a7d:	cmp    edx,edi
   14a7f:	je     0x14a65
   14a81:	push   ebx
   14a82:	push   esi
   14a83:	movzx  esi,WORD PTR [edx]
   14a86:	mov    DWORD PTR [ebp-0x418],edi
   14a8c:	mov    DWORD PTR [ebp-0x414],edi
   14a92:	cmp    si,di
   14a95:	je     0x15350
   14a9b:	push   0x2
   14a9d:	pop    ebx
   14a9e:	add    edx,ebx
   14aa0:	cmp    DWORD PTR [ebp-0x418],0x0
   14aa7:	mov    DWORD PTR [ebp+0xc],edx
   14aaa:	jl     0x15350
   14ab0:	lea    eax,[esi-0x20]
   14ab3:	cmp    ax,0x58
   14ab7:	ja     0x14ac8
   14ab9:	movzx  eax,si
   14abc:	movsx  eax,BYTE PTR [eax+0x160f0]
   14ac3:	and    eax,0xf
   14ac6:	jmp    0x14aca
   14ac8:	xor    eax,eax
   14aca:	movsx  eax,BYTE PTR [edi+eax*8+0x16110]
   14ad2:	push   0x7
   14ad4:	sar    eax,0x4
   14ad7:	pop    edi
   14ad8:	mov    DWORD PTR [ebp-0x448],eax
   14ade:	cmp    eax,edi
   14ae0:	ja     0x15320
   14ae6:	jmp    DWORD PTR [eax*4+0x15365]
   14aed:	xor    eax,eax
   14aef:	or     DWORD PTR [ebp-0x40c],0xffffffff
   14af6:	mov    DWORD PTR [ebp-0x43c],eax
   14afc:	mov    DWORD PTR [ebp-0x430],eax
   14b02:	mov    DWORD PTR [ebp-0x424],eax
   14b08:	mov    DWORD PTR [ebp-0x408],eax
   14b0e:	mov    DWORD PTR [ebp-0x428],eax
   14b14:	jmp    0x15320
   14b19:	movzx  eax,si
   14b1c:	sub    eax,0x20
   14b1f:	je     0x14b6b
   14b21:	sub    eax,0x3
   14b24:	je     0x14b5c
   14b26:	sub    eax,0x8
   14b29:	je     0x14b50
   14b2b:	sub    eax,ebx
   14b2d:	je     0x14b44
   14b2f:	sub    eax,0x3
   14b32:	jne    0x15320
   14b38:	or     DWORD PTR [ebp-0x408],0x8
   14b3f:	jmp    0x15320
   14b44:	or     DWORD PTR [ebp-0x408],0x4
   14b4b:	jmp    0x15320
   14b50:	or     DWORD PTR [ebp-0x408],0x1
   14b57:	jmp    0x15320
   14b5c:	or     DWORD PTR [ebp-0x408],0x80
   14b66:	jmp    0x15320
   14b6b:	or     DWORD PTR [ebp-0x408],ebx
   14b71:	jmp    0x15320
   14b76:	cmp    si,0x2a
   14b7a:	jne    0x14ba8
   14b7c:	add    ecx,0x4
   14b7f:	mov    DWORD PTR [ebp-0x41c],ecx
   14b85:	mov    ecx,DWORD PTR [ecx-0x4]
   14b88:	mov    DWORD PTR [ebp-0x430],ecx
   14b8e:	test   ecx,ecx
   14b90:	jge    0x15320
   14b96:	or     DWORD PTR [ebp-0x408],0x4
   14b9d:	neg    DWORD PTR [ebp-0x430]
   14ba3:	jmp    0x15320
   14ba8:	mov    eax,DWORD PTR [ebp-0x430]
   14bae:	imul   eax,eax,0xa
   14bb1:	movzx  ecx,si
   14bb4:	lea    eax,[eax+ecx*1-0x30]
   14bb8:	mov    DWORD PTR [ebp-0x430],eax
   14bbe:	jmp    0x15320
   14bc3:	and    DWORD PTR [ebp-0x40c],0x0
   14bca:	jmp    0x15320
   14bcf:	cmp    si,0x2a
   14bd3:	jne    0x14bfb
   14bd5:	add    ecx,0x4
   14bd8:	mov    DWORD PTR [ebp-0x41c],ecx
   14bde:	mov    ecx,DWORD PTR [ecx-0x4]
   14be1:	mov    DWORD PTR [ebp-0x40c],ecx
   14be7:	test   ecx,ecx
   14be9:	jge    0x15320
   14bef:	or     DWORD PTR [ebp-0x40c],0xffffffff
   14bf6:	jmp    0x15320
   14bfb:	mov    eax,DWORD PTR [ebp-0x40c]
   14c01:	imul   eax,eax,0xa
   14c04:	movzx  ecx,si
   14c07:	lea    eax,[eax+ecx*1-0x30]
   14c0b:	mov    DWORD PTR [ebp-0x40c],eax
   14c11:	jmp    0x15320
   14c16:	movzx  eax,si
   14c19:	cmp    eax,0x49
   14c1c:	je     0x14c72
   14c1e:	cmp    eax,0x68
   14c21:	je     0x14c66
   14c23:	cmp    eax,0x6c
   14c26:	je     0x14c40
   14c28:	cmp    eax,0x77
   14c2b:	jne    0x15320
   14c31:	or     DWORD PTR [ebp-0x408],0x800
   14c3b:	jmp    0x15320
   14c40:	cmp    WORD PTR [edx],0x6c
   14c44:	jne    0x14c5a
   14c46:	add    edx,ebx
   14c48:	or     DWORD PTR [ebp-0x408],0x1000
   14c52:	mov    DWORD PTR [ebp+0xc],edx
   14c55:	jmp    0x15320
   14c5a:	or     DWORD PTR [ebp-0x408],0x10
   14c61:	jmp    0x15320
   14c66:	or     DWORD PTR [ebp-0x408],0x20
   14c6d:	jmp    0x15320
   14c72:	movzx  eax,WORD PTR [edx]
   14c75:	cmp    ax,0x36
   14c79:	jne    0x14c97
   14c7b:	cmp    WORD PTR [edx+0x2],0x34
   14c80:	jne    0x14c97
   14c82:	add    edx,0x4
   14c85:	or     DWORD PTR [ebp-0x408],0x8000
   14c8f:	mov    DWORD PTR [ebp+0xc],edx
   14c92:	jmp    0x15320
   14c97:	cmp    ax,0x33
   14c9b:	jne    0x14cb9
   14c9d:	cmp    WORD PTR [edx+0x2],0x32
   14ca2:	jne    0x14cb9
   14ca4:	add    edx,0x4
   14ca7:	and    DWORD PTR [ebp-0x408],0xffff7fff
   14cb1:	mov    DWORD PTR [ebp+0xc],edx
   14cb4:	jmp    0x15320
   14cb9:	cmp    ax,0x64
   14cbd:	je     0x15320
   14cc3:	cmp    ax,0x69
   14cc7:	je     0x15320
   14ccd:	cmp    ax,0x6f
   14cd1:	je     0x15320
   14cd7:	cmp    ax,0x75
   14cdb:	je     0x15320
   14ce1:	cmp    ax,0x78
   14ce5:	je     0x15320
   14ceb:	cmp    ax,0x58
   14cef:	je     0x15320
   14cf5:	and    DWORD PTR [ebp-0x448],0x0
   14cfc:	push   esi
   14cfd:	mov    esi,DWORD PTR [ebp-0x42c]
   14d03:	lea    edi,[ebp-0x418]
   14d09:	mov    DWORD PTR [ebp-0x428],0x1
   14d13:	call   0x1494b
   14d18:	pop    ecx
   14d19:	jmp    0x15320
   14d1e:	movzx  eax,si
   14d21:	cmp    eax,0x69
   14d24:	jg     0x14f1f
   14d2a:	je     0x14d5b
   14d2c:	sub    eax,0x43
   14d2f:	je     0x14e95
   14d35:	sub    eax,0x10
   14d38:	je     0x14e08
   14d3e:	sub    eax,0x5
   14d41:	je     0x14f97
   14d47:	sub    eax,ebx
   14d49:	je     0x14d71
   14d4b:	sub    eax,0x9
   14d4e:	je     0x14ea8
   14d54:	dec    eax
   14d55:	jne    0x15178
   14d5b:	or     DWORD PTR [ebp-0x408],0x40
   14d62:	mov    DWORD PTR [ebp-0x420],0xa
   14d6c:	jmp    0x14fef
   14d71:	mov    eax,DWORD PTR [ecx]
   14d73:	add    ecx,0x4
   14d76:	mov    DWORD PTR [ebp-0x41c],ecx
   14d7c:	test   eax,eax
   14d7e:	je     0x14def
   14d80:	mov    esi,DWORD PTR [eax+0x4]
   14d83:	test   esi,esi
   14d85:	je     0x14def
   14d87:	movzx  ecx,WORD PTR [eax]
   14d8a:	cmp    WORD PTR [eax+0x2],cx
   14d8e:	jb     0x1533c
   14d94:	test   DWORD PTR [ebp-0x408],0x800
   14d9e:	movzx  eax,cx
   14da1:	je     0x14dd7
   14da3:	xor    ecx,ecx
   14da5:	mov    edx,eax
   14da7:	not    edx
   14da9:	inc    ecx
   14daa:	test   cl,dl
   14dac:	je     0x1533c
   14db2:	mov    edx,esi
   14db4:	not    edx
   14db6:	test   cl,dl
   14db8:	je     0x1533c
   14dbe:	shr    eax,1
   14dc0:	mov    DWORD PTR [ebp-0x410],esi
   14dc6:	mov    DWORD PTR [ebp-0x414],eax
   14dcc:	mov    DWORD PTR [ebp-0x428],ecx
   14dd2:	jmp    0x15178
   14dd7:	and    DWORD PTR [ebp-0x428],0x0
   14dde:	mov    DWORD PTR [ebp-0x410],esi
   14de4:	mov    DWORD PTR [ebp-0x414],eax
   14dea:	jmp    0x15178
   14def:	mov    eax,ds:0x1706c
   14df4:	mov    DWORD PTR [ebp-0x410],eax
   14dfa:	lea    edx,[eax+0x1]
   14dfd:	mov    cl,BYTE PTR [eax]
   14dff:	inc    eax
   14e00:	test   cl,cl
   14e02:	jne    0x14dfd
   14e04:	sub    eax,edx
   14e06:	jmp    0x14de4
   14e08:	test   DWORD PTR [ebp-0x408],0x830
   14e12:	jne    0x14e1b
   14e14:	or     DWORD PTR [ebp-0x408],0x20
   14e1b:	cmp    DWORD PTR [ebp-0x40c],0xffffffff
   14e22:	mov    edx,0x7fffffff
   14e27:	je     0x14e2f
   14e29:	mov    edx,DWORD PTR [ebp-0x40c]
   14e2f:	add    ecx,0x4
   14e32:	test   BYTE PTR [ebp-0x408],0x20
   14e39:	mov    DWORD PTR [ebp-0x41c],ecx
   14e3f:	mov    ecx,DWORD PTR [ecx-0x4]
   14e42:	mov    DWORD PTR [ebp-0x410],ecx
   14e48:	je     0x14f58
   14e4e:	test   ecx,ecx
   14e50:	jne    0x14e5d
   14e52:	mov    eax,ds:0x1706c
   14e57:	mov    DWORD PTR [ebp-0x410],eax
   14e5d:	and    DWORD PTR [ebp-0x414],0x0
   14e64:	test   edx,edx
   14e66:	jle    0x15178
   14e6c:	mov    eax,DWORD PTR [ebp-0x410]
   14e72:	mov    ecx,DWORD PTR [ebp-0x414]
   14e78:	cmp    BYTE PTR [eax+ecx*1],0x0
   14e7c:	je     0x15178
   14e82:	inc    DWORD PTR [ebp-0x414]
   14e88:	cmp    DWORD PTR [ebp-0x414],edx
   14e8e:	jl     0x14e6c
   14e90:	jmp    0x15178
   14e95:	test   DWORD PTR [ebp-0x408],0x830
   14e9f:	jne    0x14ea8
   14ea1:	or     DWORD PTR [ebp-0x408],0x20
   14ea8:	movzx  eax,WORD PTR [ecx]
   14eab:	add    ecx,0x4
   14eae:	xor    edi,edi
   14eb0:	inc    edi
   14eb1:	test   BYTE PTR [ebp-0x408],0x20
   14eb8:	mov    DWORD PTR [ebp-0x428],edi
   14ebe:	mov    DWORD PTR [ebp-0x41c],ecx
   14ec4:	mov    DWORD PTR [ebp-0x44c],eax
   14eca:	je     0x14f01
   14ecc:	push   DWORD PTR ds:0x17080
   14ed2:	mov    BYTE PTR [ebp-0x438],al
   14ed8:	lea    eax,[ebp-0x438]
   14ede:	push   eax
   14edf:	lea    eax,[ebp-0x404]
   14ee5:	push   eax
   14ee6:	mov    BYTE PTR [ebp-0x437],0x0
   14eed:	call   0x15494
   14ef2:	add    esp,0xc
   14ef5:	test   eax,eax
   14ef7:	jge    0x14f08
   14ef9:	mov    DWORD PTR [ebp-0x43c],edi
   14eff:	jmp    0x14f08
   14f01:	mov    WORD PTR [ebp-0x404],ax
   14f08:	lea    eax,[ebp-0x404]
   14f0e:	mov    DWORD PTR [ebp-0x410],eax
   14f14:	mov    DWORD PTR [ebp-0x414],edi
   14f1a:	jmp    0x15178
   14f1f:	sub    eax,0x6e
   14f22:	je     0x15139
   14f28:	dec    eax
   14f29:	je     0x14fd2
   14f2f:	dec    eax
   14f30:	je     0x14f8d
   14f32:	sub    eax,0x3
   14f35:	je     0x14e1b
   14f3b:	sub    eax,ebx
   14f3d:	je     0x14d62
   14f43:	sub    eax,0x3
   14f46:	jne    0x15178
   14f4c:	mov    DWORD PTR [ebp-0x440],0x27
   14f56:	jmp    0x14f9d
   14f58:	test   ecx,ecx
   14f5a:	jne    0x14f69
   14f5c:	mov    eax,ds:0x17070
   14f61:	mov    DWORD PTR [ebp-0x410],eax
   14f67:	mov    ecx,eax
   14f69:	mov    DWORD PTR [ebp-0x428],0x1
   14f73:	mov    eax,ecx
   14f75:	jmp    0x14f80
   14f77:	dec    edx
   14f78:	cmp    WORD PTR [eax],0x0
   14f7c:	je     0x14f84
   14f7e:	add    eax,ebx
   14f80:	test   edx,edx
   14f82:	jne    0x14f77
   14f84:	sub    eax,ecx
   14f86:	sar    eax,1
   14f88:	jmp    0x14de4
   14f8d:	mov    DWORD PTR [ebp-0x40c],0x8
   14f97:	mov    DWORD PTR [ebp-0x440],edi
   14f9d:	test   BYTE PTR [ebp-0x408],0x80
   14fa4:	mov    DWORD PTR [ebp-0x420],0x10
   14fae:	je     0x14fef
   14fb0:	push   0x30
   14fb2:	pop    eax
   14fb3:	mov    WORD PTR [ebp-0x434],ax
   14fba:	mov    eax,DWORD PTR [ebp-0x440]
   14fc0:	add    eax,0x51
   14fc3:	mov    WORD PTR [ebp-0x432],ax
   14fca:	mov    DWORD PTR [ebp-0x424],ebx
   14fd0:	jmp    0x14fef
   14fd2:	test   BYTE PTR [ebp-0x408],0x80
   14fd9:	mov    DWORD PTR [ebp-0x420],0x8
   14fe3:	je     0x14fef
   14fe5:	or     DWORD PTR [ebp-0x408],0x200
   14fef:	mov    ebx,DWORD PTR [ebp-0x408]
   14ff5:	test   ebx,0x8000
   14ffb:	je     0x15007
   14ffd:	mov    eax,DWORD PTR [ecx]
   14fff:	mov    edx,DWORD PTR [ecx+0x4]
   15002:	add    ecx,0x8
   15005:	jmp    0x1503c
   15007:	test   ebx,0x1000
   1500d:	jne    0x14ffd
   1500f:	add    ecx,0x4
   15012:	test   bl,0x20
   15015:	je     0x1502f
   15017:	mov    DWORD PTR [ebp-0x41c],ecx
   1501d:	test   bl,0x40
   15020:	je     0x15028
   15022:	movsx  eax,WORD PTR [ecx-0x4]
   15026:	jmp    0x1502c
   15028:	movzx  eax,WORD PTR [ecx-0x4]
   1502c:	cdq
   1502d:	jmp    0x15042
   1502f:	mov    eax,DWORD PTR [ecx-0x4]
   15032:	test   bl,0x40
   15035:	je     0x1503a
   15037:	cdq
   15038:	jmp    0x1503c
   1503a:	xor    edx,edx
   1503c:	mov    DWORD PTR [ebp-0x41c],ecx
   15042:	test   bl,0x40
   15045:	je     0x15062
   15047:	test   edx,edx
   15049:	jg     0x15062
   1504b:	jl     0x15051
   1504d:	test   eax,eax
   1504f:	jae    0x15062
   15051:	neg    eax
   15053:	adc    edx,0x0
   15056:	neg    edx
   15058:	or     DWORD PTR [ebp-0x408],0x100
   15062:	test   DWORD PTR [ebp-0x408],0x9000
   1506c:	mov    ebx,edx
   1506e:	mov    esi,eax
   15070:	jne    0x15074
   15072:	xor    ebx,ebx
   15074:	cmp    DWORD PTR [ebp-0x40c],0x0
   1507b:	jge    0x15089
   1507d:	mov    DWORD PTR [ebp-0x40c],0x1
   15087:	jmp    0x150a3
   15089:	and    DWORD PTR [ebp-0x408],0xfffffff7
   15090:	mov    eax,0x200
   15095:	cmp    DWORD PTR [ebp-0x40c],eax
   1509b:	jle    0x150a3
   1509d:	mov    DWORD PTR [ebp-0x40c],eax
   150a3:	mov    eax,esi
   150a5:	or     eax,ebx
   150a7:	jne    0x150af
   150a9:	and    DWORD PTR [ebp-0x424],eax
   150af:	lea    edi,[ebp-0x205]
   150b5:	mov    eax,DWORD PTR [ebp-0x40c]
   150bb:	dec    DWORD PTR [ebp-0x40c]
   150c1:	test   eax,eax
   150c3:	jg     0x150cb
   150c5:	mov    eax,esi
   150c7:	or     eax,ebx
   150c9:	je     0x150f8
   150cb:	mov    eax,DWORD PTR [ebp-0x420]
   150d1:	cdq
   150d2:	push   edx
   150d3:	push   eax
   150d4:	push   ebx
   150d5:	push   esi
   150d6:	call   0x153b0
   150db:	add    ecx,0x30
   150de:	cmp    ecx,0x39
   150e1:	mov    DWORD PTR [ebp-0x450],ebx
   150e7:	mov    esi,eax
   150e9:	mov    ebx,edx
   150eb:	jle    0x150f3
   150ed:	add    ecx,DWORD PTR [ebp-0x440]
   150f3:	mov    BYTE PTR [edi],cl
   150f5:	dec    edi
   150f6:	jmp    0x150b5
   150f8:	lea    eax,[ebp-0x205]
   150fe:	sub    eax,edi
   15100:	inc    edi
   15101:	test   DWORD PTR [ebp-0x408],0x200
   1510b:	mov    DWORD PTR [ebp-0x414],eax
   15111:	mov    DWORD PTR [ebp-0x410],edi
   15117:	je     0x15178
   15119:	test   eax,eax
   1511b:	je     0x15124
   1511d:	mov    ecx,edi
   1511f:	cmp    BYTE PTR [ecx],0x30
   15122:	je     0x15178
   15124:	dec    DWORD PTR [ebp-0x410]
   1512a:	mov    ecx,DWORD PTR [ebp-0x410]
   15130:	mov    BYTE PTR [ecx],0x30
   15133:	inc    eax
   15134:	jmp    0x14de4
   15139:	mov    esi,DWORD PTR [ecx]
   1513b:	add    ecx,0x4
   1513e:	mov    DWORD PTR [ebp-0x41c],ecx
   15144:	call   0x1538a
   15149:	test   eax,eax
   1514b:	je     0x1533c
   15151:	test   BYTE PTR [ebp-0x408],0x20
   15158:	je     0x15166
   1515a:	mov    ax,WORD PTR [ebp-0x418]
   15161:	mov    WORD PTR [esi],ax
   15164:	jmp    0x1516e
   15166:	mov    eax,DWORD PTR [ebp-0x418]
   1516c:	mov    DWORD PTR [esi],eax
   1516e:	mov    DWORD PTR [ebp-0x43c],0x1
   15178:	cmp    DWORD PTR [ebp-0x43c],0x0
   1517f:	jne    0x15320
   15185:	mov    ecx,DWORD PTR [ebp-0x408]
   1518b:	test   cl,0x40
   1518e:	je     0x151ce
   15190:	test   ecx,0x100
   15196:	je     0x1519c
   15198:	push   0x2d
   1519a:	jmp    0x151bc
   1519c:	xor    eax,eax
   1519e:	inc    eax
   1519f:	test   al,cl
   151a1:	je     0x151b5
   151a3:	push   0x2b
   151a5:	pop    ecx
   151a6:	mov    WORD PTR [ebp-0x434],cx
   151ad:	mov    DWORD PTR [ebp-0x424],eax
   151b3:	jmp    0x151ce
   151b5:	test   cl,0x2
   151b8:	je     0x151ce
   151ba:	push   0x20
   151bc:	pop    eax
   151bd:	mov    DWORD PTR [ebp-0x424],0x1
   151c7:	mov    WORD PTR [ebp-0x434],ax
   151ce:	mov    ebx,DWORD PTR [ebp-0x430]
   151d4:	mov    esi,DWORD PTR [ebp-0x414]
   151da:	sub    ebx,esi
   151dc:	sub    ebx,DWORD PTR [ebp-0x424]
   151e2:	test   BYTE PTR [ebp-0x408],0xc
   151e9:	jne    0x15202
   151eb:	push   DWORD PTR [ebp-0x42c]
   151f1:	lea    eax,[ebp-0x418]
   151f7:	push   ebx
   151f8:	push   0x20
   151fa:	call   0x14985
   151ff:	add    esp,0xc
   15202:	push   DWORD PTR [ebp-0x424]
   15208:	mov    ecx,DWORD PTR [ebp-0x42c]
   1520e:	lea    eax,[ebp-0x418]
   15214:	lea    edx,[ebp-0x434]
   1521a:	call   0x149b7
   1521f:	test   BYTE PTR [ebp-0x408],0x8
   15226:	pop    ecx
   15227:	je     0x15249
   15229:	test   BYTE PTR [ebp-0x408],0x4
   15230:	jne    0x15249
   15232:	push   DWORD PTR [ebp-0x42c]
   15238:	lea    eax,[ebp-0x418]
   1523e:	push   ebx
   1523f:	push   0x30
   15241:	call   0x14985
   15246:	add    esp,0xc
   15249:	cmp    DWORD PTR [ebp-0x428],0x0
   15250:	jne    0x152de
   15256:	test   esi,esi
   15258:	jle    0x152de
   1525e:	mov    eax,DWORD PTR [ebp-0x410]
   15264:	mov    DWORD PTR [ebp-0x444],eax
   1526a:	mov    DWORD PTR [ebp-0x420],esi
   15270:	push   DWORD PTR ds:0x17080
   15276:	dec    DWORD PTR [ebp-0x420]
   1527c:	push   DWORD PTR [ebp-0x444]
   15282:	lea    eax,[ebp-0x44c]
   15288:	push   eax
   15289:	call   0x15494
   1528e:	add    esp,0xc
   15291:	mov    DWORD PTR [ebp-0x450],eax
   15297:	cmp    eax,0x2
   1529a:	jne    0x152a2
   1529c:	dec    DWORD PTR [ebp-0x420]
   152a2:	test   eax,eax
   152a4:	jle    0x152d5
   152a6:	push   DWORD PTR [ebp-0x44c]
   152ac:	mov    esi,DWORD PTR [ebp-0x42c]
   152b2:	lea    edi,[ebp-0x418]
   152b8:	call   0x1494b
   152bd:	mov    eax,DWORD PTR [ebp-0x450]
   152c3:	add    DWORD PTR [ebp-0x444],eax
   152c9:	cmp    DWORD PTR [ebp-0x420],0x0
   152d0:	pop    ecx
   152d1:	jg     0x15270
   152d3:	jmp    0x152f7
   152d5:	or     DWORD PTR [ebp-0x418],0xffffffff
   152dc:	jmp    0x152f7
   152de:	mov    ecx,DWORD PTR [ebp-0x42c]
   152e4:	mov    edx,DWORD PTR [ebp-0x410]
   152ea:	push   esi
   152eb:	lea    eax,[ebp-0x418]
   152f1:	call   0x149b7
   152f6:	pop    ecx
   152f7:	cmp    DWORD PTR [ebp-0x418],0x0
   152fe:	jl     0x15320
   15300:	test   BYTE PTR [ebp-0x408],0x4
   15307:	je     0x15320
   15309:	push   DWORD PTR [ebp-0x42c]
   1530f:	lea    eax,[ebp-0x418]
   15315:	push   ebx
   15316:	push   0x20
   15318:	call   0x14985
   1531d:	add    esp,0xc
   15320:	mov    edx,DWORD PTR [ebp+0xc]
   15323:	movzx  esi,WORD PTR [edx]
   15326:	test   si,si
   15329:	je     0x15350
   1532b:	mov    edi,DWORD PTR [ebp-0x448]
   15331:	mov    ecx,DWORD PTR [ebp-0x41c]
   15337:	jmp    0x14a9b
   1533c:	xor    eax,eax
   1533e:	push   eax
   1533f:	push   eax
   15340:	push   eax
   15341:	push   eax
   15342:	push   eax
   15343:	call   0x14945
   15348:	add    esp,0x14
   1534b:	or     eax,0xffffffff
   1534e:	jmp    0x15356
   15350:	mov    eax,DWORD PTR [ebp-0x418]
   15356:	pop    esi
   15357:	pop    ebx
   15358:	mov    ecx,DWORD PTR [ebp-0x4]
   1535b:	xor    ecx,ebp
   1535d:	pop    edi
   1535e:	call   0x144c2
   15363:	leave
   15364:	ret
   15365:	cld
   15366:	dec    esp
   15367:	add    DWORD PTR [eax],eax
   15369:	in     eax,dx
   1536a:	dec    edx
   1536b:	add    DWORD PTR [eax],eax
   1536d:	sbb    DWORD PTR [ebx+0x1],ecx
   15370:	add    BYTE PTR [esi+0x4b],dh
   15373:	add    DWORD PTR [eax],eax
   15375:	ret
   15376:	dec    ebx
   15377:	add    DWORD PTR [eax],eax
   15379:	iret
   1537a:	dec    ebx
   1537b:	add    DWORD PTR [eax],eax
   1537d:	push   ss
   1537e:	dec    esp
   1537f:	add    DWORD PTR [eax],eax
   15381:	push   ds
   15382:	dec    ebp
   15383:	add    DWORD PTR [eax],eax
   15385:	int3
   15386:	int3
   15387:	int3
   15388:	int3
   15389:	int3
   1538a:	mov    eax,ds:0x17044
   1538f:	or     eax,0x1
   15392:	xor    ecx,ecx
   15394:	cmp    DWORD PTR ds:0x17924,eax
   1539a:	sete   cl
   1539d:	mov    eax,ecx
   1539f:	ret
   153a0:	int3
   153a1:	int3
   153a2:	int3
   153a3:	int3
   153a4:	int3
   153a5:	int3
   153a6:	int3
   153a7:	int3
   153a8:	int3
   153a9:	int3
   153aa:	int3
   153ab:	int3
   153ac:	int3
   153ad:	int3
   153ae:	int3
   153af:	int3
   153b0:	push   esi
   153b1:	mov    eax,DWORD PTR [esp+0x14]
   153b5:	or     eax,eax
   153b7:	jne    0x153e1
   153b9:	mov    ecx,DWORD PTR [esp+0x10]
   153bd:	mov    eax,DWORD PTR [esp+0xc]
   153c1:	xor    edx,edx
   153c3:	div    ecx
   153c5:	mov    ebx,eax
   153c7:	mov    eax,DWORD PTR [esp+0x8]
   153cb:	div    ecx
   153cd:	mov    esi,eax
   153cf:	mov    eax,ebx
   153d1:	mul    DWORD PTR [esp+0x10]
   153d5:	mov    ecx,eax
   153d7:	mov    eax,esi
   153d9:	mul    DWORD PTR [esp+0x10]
   153dd:	add    edx,ecx
   153df:	jmp    0x15428
   153e1:	mov    ecx,eax
   153e3:	mov    ebx,DWORD PTR [esp+0x10]
   153e7:	mov    edx,DWORD PTR [esp+0xc]
   153eb:	mov    eax,DWORD PTR [esp+0x8]
   153ef:	shr    ecx,1
   153f1:	rcr    ebx,1
   153f3:	shr    edx,1
   153f5:	rcr    eax,1
   153f7:	or     ecx,ecx
   153f9:	jne    0x153ef
   153fb:	div    ebx
   153fd:	mov    esi,eax
   153ff:	mul    DWORD PTR [esp+0x14]
   15403:	mov    ecx,eax
   15405:	mov    eax,DWORD PTR [esp+0x10]
   15409:	mul    esi
   1540b:	add    edx,ecx
   1540d:	jb     0x1541d
   1540f:	cmp    edx,DWORD PTR [esp+0xc]
   15413:	ja     0x1541d
   15415:	jb     0x15426
   15417:	cmp    eax,DWORD PTR [esp+0x8]
   1541b:	jbe    0x15426
   1541d:	dec    esi
   1541e:	sub    eax,DWORD PTR [esp+0x10]
   15422:	sbb    edx,DWORD PTR [esp+0x14]
   15426:	xor    ebx,ebx
   15428:	sub    eax,DWORD PTR [esp+0x8]
   1542c:	sbb    edx,DWORD PTR [esp+0xc]
   15430:	neg    edx
   15432:	neg    eax
   15434:	sbb    edx,0x0
   15437:	mov    ecx,edx
   15439:	mov    edx,ebx
   1543b:	mov    ebx,ecx
   1543d:	mov    ecx,eax
   1543f:	mov    eax,esi
   15441:	pop    esi
   15442:	ret    0x10
   15445:	int3
   15446:	int3
   15447:	int3
   15448:	int3
   15449:	int3
   1544a:	mov    edi,edi
   1544c:	push   ebp
   1544d:	mov    ebp,esp
   1544f:	mov    ecx,DWORD PTR [ebp+0xc]
   15452:	xor    eax,eax
   15454:	cmp    ecx,eax
   15456:	jne    0x1546c
   15458:	push   eax
   15459:	push   eax
   1545a:	push   eax
   1545b:	push   eax
   1545c:	push   eax
   1545d:	call   0x14945
   15462:	add    esp,0x14
   15465:	mov    eax,0xffff
   1546a:	pop    ebp
   1546b:	ret
   1546c:	add    DWORD PTR [ecx+0x4],0xfffffffe
   15470:	js     0x15480
   15472:	mov    edx,DWORD PTR [ecx]
   15474:	mov    ax,WORD PTR [ebp+0x8]
   15478:	mov    WORD PTR [edx],ax
   1547b:	add    DWORD PTR [ecx],0x2
   1547e:	pop    ebp
   1547f:	ret
   15480:	movzx  eax,WORD PTR [ebp+0x8]
   15484:	push   ecx
   15485:	push   eax
   15486:	call   0x154db
   1548b:	pop    ecx
   1548c:	pop    ecx
   1548d:	pop    ebp
   1548e:	ret
   1548f:	int3
   15490:	int3
   15491:	int3
   15492:	int3
   15493:	int3
   15494:	mov    edi,edi
   15496:	push   ebp
   15497:	mov    ebp,esp
   15499:	push   esi
   1549a:	mov    esi,DWORD PTR [ebp+0xc]
   1549d:	test   esi,esi
   1549f:	je     0x154b8
   154a1:	cmp    DWORD PTR [ebp+0x10],0x0
   154a5:	je     0x154b8
   154a7:	cmp    BYTE PTR [esi],0x0
   154aa:	jne    0x154bd
   154ac:	mov    eax,DWORD PTR [ebp+0x8]
   154af:	test   eax,eax
   154b1:	je     0x154b8
   154b3:	xor    ecx,ecx
   154b5:	mov    WORD PTR [eax],cx
   154b8:	xor    eax,eax
   154ba:	pop    esi
   154bb:	pop    ebp
   154bc:	ret
   154bd:	lea    eax,[ebp+0xc]
   154c0:	push   eax
   154c1:	mov    DWORD PTR [ebp+0xc],esi
   154c4:	call   0x154f4
   154c9:	mov    ecx,DWORD PTR [ebp+0x8]
   154cc:	mov    WORD PTR [ecx],ax
   154cf:	mov    eax,DWORD PTR [ebp+0xc]
   154d2:	sub    eax,esi
   154d4:	jmp    0x154ba
   154d6:	int3
   154d7:	int3
   154d8:	int3
   154d9:	int3
   154da:	int3
   154db:	mov    edi,edi
   154dd:	push   ebp
   154de:	mov    ebp,esp
   154e0:	mov    eax,DWORD PTR [ebp+0xc]
   154e3:	or     DWORD PTR [eax+0xc],0x20
   154e7:	mov    eax,0xffff
   154ec:	pop    ebp
   154ed:	ret
   154ee:	int3
   154ef:	int3
   154f0:	int3
   154f1:	int3
   154f2:	int3
   154f3:	int3
   154f4:	jmp    DWORD PTR ds:0x1603c
   154fa:	int3
   154fb:	int3
   154fc:	int3
   154fd:	int3
   154fe:	int3
   154ff:	int3
   15500:	jmp    DWORD PTR ds:0x16008
   15506:	int3
   15507:	int3
   15508:	int3
   15509:	int3
   1550a:	int3
   1550b:	int3
   1550c:	jmp    DWORD PTR ds:0x16004
   15512:	int3
   15513:	int3
   15514:	int3
   15515:	int3
   15516:	int3
   15517:	int3
   15518:	jmp    DWORD PTR ds:0x16000
   1551e:	int3
   1551f:	int3
   15520:	int3
   15521:	int3
   15522:	int3
   15523:	int3
   15524:	jmp    DWORD PTR ds:0x1600c
   1552a:	push   eax
   1552b:	add    BYTE PTR [edi+0x0],ch
   1552e:	jb     0x15530
   15530:	je     0x15532
   15532:	dec    esi
   15533:	add    BYTE PTR [ecx+0x0],ah
   15536:	ins    DWORD PTR es:[edi],dx
   15537:	add    BYTE PTR [ebp+0x0],ah
   1553a:	add    BYTE PTR [eax],al
   1553c:	push   ebx
   1553d:	add    BYTE PTR [ebp+0x0],al
   15540:	push   edx
   15541:	add    BYTE PTR [ecx+0x0],cl
   15544:	inc    ecx
   15545:	add    BYTE PTR [eax+eax*1+0x43],cl
   15549:	add    BYTE PTR [edi+0x0],cl
   1554c:	dec    ebp
   1554d:	add    BYTE PTR [ebp+0x0],cl
   15550:	add    BYTE PTR [eax],al
   15552:	and    eax,0x73007700
   15557:	add    BYTE PTR ds:0x73007700,ah
   1555d:	add    BYTE PTR [eax],al
   1555f:	add    BYTE PTR [eax+eax*1+0x44],bl
   15563:	add    BYTE PTR [edi+0x0],ch
   15566:	jae    0x15568
   15568:	inc    esp
   15569:	add    BYTE PTR [ebp+0x0],ah
   1556c:	jbe    0x1556e
   1556e:	imul   eax,DWORD PTR [eax],0x650063
   15574:	jae    0x15576
   15576:	pop    esp
   15577:	add    BYTE PTR [eax],al
   15579:	add    BYTE PTR [ebp+0x0],dl
   1557c:	jae    0x1557e
   1557e:	bound  eax,QWORD PTR [eax]
   15580:	inc    ebp
   15581:	add    BYTE PTR [esi+0x0],ch
   15584:	popa
   15585:	add    BYTE PTR [edx+0x0],ah
   15588:	ins    BYTE PTR es:[edi],dx
   15589:	add    BYTE PTR [ebp+0x0],ah
   1558c:	pop    edx
   1558d:	add    BYTE PTR [eax+eax*1+0x50],cl
   15591:	add    BYTE PTR [eax],al
   15593:	add    BYTE PTR [edx+0x0],al
   15596:	jne    0x15598
   15598:	ins    BYTE PTR es:[edi],dx
   15599:	add    BYTE PTR [ebx+0x0],ch
   1559c:	dec    ecx
   1559d:	add    BYTE PTR [esi+0x0],ch
   155a0:	inc    edx
   155a1:	add    BYTE PTR [ebp+0x0],dh
   155a4:	data16 add BYTE PTR [ebx+0x0],dl
   155a8:	imul   eax,DWORD PTR [eax],0x65007a
   155ae:	add    BYTE PTR [eax],al
   155b0:	push   edx
   155b1:	add    BYTE PTR [eax+0x0],bh
   155b4:	inc    esi
   155b5:	add    BYTE PTR [ecx+0x0],ch
   155b8:	data16 add BYTE PTR [edi+0x0],ch
   155bc:	push   ebx
   155bd:	add    BYTE PTR [ecx+0x0],ch
   155c0:	jp     0x155c2
   155c2:	add    BYTE PTR gs:[eax],al
   155c5:	add    BYTE PTR [ebp+0x0],dl
   155c8:	jae    0x155ca
   155ca:	add    BYTE PTR gs:[ebx+0x0],al
   155ce:	outs   dx,DWORD PTR ds:[esi]
   155cf:	add    BYTE PTR [esi+0x0],ch
   155d2:	je     0x155d4
   155d4:	imul   eax,DWORD PTR [eax],0x75006e
   155da:	outs   dx,DWORD PTR ds:[esi]
   155db:	add    BYTE PTR [ebp+0x0],dh
   155de:	jae    0x155e0
   155e0:	push   edx
   155e1:	add    BYTE PTR [ebp+0x0],ah
   155e4:	popa
   155e5:	add    BYTE PTR [eax+eax*1+0x0],ah
   155e9:	add    BYTE PTR [ebx+0x0],al
   155ec:	add    BYTE PTR fs:[ebx+0x0],ah
   155f0:	inc    ebx
   155f1:	add    BYTE PTR [edi+0x0],ch
   155f4:	outs   dx,BYTE PTR ds:[esi]
   155f5:	add    BYTE PTR [eax+eax*1+0x72],dh
   155f9:	add    BYTE PTR [edi+0x0],ch
   155fc:	ins    BYTE PTR es:[edi],dx
   155fd:	add    BYTE PTR [eax+eax*1+0x69],cl
   15601:	add    BYTE PTR [esi+0x0],ch
   15604:	add    BYTE PTR gs:[ebx+0x0],dl
   15608:	je     0x1560a
   1560a:	popa
   1560b:	add    BYTE PTR [eax+eax*1+0x65],dh
   1560f:	add    BYTE PTR [eax],al
   15611:	add    BYTE PTR [ebx+0x0],dl
   15614:	jo     0x15616
   15616:	jb     0x15618
   15618:	add    BYTE PTR fs:[esi+0x0],dl
   1561c:	add    BYTE PTR gs:[esi+0x0],ch
   15620:	add    BYTE PTR fs:[edi+0x0],ch
   15624:	jb     0x15626
   15626:	push   edx
   15627:	add    BYTE PTR [ebp+0x0],ah
   1562a:	jno    0x1562c
   1562c:	jne    0x1562e
   1562e:	add    BYTE PTR gs:[ebx+0x0],dh
   15632:	je     0x15634
   15634:	add    BYTE PTR [eax],al
   15636:	push   esi
   15637:	add    BYTE PTR [ebp+0x0],ah
   1563a:	outs   dx,BYTE PTR ds:[esi]
   1563b:	add    BYTE PTR [eax+eax*1+0x6f],ah
   1563f:	add    BYTE PTR [edx+0x0],dh
   15642:	push   edx
   15643:	add    BYTE PTR [ebp+0x0],ah
   15646:	jno    0x15648
   15648:	jne    0x1564a
   1564a:	add    BYTE PTR gs:[ebx+0x0],dh
   1564e:	je     0x15650
   15650:	push   esp
   15651:	add    BYTE PTR [ecx+0x0],ch
   15654:	ins    DWORD PTR es:[edi],dx
   15655:	add    BYTE PTR [ebp+0x0],ah
   15658:	outs   dx,DWORD PTR ds:[esi]
   15659:	add    BYTE PTR [ebp+0x0],dh
   1565c:	je     0x1565e
   1565e:	push   esi
   1565f:	add    BYTE PTR [ecx+0x0],ah
   15662:	ins    BYTE PTR es:[edi],dx
   15663:	add    BYTE PTR [ebp+0x0],dh
   15666:	add    BYTE PTR gs:[eax],al
   15669:	add    BYTE PTR ds:0x73007700,ah
   1566f:	add    BYTE PTR ds:0x6400,ah
   15675:	add    BYTE PTR [eax+eax*1+0x44],bl
   15679:	add    BYTE PTR [ebp+0x0],ah
   1567c:	jbe    0x1567e
   1567e:	imul   eax,DWORD PTR [eax],0x650063
   15684:	pop    esp
   15685:	add    BYTE PTR [ebx+0x0],dh
   15688:	jo     0x1568a
   1568a:	jb     0x1568c
   1568c:	add    BYTE PTR fs:[edi+0x0],bl
   15690:	jne    0x15692
   15692:	jae    0x15694
   15694:	bound  eax,QWORD PTR [eax]
   15696:	arpl   WORD PTR [eax],ax
   15698:	outs   dx,DWORD PTR ds:[esi]
   15699:	add    BYTE PTR [ebp+0x0],ch
   1569c:	ins    DWORD PTR es:[edi],dx
   1569d:	add    BYTE PTR [edi+0x0],bl
   156a0:	ins    DWORD PTR es:[edi],dx
   156a1:	add    BYTE PTR [edi+0x0],ch
   156a4:	add    BYTE PTR fs:[ebp+0x0],ah
   156a8:	ins    DWORD PTR es:[edi],dx
   156a9:	add    BYTE PTR [eax],al
   156ab:	add    BYTE PTR [ebx+0x4f],al
   156ae:	dec    esi
   156af:	dec    esi
   156b0:	inc    ebp
   156b1:	inc    ebx
   156b2:	push   esp
	...

Disassembly of section INIT:

00018000 <INIT>:
   18000:	add    BYTE PTR [eax],al
   18002:	add    BYTE PTR [eax],al
   18004:	add    BYTE PTR [ecx+0x17044],ah
   1800a:	mov    ecx,0xbb40e64e
   1800f:	test   eax,eax
   18011:	je     0x18017
   18013:	cmp    eax,ecx
   18015:	jne    0x18031
   18017:	mov    eax,ds:0x16030
   1801c:	mov    eax,DWORD PTR [eax]
   1801e:	xor    eax,0x17044
   18023:	mov    ds:0x17044,eax
   18028:	jne    0x18031
   1802a:	mov    eax,ecx
   1802c:	mov    ds:0x17044,eax
   18031:	not    eax
   18033:	mov    ds:0x17048,eax
   18038:	ret
   18039:	int3
   1803a:	int3
   1803b:	int3
   1803c:	mov    WORD PTR [eax+0x0],es
   18042:	add    BYTE PTR [eax],al
   18044:	add    BYTE PTR [eax],al
   18046:	add    BYTE PTR [eax],al
   18048:	aam    0x81
   1804a:	add    BYTE PTR [eax],al
   1804c:	adc    al,0x60
   1804e:	add    BYTE PTR [eax],al
   18050:	js     0x17fd2
	...
   1805a:	add    BYTE PTR [eax],al
   1805c:	push   0xffffff82
   1805e:	add    BYTE PTR [eax],al
   18060:	add    BYTE PTR [eax+0x0],ah
	...
   18077:	add    BYTE PTR [edx+eax*4],bh
   1807a:	add    BYTE PTR [eax],al
   1807c:	sub    al,BYTE PTR [edx-0x7dea0000]
   18082:	add    BYTE PTR [eax],al
   18084:	push   edx
   18085:	add    BYTE PTR [eax],0x0
   18088:	add    BYTE PTR [eax],al
   1808a:	add    BYTE PTR [eax],al
   1808c:	sub    al,0x81
   1808e:	add    BYTE PTR [eax],al
   18090:	cmp    al,BYTE PTR [ecx-0x7eb60000]
   18096:	add    BYTE PTR [eax],al
   18098:	add    DWORD PTR fs:[eax],0x818400
   1809f:	add    BYTE PTR [eax+0x14000081],bl
   180a5:	add    DWORD PTR [eax],0x81b600
   180ab:	add    ah,al
   180ad:	add    DWORD PTR [eax],0x81e200
   180b3:	add    dl,bh
   180b5:	add    DWORD PTR [eax],0x80fc00
   180bb:	add    ah,ah
   180bd:	add    BYTE PTR [eax],0x0
   180c0:	fiadd  DWORD PTR [eax-0x7e540000]
   180c6:	add    BYTE PTR [eax],al
   180c8:	rol    BYTE PTR [eax+0x0],1
   180ce:	add    BYTE PTR [eax],al
   180d0:	inc    BYTE PTR [edi]
   180d2:	pop    edi
   180d3:	popa
   180d4:	ins    BYTE PTR es:[edi],dx
   180d5:	ins    BYTE PTR es:[edi],dx
   180d6:	ins    DWORD PTR es:[edi],dx
   180d7:	jne    0x18145
   180d9:	add    BYTE PTR [edi+0x8],cl
   180dc:	ins    DWORD PTR es:[edi],dx
   180dd:	gs ins DWORD PTR es:[edi],dx
   180df:	jae    0x18146
   180e1:	je     0x180e3
   180e3:	add    BYTE PTR [ebp+0x57654b03],ah
   180e9:	popa
   180ea:	imul   esi,DWORD PTR [esi+eax*2+0x6f],0x6e695372
   180f2:	ins    BYTE PTR es:[di],dx
   180f4:	gs dec edi
   180f6:	bound  ebp,QWORD PTR [edx+0x65]
   180f9:	arpl   WORD PTR [eax+eax*1-0x12],si
   180fd:	add    eax,0x496c7452
   18102:	outs   dx,BYTE PTR ds:[esi]
   18103:	imul   esi,DWORD PTR [ebp+edx*2+0x6e],0x646f6369
   1810b:	gs push ebx
   1810d:	je     0x18181
   1810f:	imul   ebp,DWORD PTR [esi+0x67],0x6a40000
   18116:	push   edx
   18117:	je     0x18185
   18119:	push   edi
   1811a:	jb     0x18185
   1811c:	je     0x18183
   1811e:	push   edx
   1811f:	imul   esi,DWORD PTR gs:[bp+di+0x74],0x61567972
   18128:	ins    BYTE PTR es:[edi],dx
   18129:	jne    0x18190
   1812b:	add    BYTE PTR [ebx+eax*1+0x6553654b],al
   18132:	je     0x18179
   18134:	jbe    0x1819b
   18136:	outs   dx,BYTE PTR ds:[esi]
   18137:	je     0x18139
   18139:	add    dl,ah
   1813b:	add    cl,BYTE PTR [ebx+0x65]
   1813e:	inc    ebx
   1813f:	ins    BYTE PTR es:[edi],dx
   18140:	gs popa
   18142:	jb     0x18189
   18144:	jbe    0x181ab
   18146:	outs   dx,BYTE PTR ds:[esi]
   18147:	je     0x18149
   18149:	add    BYTE PTR [ebx+0x6c745205],dl
   1814f:	inc    esp
   18150:	gs ins BYTE PTR es:[edi],dx
   18152:	gs je  0x181ba
   18155:	push   edx
   18156:	imul   esi,DWORD PTR gs:[bp+di+0x74],0x61567972
   1815f:	ins    BYTE PTR es:[edi],dx
   18160:	jne    0x181c7
   18162:	add    BYTE PTR [eax],al
   18164:	sbb    eax,DWORD PTR [edx]
   18166:	dec    ecx
   18167:	outs   dx,DWORD PTR ds:[esi]
   18168:	inc    edi
   18169:	gs je  0x181af
   1816c:	outs   dx,DWORD PTR ds:[esi]
   1816d:	outs   dx,BYTE PTR ds:[esi]
   1816e:	imul   sp,WORD PTR [edi+0x75],0x6172
   18174:	je     0x181df
   18176:	outs   dx,DWORD PTR ds:[esi]
   18177:	outs   dx,BYTE PTR ds:[esi]
   18178:	dec    ecx
   18179:	outs   dx,BYTE PTR ds:[esi]
   1817a:	outs   dx,WORD PTR ds:[esi]
   1817c:	jb     0x181eb
   1817e:	popa
   1817f:	je     0x181ea
   18181:	outs   dx,DWORD PTR ds:[esi]
   18182:	outs   dx,BYTE PTR ds:[esi]
   18183:	add    BYTE PTR [esi],dl
   18185:	add    ecx,DWORD PTR [ebx+0x65]
   18188:	dec    ecx
   18189:	outs   dx,BYTE PTR ds:[esi]
   1818a:	imul   esi,DWORD PTR [ecx+ebp*2+0x61],0x657a696c
   18192:	inc    ebp
   18193:	jbe    0x181fa
   18195:	outs   dx,BYTE PTR ds:[esi]
   18196:	je     0x18198
   18198:	push   eax
   18199:	add    ecx,DWORD PTR [ebx+0x65]
   1819c:	push   ecx
   1819d:	jne    0x18204
   1819f:	jb     0x1821a
   181a1:	push   ebx
   181a2:	jns    0x18217
   181a4:	je     0x1820b
   181a6:	ins    DWORD PTR es:[edi],dx
   181a7:	push   esp
   181a8:	imul   ebp,DWORD PTR [ebp+0x65],0x73086000
   181af:	je     0x18223
   181b1:	outs   dx,BYTE PTR ds:[esi]
   181b2:	arpl   WORD PTR [ebp+0x70],bp
   181b5:	add    BYTE PTR [ebx+eax*1+0x6954654b],bl
   181bc:	arpl   WORD PTR [ebx+0x43],bp
   181bf:	outs   dx,DWORD PTR ds:[esi]
   181c0:	jne    0x18230
   181c2:	je     0x181c4
   181c4:	fld    QWORD PTR [edx]
   181c6:	dec    ebx
   181c7:	gs inc edx
   181c9:	jne    0x18232
   181cb:	inc    ebx
   181cc:	push   0x456b6365
   181d1:	js     0x181d3
   181d3:	add    BYTE PTR [esi+0x74],ch
   181d6:	outs   dx,DWORD PTR ds:[esi]
   181d7:	jae    0x18244
   181d9:	jb     0x18249
   181db:	ins    BYTE PTR es:[edi],dx
   181dc:	cs gs js 0x18245
   181e0:	add    BYTE PTR [eax],al
   181e2:	jge    0x181e9
   181e4:	push   edx
   181e5:	je     0x18253
   181e7:	inc    ebx
   181e8:	outs   dx,DWORD PTR ds:[esi]
   181e9:	jo     0x18264
   181eb:	push   ebp
   181ec:	outs   dx,BYTE PTR ds:[esi]
   181ed:	imul   esp,DWORD PTR [ebx+0x6f],0x74536564
   181f4:	jb     0x1825f
   181f6:	outs   dx,BYTE PTR ds:[esi]
   181f7:	add    BYTE PTR [bx+si],al
   181fa:	push   ebp
   181fb:	add    eax,0x416c7452
   18200:	outs   dx,BYTE PTR ds:[esi]
   18201:	jae    0x1826c
   18203:	inc    ebx
   18204:	push   0x6f547261
   18209:	push   ebp
   1820a:	outs   dx,BYTE PTR ds:[esi]
   1820b:	imul   esp,DWORD PTR [ebx+0x6f],0x68436564
   18212:	popa
   18213:	jb     0x18215
   18215:	add    BYTE PTR [eax],cl
   18217:	add    BYTE PTR [edi+0x64],dl
   1821a:	push   si
   1821c:	gs jb  0x18292
   1821f:	imul   ebp,DWORD PTR [edi+0x6e],0x69626e55
   18226:	outs   dx,BYTE PTR ds:[esi]
   18227:	add    BYTE PTR fs:[eax],al
   1822a:	push   es
   1822b:	add    BYTE PTR [edi+0x64],dl
   1822e:	push   si
   18230:	gs jb  0x182a6
   18233:	imul   ebp,DWORD PTR [edi+0x6e],0x646e6942
   1823a:	add    BYTE PTR [eax],al
   1823c:	pop    es
   1823d:	add    BYTE PTR [edi+0x64],dl
   18240:	push   si
   18242:	gs jb  0x182b8
   18245:	imul   ebp,DWORD PTR [edi+0x6e],0x646e6942
   1824c:	inc    ebx
   1824d:	ins    BYTE PTR es:[edi],dx
   1824e:	popa
   1824f:	jae    0x182c4
   18251:	add    BYTE PTR [ecx],cl
   18253:	add    BYTE PTR [edi+0x64],dl
   18256:	push   si
   18258:	gs jb  0x182ce
   1825b:	imul   ebp,DWORD PTR [edi+0x6e],0x69626e55
   18262:	outs   dx,BYTE PTR ds:[esi]
   18263:	fs inc ebx
   18265:	ins    BYTE PTR es:[edi],dx
   18266:	popa
   18267:	jae    0x182dc
   18269:	add    BYTE PTR [edi+0x44],dl
   1826c:	inc    esi
   1826d:	dec    esp
   1826e:	inc    esp
   1826f:	push   edx
   18270:	cs push ebx
   18272:	pop    ecx
   18273:	push   ebx
	...
